# Build readiness notes

Changes made to the submitted source bundle:

1. Removed the redundant nested `ChessAcademy_Source.zip`.
2. Replaced the workflow's missing-wrapper fallback with a pinned Gradle 9.3.1 setup action.
3. Removed custom debug signing configuration that pointed at a missing `debug.keystore`; debug builds now use Android's standard generated debug key.
4. Removed the release signing assignment that depended on a local keystore not included in the archive. Release builds are not production-signed.
5. Updated README build instructions.

Verification limits:
- This environment has no network access and no installed Gradle distribution or Android SDK, so Gradle dependencies could not be downloaded and the Android build/tests could not be executed here.
- GitHub Actions is the intended place for the first real build and test run. Its result must be checked before treating the APK as verified.
- Chess rules, lesson accuracy, puzzle solutions, and AI playing strength still require runtime and independent correctness testing.
