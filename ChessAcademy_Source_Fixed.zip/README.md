# CHESS ACADEMY
**Learn. Think. Strategize. Master.**

Chess Academy is a complete, offline-first, single-learner personal chess education platform for Android. It guides a learner from absolute zero to master-level strategic concepts through a 9-level progressive curriculum (175+ lessons), interactive 8×8 chessboard demonstrations, mandatory 5-question post-lesson mastery assessments, a 9-category tactical puzzle trainer, an adaptive spaced-repetition revision system, and an offline tactical coaching AI opponent with post-game mistake analysis.

---

## Key Features

1. **9-Level Progressive Curriculum (175+ Lessons)**:
   - **Level 1**: Absolute Beginner (20 lessons — Board, coordinates, all pieces, check, checkmate, stalemate, setup)
   - **Level 2**: Basic Rules & Movement (16 lessons — Castling, En Passant, Promotion, Notation, Clocks, Draw rules, Touch-move)
   - **Level 3**: Beginner Strategy (13 lessons — Center control, development, king safety, connecting rooks, hanging pieces)
   - **Level 4**: Chess Tactics (25 lessons — Fork, Pin, Skewer, Discovered/Double Check, Deflection, Decoy, Smothered/Arabian/Boden's Mate, Greek Gift, Windmill)
   - **Level 5**: Openings (21 major openings for White and Black + Opening Principles, ideas, pawn structures, traps, and plans)
   - **Level 6**: Middlegame Mastery (25 lessons — Outposts, weak squares, open/half-open files, IQP, pawn chains, prophylaxis, good vs bad bishop)
   - **Level 7**: Endgame Mastery (20 lessons — Opposition, Key Squares, Rule of the Square, Lucena, Philidor, K+Q, K+R, Two Bishops)
   - **Level 8**: Advanced Chess (20 lessons — Deep calculation, candidate moves, calculation trees, exchange sacrifices, opposite-side castling, time management)
   - **Level 9**: Master-Level Concepts (15 lessons — Deep positional evaluation, dynamic vs static imbalances, endgame transitions, GM game analysis)
2. **10-Part Lesson Format & Mandatory 5-Question Mastery Tests**:
   - Every lesson features Title, Learning Objective, Simple Explanation, Visual Demonstration, Interactive Chessboard, Step-by-Step Examples, Common Mistakes, Practical Exercise, Summary, and a 5-Question Assessment (80% default passing score to unlock the next lesson).
3. **Full FIDE-Compliant Chess Rules Engine**:
   - Supports legal move generation, absolute pins, castling (`O-O` / `O-O-O`), en passant, promotion/underpromotion, checkmate, stalemate, 50-move rule, threefold repetition, insufficient material, SAN notation, and FEN/PGN import/export.
4. **9-Category Chess Puzzle Trainer**:
   - Mate in 1, Mate in 2, Mate in 3, Tactical, Defensive, Endgame, Opening, Positional, and Advanced Calculation puzzles with timers, hints, and winning idea explanations.
5. **Offline Coaching AI Opponent (5 Difficulty Levels)**:
   - Beginner, Easy, Intermediate, Advanced, and Expert levels powered by an offline alpha-beta minimax + positional piece-square evaluation engine with real-time blunder/mistake coaching and post-game analysis.
6. **Adaptive Spaced Repetition & Local SQLite Persistence**:
   - Uses Room SQLite (`chess_academy_local.db`) to track completed lessons, test scores, weak chess concepts, SM-2 spaced repetition review intervals, puzzle accuracy, and AI game records 100% offline.

---

## Local Build & Test Instructions

### Prerequisites
- JDK 17+
- Gradle 9.3.1
- Android SDK Platform 36 and Build Tools 36.0.0

This source bundle does not include a Gradle wrapper JAR. The included GitHub workflow installs
pinned Gradle 9.3.1 directly. For local builds, install Gradle 9.3.1 and ensure `gradle` is on PATH.

### Running Unit & Robolectric Tests
```bash
gradle :app:testDebugUnitTest --no-daemon
```

### Building the Debug APK Locally
```bash
gradle :app:assembleDebug --no-daemon
```
The debug build uses Android Gradle Plugin's automatically generated debug signing key.
The compiled APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

---

## GitHub Upload & Automated APK Compilation Instructions

This project includes a GitHub Actions workflow at `.github/workflows/android-build.yml`. It installs Gradle 9.3.1 directly because the submitted archive did not include Gradle wrapper scripts or the wrapper JAR.

### Step-by-Step GitHub Build Guide
1. **Create a new GitHub Repository**:
   - Go to [https://github.com/new](https://github.com/new) and create a repository (e.g., `chess-academy-android`).
2. **Push the Source Code**:
   - Extract the delivered source ZIP and push the project root (the folder containing `settings.gradle.kts`) to your repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Chess Academy complete Android application"
   git branch -M main
   git remote add origin https://github.com/<your-username>/chess-academy-android.git
   git push -u origin main
   ```
3. **Download Your Compiled APK**:
   - Open the **Actions** tab in your GitHub repository.
   - Select the **Android APK Build & Test (Chess Academy)** workflow run.
   - Once completed, scroll to the **Artifacts** section at the bottom of the summary page and download **`ChessAcademy-Android-APK`**.

### Configuring Secure Release APK Signing in GitHub Actions
Never commit `.jks` keystores or signing passwords directly into source code. To sign a production Release APK via GitHub Secrets:
1. Generate an upload keystore locally:
   ```bash
   keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```
2. Base64-encode the keystore file:
   ```bash
   base64 -w 0 release-key.jks > release-key.b64
   ```
3. In your GitHub repository, navigate to **Settings → Secrets and variables → Actions** and add:
   - `KEYSTORE_BASE64`: Contents of `release-key.b64`
   - `STORE_PASSWORD`: Your keystore password
   - `KEY_PASSWORD`: Your key alias password
4. In `.github/workflows/android-build.yml`, decode `KEYSTORE_BASE64` to `my-upload-key.jks` before running `./gradlew assembleRelease`—`app/build.gradle.kts` automatically reads `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` from environment variables.

---

## License & Third-Party Attribution
- **Application Source Code**: MIT License.
- **Libraries & Fonts**: AndroidX Jetpack Compose, Material 3, Room SQLite (Apache License 2.0); Plus Jakarta Sans, Inter, and JetBrains Mono fonts (SIL Open Font License 1.1).
