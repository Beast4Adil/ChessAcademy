# Chess Academy — Learn. Think. Strategize. Master.

**Chess Academy** is a complete, offline-first, single-learner personal chess education platform for Android that guides a student from absolute zero to master-level strategic concepts through interactive board demonstrations, mandatory mastery assessments, adaptive spaced-repetition revision, tactical puzzles, and an offline coaching AI opponent.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Please review the confirmed architectural and product decisions below before we proceed to implementation. Once approved, we will execute the build, verification, and packaging milestones.

- **Confirmed Decision 1 — Tactical Coaching AI & Mistake Analysis**: The offline chess opponent and analysis system is built around an adaptive tactical heuristic & alpha-beta minimax engine (Beginner through Expert) with an integrated **Coach & Mistake Analyzer** that detects blunders, hanging pieces, missed tactics, and positional errors in real time and post-game review.
- **Confirmed Decision 2 — Complete 9-Level Interactive Curriculum**: All 9 curriculum levels (from *Level 1: Absolute Beginner* through *Level 9: Master-Level Concepts*) are included with structured lessons, interactive board demonstrations, step-by-step guided examples, common mistakes, and mandatory 5-question mastery assessments (80% pass threshold to unlock subsequent lessons).
- **Confirmed Decision 3 — Selectable Chessboard Visual Themes**: The interactive chessboard defaults to the signature **Cyan & Pure White** aesthetic (`#FFFFFF` / `#00BCD4` / `#E0F7FA`) while allowing the learner to switch seamlessly between **Cyan-White**, **Classic Wood**, and **Tournament Green** board themes in Practice, Puzzles, and Profile settings.
- **Architectural Platform Choice — Native Kotlin, Jetpack Compose & Room SQLite**: While the prompt noted Flutter as a preferred option alongside permission to select a better-suited stack with explanation, this environment compiles native Android applications directly on the Android SDK toolchain. Using **Kotlin + Jetpack Compose + Material 3 + Room SQLite** provides zero-overhead native rendering for interactive 64-square board gestures, instant local SQLite queries, deterministic offline chess rule validation, and direct APK/GitHub Actions compatibility.

---

## 1. Overview & Core Concept

- **What It Does**: Transforms a single learner into a strong, calculating chess player by combining structured theory, hands-on interactive board exercises, automated 5-question post-lesson tests, a categorized tactical/endgame puzzle trainer, an adaptive revision scheduler, and an offline AI sparring partner with post-game mistake analysis.
- **Target Audience / Persona**: A dedicated solo chess student seeking a distraction-free, structured academy without social feeds, accounts, ads, or mandatory internet dependency.
- **Key Value**:
  - **Performance-Gated Mastery**: Advanced lessons unlock only when the learner demonstrates comprehension (80%+ quiz score or diagnostic placement), never merely from time spent.
  - **Concept-Driven Explanations**: Every quiz answer, puzzle solution, and AI post-game review explains *why* a move works or fails based on underlying tactical or strategic principles.
  - **Adaptive Spaced Repetition**: Automatically tracks weak concepts (e.g., pins, knight forks, opposition, back-rank defense) from missed test questions and failed puzzles to build a personalized daily revision session.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **First-Launch Onboarding & Initial Skill Assessment**:
   - Welcomes the learner with the *Chess Academy* vision (*Learn. Think. Strategize. Master.*) and offers an interactive **Initial Knowledge Assessment** (covering piece mechanics, basic rules, tactics, opening principles, and endgames) or direct start from *Absolute Beginner*.
   - Computes the learner's starting tier (*Complete Beginner*, *Beginner*, *Intermediate*, or *Advanced*) and configures their personalized curriculum path while keeping earlier levels accessible for review.
2. **Five-Section Primary Navigation**:
   - **Home**: Displays current curriculum level, daily streak, "Continue Learning" card for the active lesson, "Daily Adaptive Revision" queue based on weak concepts, quick-launch cards for Daily Puzzle and AI Sparring, and recent accuracy snapshot.
   - **Learn**: Presents the 9-Level progressive curriculum accordion/list with completion badges, mastery percentages, lock/unlock status, and full lesson modules.
   - **Practice**: Hub with tabs/modes for **Tactical Puzzles** (9 categories: *Mate in 1, Mate in 2, Mate in 3, Tactical, Defensive, Endgame, Opening, Positional, Advanced Calculation*), **Play vs. Coaching AI** (5 difficulty tiers + post-game analysis), and **Interactive Board Sandbox** (free analysis, position setup, FEN/PGN import & export).
   - **Progress**: Visual analytics dashboard showing overall curriculum completion, level indicator, test accuracy, puzzle solve rate, strongest vs. weakest chess concepts, revision recommendations, and AI match record.
   - **Profile**: Learner settings including current level & assessment retake option, selectable **Board Theme** (*Cyan-White*, *Classic Wood*, *Tournament Green*), coordinate display toggle, move-hint preferences, passing-score threshold (default 80%), PGN/FEN export tools, and progress reset controls.
3. **10-Part Interactive Lesson & Assessment Flow**:
   - Every lesson walks the learner through: (1) Title, (2) Learning Objective, (3) Simple Explanation, (4) Visual Demonstration on the board, (5) Interactive Chessboard sandbox with step-by-step guided exploration, (6) Step-by-Step Annotated Example, (7) Common Mistakes to Avoid, (8) Practical On-Board Exercise, (9) Concise Summary, and (10) Mandatory 5-Question Assessment.
   - The assessment mixes multiple-choice, true/false, interactive board move selection, tactical pattern identification, and illegal-move detection, explaining the chess concept behind every answer and unlocking the next lesson at 80%+.

### Visual Identity & Theme
- **Aesthetic Direction**: Minimalist, high-clarity editorial academy aesthetic where **Pure White** and **Cyan** dominate, keeping cognitive focus entirely on the 8×8 chessboard and concise strategic explanations.
- **Color Palette & Mood**:
  - Primary Background: Pure White (`#FFFFFF`)
  - Elevated Cards & Surfaces: Crisp Ice Grey (`#F7FAFB`) with subtle 1dp borders (`#E5EEF0`)
  - Primary Accent: Academy Cyan (`#00BCD4`) for active indicators, primary CTAs, and tactical highlights
  - Secondary Accent: Soft Cyan Tint (`#E0F7FA`) for light board squares, active pills, and callout banners
  - Primary Text: Dark Charcoal (`#202124`)
  - Secondary Text: Neutral Slate Grey (`#777777`)
  - Semantic Feedback: Soft Emerald Green (`#2E7D32` / `#E8F5E9` surface) for correct moves/answers; Soft Coral Red (`#C62828` / `#FFEBEE` surface) for blunders/incorrect answers
- **Typography & Hierarchy**:
  - **Display & Section Headers**: *Plus Jakarta Sans* (Bold/SemiBold) for clean, authoritative lesson titles and level milestones.
  - **Body & Explanations**: *Inter* (Regular/Medium) with generous line height (`24.sp`) for effortless reading of strategic concepts.
  - **Algebraic Notation & Clocks**: *JetBrains Mono* (Medium) for crisp move lists (`1. e4 e5 2. Nf3 Nc6`), FEN strings, and timers.
- **Component Styling & Layout**:
  - Rounded `16.dp` cards with subtle elevation and zero visual clutter.
  - Custom high-precision `Canvas` + vector chessboard supporting coordinate labels (`a–h`, `1–8`), legal-move target dots/rings, last-move highlight, check king-glow, tactical coach arrows, and selectable board palettes (*Cyan-White*, *Classic Wood*, *Tournament Green*).

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Pure Kotlin FIDE Chess Rules & Tactical Coaching Engine vs. Native Binary Wrapper**
  - *Chosen Approach*: Implement a complete, deterministic FIDE-compliant chess rules engine (legal move generation, pins/checks, castling rights, en passant target squares, promotion dialog, 50-move rule, threefold repetition hash history, insufficient material, stalemate, checkmate, SAN algebraic parser/formatter, FEN & PGN import/export) paired with an offline multi-depth alpha-beta minimax + piece-square positional evaluation + tactical heuristic coach in Kotlin coroutines.
  - *Why*: Eliminates ABI-specific native binary crashes across Android architectures, runs 100% offline with zero external process latency, and allows the engine to inspect semantic chess features (e.g., explaining *why* a move hangs a piece, misses a fork, or weakens king safety) directly for learner coaching and post-game analysis.
  - *Alternatives Considered*: Bundling a raw C++ UCI binary was passed over because raw UCI centipawn scores do not explain tactical mistakes in human terms for beginners and add cross-ABI packaging fragility.

- **Decision 2 — Local Persistence with Room SQLite + Preferences DataStore**
  - *Chosen Approach*: Store all learner progress, lesson quiz history, missed question queue, spaced-repetition intervals, puzzle solve metrics, and saved AI games in a local **Room SQLite database**, with lightweight UI preferences (board theme, onboarding completion, sound/haptics, coordinate visibility) in preferences storage.
  - *Why*: Meets the strict single-learner, offline-first, zero-registration requirement while providing relational queries for weakness detection and spaced repetition.
  - *Alternatives Considered*: Cloud databases (Firestore) were excluded because the specification strictly prohibits account registration, social features, and mandatory internet access.

- **Decision 3 — Structured 9-Level Curriculum Architecture with Performance Gating**
  - *Chosen Approach*: Organize all 9 curriculum levels into structured domain models containing all required topics across Levels 1–9, complete with interactive FEN positions, guided demonstration moves, practical board exercises, and 5 graded assessment questions per lesson.
  - *Why*: Ensures every level has genuine, playable chess content and verified tests rather than empty placeholders, while enforcing the 80% mastery threshold.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                        PRESENTATION LAYER (Jetpack Compose)                  │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────┐ ┌────────┐  │
│  │ Home Screen  │ │ Learn Screen │ │Practice Hub  │ │ Progress │ │Profile │  │
│  │ • Daily Plan │ │ • 9 Levels   │ │ • Puzzles    │ │ • Charts │ │ • Theme│  │
│  │ • Revision   │ │ • 10-Step    │ │ • vs Coach AI│ │ • Weak   │ │ • FEN/ │  │
│  │ • Quick Play │ │   Lesson UI  │ │ • Sandbox    │ │   Topics │ │   PGN  │  │
│  │              │ │ • 5-Q Quiz   │ │ • Post-Game  │ │ • Stats  │ │ • Reset│  │
│  └──────┬───────┘ └──────┬───────┘ └──────┬───────┘ └────┬─────┘ └───┬────┘  │
│         └────────────────┴────────┬───────┴──────────────┴───────────┘       │
│                                   ▼                                          │
│                  ┌──────────────────────────────────┐                        │
│                  │   Shared Interactive Chessboard  │                        │
│                  │ • Legal Move Dots & Captures     │                        │
│                  │ • Promotion / Castling / En Pass │                        │
│                  │ • Cyan-White / Wood / Green Theme│                        │
│                  │ • Move History & Coach Arrows    │                        │
│                  └────────────────┬─────────────────┘                        │
└───────────────────────────────────┼──────────────────────────────────────────┘
                                    ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                     STATE & DOMAIN LAYER (ViewModels & Engines)              │
│  ┌─────────────────────────┐  ┌────────────────────┐  ┌───────────────────┐  │
│  │ FIDE Chess Rules Engine │  │ Tactical Coach AI  │  │ Adaptive Revision │  │
│  │ • Move Generator & Pin  │  │ • 5 Skill Levels   │  │   & Spaced Rep    │  │
│  │ • Check/Mate/Stalemate  │  │ • Alpha-Beta + PST │  │ • Concept Tagging │  │
│  │ • 3-Fold / 50-Move /Mat │  │ • Blunder Detector │  │ • SM-2 Scheduling │  │
│  │ • SAN, FEN & PGN Parser │  │ • Post-Game Review │  │ • Daily Recommend │  │
│  └────────────┬────────────┘  └─────────┬──────────┘  └─────────┬─────────┘  │
└───────────────┼─────────────────────────┼───────────────────────┼────────────┘
                └─────────────────────────┼───────────────────────┘
                                          ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                        DATA LAYER (Offline-First Local Storage)              │
│  ┌──────────────────────────────────────┐  ┌──────────────────────────────┐  │
│  │ Room SQLite Database                 │  │ Curriculum & Puzzle Catalog  │  │
│  │ • LessonProgressEntity (scores/lock) │  │ • 9 Levels (175+ Topics)     │  │
│  │ • AssessmentAttemptEntity            │  │ • Interactive Board Demos    │  │
│  │ • WeakConceptRevisionEntity (SM-2)   │  │ • 5-Question Lesson Quizzes  │  │
│  │ • PuzzleAttemptEntity                │  │ • 9-Category Verified Puzzles│  │
│  │ • AiGameRecordEntity (PGN & review)  │  │ • Diagnostic Placement Test  │  │
│  └──────────────────────────────────────┘  └──────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Database Schema (Room SQLite)

1. **`LearnerProfileEntity`**:
   - Stores single-learner onboarding state, diagnostic score, assigned starting level (`Complete Beginner`, `Beginner`, `Intermediate`, `Advanced`), current active level, daily learning streak, last active date, preferred board theme (`CYAN_WHITE`, `CLASSIC_WOOD`, `TOURNAMENT_GREEN`), and passing threshold (default `80`).
2. **`LessonProgressEntity`**:
   - Tracks `lessonId`, `levelNumber` (1–9), `isUnlocked`, `isCompleted`, `bestScorePercent`, `attemptsCount`, `lastCompletedTimestamp`, and `practicalExerciseSolved`.
3. **`MissedQuestionEntity` & `ConceptMasteryEntity`**:
   - Tracks performance per chess concept tag (e.g., `CASTLING`, `EN_PASSANT`, `FORK`, `PIN`, `SKEWER`, `OPENING_PRINCIPLES`, `OPPOSITION`, `LUCENA`, `CALCULATION`).
   - Stores `correctCount`, `incorrectCount`, `accuracyPercent`, `easeFactor`, `intervalDays`, and `nextReviewTimestamp` to power the **Spaced Repetition & Daily Revision Engine**.
4. **`PuzzleProgressEntity`**:
   - Tracks `puzzleId`, `category` (`MATE_IN_1`, `MATE_IN_2`, `MATE_IN_3`, `TACTICAL`, `DEFENSIVE`, `ENDGAME`, `OPENING`, `POSITIONAL`, `CALCULATION`), `isSolved`, `attempts`, `bestTimeSeconds`, and `hintsUsed`.
5. **`SavedGameEntity`**:
   - Stores completed and in-progress games against the AI (`id`, `difficultyLevel`, `playerColor`, `result`, `pgnText`, `finalFen`, `blundersCount`, `inaccuraciesCount`, `accuracyEstimate`, `timestamp`).

### Curriculum Data Structure (Levels 1 to 9)

Each curriculum level (`Level 1` through `Level 9`) contains structured `LessonModule` objects covering every topic specified in the syllabus:
- **Level 1 (Absolute Beginner — 20 Topics)**: Chess introduction, history/objective, 8×8 board, files/ranks/squares, board orientation, notation basics, piece identification, King, Queen, Rook, Bishop, Knight, Pawn, captures, check, checkmate, stalemate, draw conditions, basic game rules, setting up the board.
- **Level 2 (Basic Rules & Movement — 16 Topics)**: Legal/illegal moves, castling, en passant, pawn promotion, double pawn step, check evasion, protecting the king, piece exchanges, basic & algebraic notation, recording a game, chess clocks, threefold repetition, 50-move rule, insufficient material, touch-move competitive rule.
- **Level 3 (Beginner Strategy — 13 Topics)**: Controlling the center, developing pieces, early castling, king safety, connecting rooks, piece coordination, avoiding unnecessary moves, material value, recognizing hanging pieces, basic exchanges, developing a plan, identifying threats, avoiding opening mistakes.
- **Level 4 (Chess Tactics — 25 Topics)**: Fork, Pin, Skewer, Discovered attack, Double attack, Discovered check, Double check, Deflection, Decoy, Removing the defender, Overloading, Interference, Clearance sacrifice, Zwischenzug, X-ray attack, Trapped pieces, Back-rank weaknesses, Smothered mate, Anastasia's mate, Arabian mate, Boden's mate, Greek gift sacrifice, Windmill, Zwischenzug combinations, Tactical combinations.
- **Level 5 (Openings — 21 Openings + Core Principles)**: Open/Semi-Open/Closed/Flank principles; White (Italian, Ruy Lopez, Scotch, Vienna, King's Gambit, Queen's Gambit, London System, English, Réti); Black vs 1.e4 (Sicilian, French, Caro-Kann, Scandinavian, Pirc, King's Indian); Black vs 1.d4 (QGD, Nimzo-Indian, King's Indian, Grünfeld, Slav, Dutch) — each teaching main idea, move order, principles, variations, traps, pawn structures, plans, mistakes, and responses.
- **Level 6 (Middlegame Mastery — 25 Topics)**: Positional chess, pawn structures, weak squares, outposts, open/half-open files, pawn chains, isolated/doubled/backward/passed pawns, space advantage, initiative, prophylaxis, piece activity, good vs bad bishop, knight vs bishop, rook placement, strategic sacrifices, improving worst piece, creating/exploiting weaknesses, attacking the king, defense, planning & calculation.
- **Level 7 (Endgame Mastery — 20 Topics)**: King & pawn endgames, opposition, key squares, pawn breakthroughs, outside passed pawns, rule of the square, rook endgames, Lucena, Philidor, bishop/knight/queen endgames, rook vs pawn, basic checkmates (K+Q, K+R, 2 Bishops), conversion, defensive draws, endgame calculation.
- **Level 8 (Advanced Chess — 20 Topics)**: Deep calculation, candidate moves, calculation trees, forcing/quiet moves, positional & exchange sacrifices, dynamic compensation, static advantages, prophylactic thinking, complex pawn structures, advanced king attacks, defensive resources, opposite-side castling, initiative, exchange decisions, strategic transformation, practical decisions, time management, tournament prep.
- **Level 9 (Master-Level Concepts — 15 Topics)**: Deep positional evaluation, long-term planning, advanced calculation, dynamic vs static evaluation, piece imbalance, endgame transitions, opening prep & modern theory, engine-assisted analysis, tournament psychology, winning/defending difficult positions, critical moments, imbalances, GM game analysis, plus a realistic mastery perspective note.

### Development Roadmap & Phased Verification

1. **Phase 1: Planning & Architecture** *(Current Phase)* — Finalize architecture, database schema, curriculum model, and design system.
2. **Phase 2 & 3: Core FIDE Chess Rules Engine & Interactive Chessboard UI** — Implement full legal move generation, special moves (castling, en passant, promotion), draw/mate detection, FEN/PGN support, and the multi-theme Compose chessboard.
3. **Phase 4: Complete 9-Level Curriculum & Assessment Engine** — Build the initial skill assessment, 9 curriculum levels, 10-part interactive lesson viewer, and 5-question automated test engine with 80% unlock gating.
4. **Phase 5 & 6: Tactical Puzzle System & Offline Coaching AI** — Implement the 9-category puzzle trainer with hints/timers and the 5-level tactical heuristic AI opponent with real-time & post-game mistake analysis.
5. **Phase 7: Adaptive Revision, Progress Analytics & Profile Tools** — Wire Room SQLite persistence, spaced-repetition weakness scheduling, Progress charts, and FEN/PGN import/export.
6. **Phase 8, 9 & 10: Automated Testing, GitHub Actions Workflow & Source ZIP Delivery** — Run unit and Robolectric tests for chess rules and persistence, create `.github/workflows/android-build.yml`, and package `ChessAcademy_Source.zip` with complete documentation.

### Estimated Complexity & Risks
- **Rule Edge Cases (En Passant Discovered Check, Castling Through Attack, Underpromotion)**: Mitigated by unit-testing the move generator against canonical FEN test positions before wiring UI interactions.
- **AI Search Responsiveness on Mobile**: Mitigated by running alpha-beta search with move ordering (MVV-LVA captures, checks, killer moves) on `Dispatchers.Default` with configurable depth/time budgets per difficulty level so UI frame rates remain locked at 60fps.
- **Curriculum Scale (175+ Topics Across 9 Levels)**: Mitigated by a clean, modular curriculum generator that pairs structured concept explanations, interactive FEN demonstrations, guided sequences, and multi-type assessment generators across every single topic in Levels 1–9.
