package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.chess.AiDifficulty
import com.example.chess.ChessBoardState
import com.example.chess.ChessMove
import com.example.chess.CoachArrow
import com.example.chess.MoveEvaluation
import com.example.chess.MoveQuality
import com.example.chess.PieceColor
import com.example.chess.Square
import com.example.curriculum.ChessPuzzle
import com.example.curriculum.PuzzleAndAssessmentCatalog
import com.example.curriculum.PuzzleCategory
import com.example.ui.AcademyUiState
import com.example.ui.components.InteractiveChessboard
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CardSurfaceLightGrey
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenSurface
import com.example.ui.theme.IncorrectRed
import com.example.ui.theme.IncorrectRedSurface
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MainTextCharcoal
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.PrimaryCyanDark
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SecondaryCyanBorder
import com.example.ui.theme.SecondaryLightCyan
import com.example.ui.theme.SecondaryTextGrey
import com.example.ui.theme.WarningAmberSurface
import kotlinx.coroutines.delay

@Composable
fun PracticeHubScreen(
    uiState: AcademyUiState,
    onOpenPuzzles: (PuzzleCategory?) -> Unit,
    onOpenAiGameplay: (AiDifficulty, PieceColor) -> Unit,
    onOpenBoardSandbox: () -> Unit
) {
    val scrollState = rememberScrollState()
    var selectedAiDiff by remember { mutableStateOf(AiDifficulty.BEGINNER) }
    var selectedColor by remember { mutableStateOf(PieceColor.WHITE) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("practice_hub_screen")
    ) {
        Text(
            text = "Practice & Sparring Hub",
            style = MaterialTheme.typography.headlineLarge,
            color = MainTextCharcoal
        )
        Text(
            text = "Sharpen calculation with 9 puzzle categories, spar with the offline Coach AI, or analyze FEN/PGN positions.",
            style = MaterialTheme.typography.bodySmall,
            color = SecondaryTextGrey
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 1. Play Against Offline Coaching AI Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, PrimaryCyan, RoundedCornerShape(18.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = PrimaryCyanDark
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Play vs. Offline Coaching AI",
                        style = MaterialTheme.typography.titleLarge
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Select opponent strength (Beginner to Expert) and receive real-time mistake & blunder explanations:",
                    style = MaterialTheme.typography.bodySmall,
                    color = SecondaryTextGrey
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(AiDifficulty.entries) { diff ->
                        val selected = selectedAiDiff == diff
                        FilterChip(
                            selected = selected,
                            onClick = { selectedAiDiff = diff },
                            label = { Text("${diff.title} (${diff.eloEstimate})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryCyan,
                                selectedLabelColor = PureWhite
                            )
                        )
                    }
                }

                Text(
                    text = selectedAiDiff.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MainTextCharcoal,
                    modifier = Modifier.padding(vertical = 6.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Play as:", style = MaterialTheme.typography.labelLarge)
                    FilterChip(
                        selected = selectedColor == PieceColor.WHITE,
                        onClick = { selectedColor = PieceColor.WHITE },
                        label = { Text("♔ White") }
                    )
                    FilterChip(
                        selected = selectedColor == PieceColor.BLACK,
                        onClick = { selectedColor = PieceColor.BLACK },
                        label = { Text("♚ Black") }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { onOpenAiGameplay(selectedAiDiff, selectedColor) },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("launch_ai_game_button")
                ) {
                    Text("Start Coaching Match", color = PureWhite, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 2. Dedicated 9-Category Chess Puzzle System
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Chess Puzzle Categories (9)",
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = "All Puzzles",
                style = MaterialTheme.typography.labelLarge,
                color = PrimaryCyanDark,
                modifier = Modifier
                    .clickable { onOpenPuzzles(null) }
                    .testTag("open_all_puzzles_button")
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        PuzzleCategory.entries.forEach { cat ->
            val catPuzzles = PuzzleAndAssessmentCatalog.allPuzzles.filter { it.category == cat }
            val solvedInCat = catPuzzles.count { uiState.puzzleProgressMap[it.id]?.isSolved == true }

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(1.dp, CardBorderSubtle, RoundedCornerShape(14.dp))
                    .clickable { onOpenPuzzles(cat) }
                    .testTag("puzzle_category_${cat.name}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(SecondaryLightCyan),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Extension,
                                contentDescription = null,
                                tint = PrimaryCyanDark
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = cat.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = MainTextCharcoal
                            )
                            Text(
                                text = cat.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = SecondaryTextGrey
                            )
                        }
                    }
                    Surface(
                        color = if (solvedInCat == catPuzzles.size && catPuzzles.isNotEmpty()) CorrectGreenSurface else SecondaryLightCyan,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "$solvedInCat/${catPuzzles.size}",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (solvedInCat == catPuzzles.size && catPuzzles.isNotEmpty()) CorrectGreen else PrimaryCyanDark,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 3. Interactive Analysis Board Sandbox (FEN / PGN / Position Setup)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SecondaryLightCyan.copy(alpha = 0.5f)),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SecondaryCyanBorder, RoundedCornerShape(16.dp))
                .clickable { onOpenBoardSandbox() }
                .testTag("open_sandbox_card")
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.GridOn,
                    contentDescription = null,
                    tint = PrimaryCyanDark,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Interactive Chessboard & FEN/PGN Lab",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Free analysis board with Undo/Redo, Position Presets, FEN Import/Export, and PGN Import/Export.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryTextGrey
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun PuzzleTrainerScreen(
    uiState: AcademyUiState,
    initialCategory: PuzzleCategory?,
    activePuzzle: ChessPuzzle,
    onSelectPuzzle: (ChessPuzzle) -> Unit,
    onRecordResult: (ChessPuzzle, Boolean, Int, Int) -> Unit,
    onBack: () -> Unit
) {
    var selectedCategory by remember(initialCategory) { mutableStateOf(initialCategory) }
    val filteredPuzzles = remember(selectedCategory) {
        PuzzleAndAssessmentCatalog.allPuzzles.filter {
            selectedCategory == null || it.category == selectedCategory
        }
    }

    var boardState by remember(activePuzzle.id) { mutableStateOf(ChessBoardState.fromFen(activePuzzle.fen)) }
    var solved by remember(activePuzzle.id) { mutableStateOf(false) }
    var failedAttemptMessage by remember(activePuzzle.id) { mutableStateOf<String?>(null) }
    var showHint by remember(activePuzzle.id) { mutableStateOf(false) }
    var hintsUsed by remember(activePuzzle.id) { mutableIntStateOf(0) }
    var elapsedSeconds by remember(activePuzzle.id) { mutableIntStateOf(0) }

    LaunchedEffect(activePuzzle.id, solved) {
        while (!solved) {
            delay(1000)
            elapsedSeconds++
        }
    }

    val hintArrow = remember(activePuzzle.id, showHint) {
        if (!showHint) return@remember null
        val uci = activePuzzle.solutionMovesUci.firstOrNull() ?: return@remember null
        if (uci.length >= 4) {
            val from = Square.fromAlgebraic(uci.substring(0, 2))
            val to = Square.fromAlgebraic(uci.substring(2, 4))
            if (from != null && to != null) CoachArrow(from, to, true) else null
        } else {
            null
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("puzzle_trainer_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("puzzle_back_button")) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Column {
                    Text(
                        text = activePuzzle.title,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "${activePuzzle.category.title} • Rating ${activePuzzle.difficultyRating}",
                        style = MaterialTheme.typography.bodySmall,
                        color = PrimaryCyanDark
                    )
                }
            }
            Surface(
                color = SecondaryLightCyan,
                shape = RoundedCornerShape(999.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = PrimaryCyanDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${elapsedSeconds}s",
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.labelMedium,
                        color = MainTextCharcoal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Category Filter Row
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = {
                        selectedCategory = null
                        onSelectPuzzle(PuzzleAndAssessmentCatalog.allPuzzles.first())
                    },
                    label = { Text("All (9)") }
                )
            }
            items(PuzzleCategory.entries) { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = {
                        selectedCategory = cat
                        PuzzleAndAssessmentCatalog.allPuzzles.firstOrNull { it.category == cat }?.let {
                            onSelectPuzzle(it)
                        }
                    },
                    label = { Text(cat.title) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryCyan,
                        selectedLabelColor = PureWhite
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        InteractiveChessboard(
            boardState = boardState,
            onMoveMade = { move ->
                if (solved) return@InteractiveChessboard
                val expectedUci = activePuzzle.solutionMovesUci.firstOrNull()?.lowercase() ?: ""
                val playedUci = move.toUci().lowercase()
                val next = boardState.makeMove(move)
                if (next != null) {
                    boardState = next
                    if (playedUci.startsWith(expectedUci.take(4))) {
                        solved = true
                        failedAttemptMessage = null
                        onRecordResult(activePuzzle, true, elapsedSeconds, hintsUsed)
                    } else {
                        failedAttemptMessage = "${move.san} is not the strongest move here. Try again or tap Hint to see the tactical motif!"
                        onRecordResult(activePuzzle, false, elapsedSeconds, hintsUsed)
                    }
                }
            },
            boardTheme = uiState.boardTheme,
            showCoordinates = uiState.profile.showCoordinates,
            coachArrow = hintArrow,
            onRestart = {
                boardState = ChessBoardState.fromFen(activePuzzle.fen)
                solved = false
                failedAttemptMessage = null
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (failedAttemptMessage != null && !solved) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = IncorrectRedSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = failedAttemptMessage!!,
                        style = MaterialTheme.typography.bodyMedium,
                        color = IncorrectRed
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = {
                            boardState = ChessBoardState.fromFen(activePuzzle.fen)
                            failedAttemptMessage = null
                        }
                    ) {
                        Text("Reset Position & Try Again", color = IncorrectRed)
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (showHint && !solved) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SecondaryLightCyan),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Coach Hint (Concept: ${activePuzzle.conceptTag}):",
                        style = MaterialTheme.typography.labelLarge,
                        color = PrimaryCyanDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = activePuzzle.hintText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MainTextCharcoal
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (solved) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CorrectGreenSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, CorrectGreen, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = CorrectGreen
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Puzzle Solved in ${elapsedSeconds}s!",
                            style = MaterialTheme.typography.titleMedium,
                            color = CorrectGreen
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Winning Idea Explanation:",
                        style = MaterialTheme.typography.labelLarge,
                        color = MainTextCharcoal
                    )
                    Text(
                        text = activePuzzle.winningIdeaExplanation,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MainTextCharcoal
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Action Buttons: Hint & Next Puzzle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = {
                    if (!showHint) hintsUsed++
                    showHint = true
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("puzzle_hint_button")
            ) {
                Icon(imageVector = Icons.Default.Lightbulb, contentDescription = null, tint = PrimaryCyanDark)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Coach Hint", color = PrimaryCyanDark)
            }

            Button(
                onClick = {
                    val idx = filteredPuzzles.indexOfFirst { it.id == activePuzzle.id }
                    val nextPuz = if (idx in 0 until filteredPuzzles.lastIndex) {
                        filteredPuzzles[idx + 1]
                    } else {
                        filteredPuzzles.first()
                    }
                    onSelectPuzzle(nextPuz)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("next_puzzle_button")
            ) {
                Icon(imageVector = Icons.Default.SkipNext, contentDescription = null, tint = PureWhite)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Next Puzzle", color = PureWhite, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AiGameplayScreen(
    uiState: AcademyUiState,
    difficulty: AiDifficulty,
    playerColor: PieceColor,
    boardHistory: List<ChessBoardState>,
    moveEvaluations: List<MoveEvaluation>,
    coachHint: Pair<String, CoachArrow?>?,
    isAiThinking: Boolean,
    onMoveMade: (ChessMove) -> Unit,
    onUndo: () -> Unit,
    onRestart: (AiDifficulty, PieceColor) -> Unit,
    onRequestHint: () -> Unit,
    onBack: () -> Unit
) {
    val currentBoard = boardHistory.lastOrNull() ?: ChessBoardState.initial()
    val latestEval = moveEvaluations.lastOrNull()
    var showPostGameModal by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("ai_gameplay_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("ai_back_button")) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Column {
                    Text(
                        text = "Coach AI • ${difficulty.title} (${difficulty.eloEstimate})",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = if (isAiThinking) "Coach AI is calculating move..." else "Playing as ${playerColor.displayName()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = PrimaryCyanDark
                    )
                }
            }
            OutlinedButton(
                onClick = { showPostGameModal = true },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("open_game_analysis_button")
            ) {
                Icon(imageVector = Icons.Default.Analytics, contentDescription = null, tint = PrimaryCyanDark, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Analysis", color = PrimaryCyanDark)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Difficulty switcher
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(AiDifficulty.entries) { diff ->
                FilterChip(
                    selected = difficulty == diff,
                    onClick = { onRestart(diff, playerColor) },
                    label = { Text(diff.title) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryCyan,
                        selectedLabelColor = PureWhite
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        InteractiveChessboard(
            boardState = currentBoard,
            onMoveMade = onMoveMade,
            boardTheme = uiState.boardTheme,
            showCoordinates = uiState.profile.showCoordinates,
            flipped = playerColor == PieceColor.BLACK,
            coachArrow = coachHint?.second ?: latestEval?.bestMoveArrow?.takeIf {
                latestEval.quality == MoveQuality.BLUNDER || latestEval.quality == MoveQuality.MISTAKE
            },
            canUndo = boardHistory.size >= 2 && !isAiThinking,
            onUndo = onUndo,
            onRestart = { onRestart(difficulty, playerColor) }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Coach Hint Button
        if (uiState.profile.enableCoachHints) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onRequestHint,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).testTag("ai_coach_hint_button")
                ) {
                    Icon(imageVector = Icons.Default.Lightbulb, contentDescription = null, tint = PrimaryCyanDark)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ask Coach for Hint", color = PrimaryCyanDark)
                }
                OutlinedButton(
                    onClick = {
                        onRestart(difficulty, playerColor.opposite())
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Switch Side (${playerColor.opposite().displayName()})", color = MainTextCharcoal)
                }
            }
        }

        if (coachHint != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SecondaryLightCyan),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = coachHint.first,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MainTextCharcoal,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        // Real-time Coach Move Evaluation Card
        if (latestEval != null) {
            Spacer(modifier = Modifier.height(10.dp))
            val isGood = latestEval.quality == MoveQuality.BEST ||
                latestEval.quality == MoveQuality.GOOD ||
                latestEval.quality == MoveQuality.BRILLIANT
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isGood) CorrectGreenSurface else if (latestEval.quality == MoveQuality.INACCURACY) WarningAmberSurface else IncorrectRedSurface
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Move ${latestEval.moveNumber}: ${latestEval.playedMoveSan} • ${latestEval.quality.label} (${latestEval.quality.symbol})",
                            style = MaterialTheme.typography.titleSmall,
                            color = if (isGood) CorrectGreen else IncorrectRed
                        )
                        Text(
                            text = "Best: ${latestEval.bestMoveSan}",
                            fontFamily = JetBrainsMonoFontFamily,
                            style = MaterialTheme.typography.labelSmall,
                            color = MainTextCharcoal
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = latestEval.coachExplanation,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MainTextCharcoal
                    )
                }
            }
        }
    }

    if (showPostGameModal) {
        val blunders = moveEvaluations.count { it.quality == MoveQuality.BLUNDER }
        val mistakes = moveEvaluations.count { it.quality == MoveQuality.MISTAKE }
        val inaccuracies = moveEvaluations.count { it.quality == MoveQuality.INACCURACY }
        val goodMoves = moveEvaluations.count {
            it.quality == MoveQuality.BEST || it.quality == MoveQuality.GOOD || it.quality == MoveQuality.BRILLIANT
        }
        val accuracy = if (moveEvaluations.isEmpty()) 100 else ((goodMoves * 100f) / moveEvaluations.size).toInt()

        AlertDialog(
            onDismissRequest = { showPostGameModal = false },
            title = { Text("Coach Post-Game Analysis") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Accuracy: $accuracy% • Good/Best: $goodMoves • Inaccuracies: $inaccuracies • Mistakes: $mistakes • Blunders: $blunders",
                        style = MaterialTheme.typography.labelLarge,
                        color = PrimaryCyanDark
                    )
                    if (moveEvaluations.isEmpty()) {
                        Text("Play a few moves on the board to generate move-by-move coaching analysis.")
                    } else {
                        moveEvaluations.forEach { ev ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "${ev.moveNumber}. ${ev.playedMoveSan} [${ev.quality.label}] (Best: ${ev.bestMoveSan})",
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                    Text(
                                        text = ev.coachExplanation,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SecondaryTextGrey
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPostGameModal = false }) {
                    Text("Close")
                }
            }
        )
    }
}

/**
 * Interactive Chessboard Sandbox supporting Position Presets, Undo/Redo,
 * FEN Import/Export, and PGN Import/Export.
 */
@Composable
fun BoardSandboxScreen(
    uiState: AcademyUiState,
    onBack: () -> Unit
) {
    var history by remember { mutableStateOf(listOf(ChessBoardState.initial())) }
    var cursor by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    var showFenPgnModal by remember { mutableStateOf(false) }
    var fenInputText by remember { mutableStateOf("") }
    var pgnInputText by remember { mutableStateOf("") }

    val currentBoard = history[cursor]
    val scrollState = rememberScrollState()

    val presets = remember {
        listOf(
            "Starting Position" to ChessBoardState.INITIAL_FEN,
            "Italian Game" to "r1bqk1nr/pppp1ppp/2n5/2b1p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4",
            "Sicilian Defense" to "r1bqkbnr/pp2pppp/2np4/8/3NP3/8/PPP2PPP/RNBQKB1R w KQkq - 0 5",
            "Lucena Endgame" to "1K1k4/1P6/8/8/8/8/r7/2R5 w - - 0 1",
            "Philidor Endgame" to "4k3/8/4p3/4K3/8/8/8/2r4R w - - 0 1",
            "En Passant Demo" to "4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("board_sandbox_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Column {
                    Text(
                        text = "Interactive Chessboard Lab",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "Full FIDE rules, Position Setup, FEN & PGN Import/Export",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryTextGrey
                    )
                }
            }
            OutlinedButton(
                onClick = {
                    fenInputText = currentBoard.toFen()
                    pgnInputText = currentBoard.toPgn()
                    showFenPgnModal = true
                },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("open_fen_pgn_button")
            ) {
                Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = PrimaryCyanDark, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("FEN / PGN", color = PrimaryCyanDark)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Position Setup Presets
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(presets) { (name, fen) ->
                FilterChip(
                    selected = false,
                    onClick = {
                        history = listOf(ChessBoardState.fromFen(fen))
                        cursor = 0
                    },
                    label = { Text(name) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        InteractiveChessboard(
            boardState = currentBoard,
            onMoveMade = { move ->
                val next = currentBoard.makeMove(move)
                if (next != null) {
                    history = history.take(cursor + 1) + next
                    cursor = history.lastIndex
                }
            },
            boardTheme = uiState.boardTheme,
            showCoordinates = uiState.profile.showCoordinates,
            flipped = flipped,
            canUndo = cursor > 0,
            canRedo = cursor < history.lastIndex,
            onUndo = { if (cursor > 0) cursor-- },
            onRedo = { if (cursor < history.lastIndex) cursor++ },
            onFlipToggle = { flipped = !flipped },
            onRestart = {
                history = listOf(ChessBoardState.initial())
                cursor = 0
            }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Current FEN:",
                    style = MaterialTheme.typography.labelMedium,
                    color = PrimaryCyanDark
                )
                Text(
                    text = currentBoard.toFen(),
                    fontFamily = JetBrainsMonoFontFamily,
                    style = MaterialTheme.typography.bodySmall,
                    color = MainTextCharcoal
                )
            }
        }
    }

    if (showFenPgnModal) {
        AlertDialog(
            onDismissRequest = { showFenPgnModal = false },
            title = { Text("FEN & PGN Import / Export") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("FEN String (Position Setup):", style = MaterialTheme.typography.labelLarge)
                    OutlinedTextField(
                        value = fenInputText,
                        onValueChange = { fenInputText = it },
                        modifier = Modifier.fillMaxWidth().testTag("fen_input_field")
                    )
                    Button(
                        onClick = {
                            history = listOf(ChessBoardState.fromFen(fenInputText))
                            cursor = 0
                            showFenPgnModal = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                        modifier = Modifier.fillMaxWidth().testTag("load_fen_button")
                    ) {
                        Text("Load FEN Position", color = PureWhite)
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text("PGN Game Notation:", style = MaterialTheme.typography.labelLarge)
                    OutlinedTextField(
                        value = pgnInputText,
                        onValueChange = { pgnInputText = it },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("pgn_input_field")
                    )
                    Button(
                        onClick = {
                            history = listOf(ChessBoardState.fromPgn(pgnInputText))
                            cursor = 0
                            showFenPgnModal = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyanDark),
                        modifier = Modifier.fillMaxWidth().testTag("load_pgn_button")
                    ) {
                        Text("Import PGN Moves", color = PureWhite)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFenPgnModal = false }) {
                    Text("Done")
                }
            }
        )
    }
}
