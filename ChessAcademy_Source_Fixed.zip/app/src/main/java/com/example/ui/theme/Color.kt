package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary White & Cyan Academy Palette
val PureWhite = Color(0xFFFFFFFF)
val PrimaryCyan = Color(0xFF00BCD4)
val PrimaryCyanDark = Color(0xFF0097A7)
val SecondaryLightCyan = Color(0xFFE0F7FA)
val SecondaryCyanBorder = Color(0xFFB2EBF2)

// Text Colors
val MainTextCharcoal = Color(0xFF202124)
val SecondaryTextGrey = Color(0xFF777777)
val MutedTextGrey = Color(0xFF9AA0A6)

// Surface & Card Colors
val CardSurfaceLightGrey = Color(0xFFF7FAFB)
val CardBorderSubtle = Color(0xFFE6EEF0)
val DividerSubtle = Color(0xFFEDF2F4)

// Semantic Feedback Colors
val CorrectGreen = Color(0xFF2E7D32)
val CorrectGreenSurface = Color(0xFFE8F5E9)
val CorrectGreenBorder = Color(0xFFA5D6A7)

val IncorrectRed = Color(0xFFC62828)
val IncorrectRedSurface = Color(0xFFFFEBEE)
val IncorrectRedBorder = Color(0xFFEF9A9A)

val WarningAmber = Color(0xFFF57C00)
val WarningAmberSurface = Color(0xFFFFF3E0)

// Chessboard Themes
// 1. Cyan-White (Default Signature Theme)
val BoardCyanLight = Color(0xFFE0F7FA)
val BoardCyanDark = Color(0xFF00ACC1)

// 2. Classic Wood
val BoardWoodLight = Color(0xFFF0D9B5)
val BoardWoodDark = Color(0xFFB58863)

// 3. Tournament Green
val BoardGreenLight = Color(0xFFEEEED2)
val BoardGreenDark = Color(0xFF769656)

// Board Highlights
val HighlightSelectedSquare = Color(0x88FFEB3B)
val HighlightLastMove = Color(0x5526C6DA)
val HighlightCheckRed = Color(0xAAEF5350)
val HighlightLegalMove = Color(0x9900838F)
