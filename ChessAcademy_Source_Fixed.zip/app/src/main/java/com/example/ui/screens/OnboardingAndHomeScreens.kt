package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.chess.ChessBoardState
import com.example.curriculum.ChessLesson
import com.example.curriculum.CurriculumLevels5To9
import com.example.curriculum.PuzzleAndAssessmentCatalog
import com.example.ui.AcademyUiState
import com.example.ui.components.InteractiveChessboard
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CardSurfaceLightGrey
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenSurface
import com.example.ui.theme.IncorrectRed
import com.example.ui.theme.IncorrectRedSurface
import com.example.ui.theme.MainTextCharcoal
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.PrimaryCyanDark
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SecondaryCyanBorder
import com.example.ui.theme.SecondaryLightCyan
import com.example.ui.theme.SecondaryTextGrey

@Composable
fun OnboardingWelcomeBanner(
    onStartAssessment: () -> Unit,
    onStartAbsoluteBeginner: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SecondaryLightCyan.copy(alpha = 0.55f)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, SecondaryCyanBorder, RoundedCornerShape(20.dp))
            .testTag("onboarding_welcome_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = PrimaryCyan,
                    shape = RoundedCornerShape(999.dp)
                ) {
                    Text(
                        text = "INITIAL SKILL PLACEMENT",
                        style = MaterialTheme.typography.labelSmall,
                        color = PureWhite,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Personalize Your Chess Academy Path",
                style = MaterialTheme.typography.titleLarge,
                color = MainTextCharcoal
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Take a 2-minute interactive chess knowledge assessment to determine your starting level (Complete Beginner, Beginner, Intermediate, or Advanced), or begin directly from Lesson 1.",
                style = MaterialTheme.typography.bodyMedium,
                color = SecondaryTextGrey
            )
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onStartAssessment,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("take_assessment_button")
                ) {
                    Text("Take Assessment", color = PureWhite, fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(
                    onClick = onStartAbsoluteBeginner,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("start_beginner_button")
                ) {
                    Text("Start from Zero", color = PrimaryCyanDark, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun SkillAssessmentScreen(
    uiState: AcademyUiState,
    onCompleteAssessment: (Int) -> Unit,
    onCancel: () -> Unit
) {
    val questions = remember { PuzzleAndAssessmentCatalog.diagnosticQuestions }
    var currentIndex by remember { mutableIntStateOf(0) }
    var selectedOption by remember { mutableIntStateOf(-1) }
    var isAnswered by remember { mutableStateOf(false) }
    var earnedPoints by remember { mutableIntStateOf(0) }
    var showSummary by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        if (showSummary) {
            val assigned = PuzzleAndAssessmentCatalog.determineStartingLevel(earnedPoints)
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CardBorderSubtle, RoundedCornerShape(20.dp))
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = "Assessment Complete",
                        tint = PrimaryCyan,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Assessment Complete!",
                        style = MaterialTheme.typography.headlineLarge
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Diagnostic Score: $earnedPoints / 100",
                        style = MaterialTheme.typography.titleMedium,
                        color = PrimaryCyanDark
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        color = SecondaryLightCyan,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Assigned Starting Level",
                                style = MaterialTheme.typography.labelMedium,
                                color = SecondaryTextGrey
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = assigned.title,
                                style = MaterialTheme.typography.headlineMedium,
                                color = MainTextCharcoal
                            )
                            Text(
                                text = assigned.badgeLabel,
                                style = MaterialTheme.typography.labelLarge,
                                color = PrimaryCyanDark
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = assigned.summary,
                                style = MaterialTheme.typography.bodyMedium,
                                color = SecondaryTextGrey
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { onCompleteAssessment(earnedPoints) },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("confirm_assessment_result_button")
                    ) {
                        Text(
                            text = "Launch My Personalized Path",
                            color = PureWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            return@Column
        }

        val q = questions[currentIndex]
        val boardState = remember(q.fen) { ChessBoardState.fromFen(q.fen) }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Skill Assessment • ${currentIndex + 1} / ${questions.size}",
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = "Cancel",
                style = MaterialTheme.typography.labelLarge,
                color = SecondaryTextGrey,
                modifier = Modifier.clickable { onCancel() }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { (currentIndex + 1f) / questions.size },
            color = PrimaryCyan,
            trackColor = SecondaryLightCyan,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(999.dp))
        )
        Spacer(modifier = Modifier.height(14.dp))

        Surface(
            color = SecondaryLightCyan,
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = q.categoryLabel,
                style = MaterialTheme.typography.labelMedium,
                color = PrimaryCyanDark,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = q.prompt,
            style = MaterialTheme.typography.titleMedium,
            color = MainTextCharcoal
        )
        Spacer(modifier = Modifier.height(12.dp))

        InteractiveChessboard(
            boardState = boardState,
            onMoveMade = {},
            boardTheme = uiState.boardTheme,
            showCoordinates = uiState.profile.showCoordinates,
            showControls = false,
            showMoveHistory = false,
            modifier = Modifier.fillMaxWidth(0.86f).align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(14.dp))
        q.options.forEachIndexed { idx, optionText ->
            val isSelected = selectedOption == idx
            val isCorrect = idx == q.correctIndex
            val bgColor = when {
                !isAnswered && isSelected -> SecondaryLightCyan
                isAnswered && isCorrect -> CorrectGreenSurface
                isAnswered && isSelected && !isCorrect -> IncorrectRedSurface
                else -> CardSurfaceLightGrey
            }
            val borderColor = when {
                !isAnswered && isSelected -> PrimaryCyan
                isAnswered && isCorrect -> CorrectGreen
                isAnswered && isSelected && !isCorrect -> IncorrectRed
                else -> CardBorderSubtle
            }

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = bgColor),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(1.5.dp, borderColor, RoundedCornerShape(12.dp))
                    .clickable(enabled = !isAnswered) {
                        selectedOption = idx
                        isAnswered = true
                        if (idx == q.correctIndex) {
                            earnedPoints += q.weightPoints
                        }
                    }
                    .testTag("diagnostic_option_$idx")
            ) {
                Text(
                    text = optionText,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        if (isAnswered) {
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedOption == q.correctIndex) CorrectGreenSurface else IncorrectRedSurface
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (selectedOption == q.correctIndex) "Correct!" else "Coach Explanation:",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selectedOption == q.correctIndex) CorrectGreen else IncorrectRed
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = q.explanation,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MainTextCharcoal
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = {
                    if (currentIndex < questions.lastIndex) {
                        currentIndex++
                        selectedOption = -1
                        isAnswered = false
                    } else {
                        showSummary = true
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("diagnostic_next_button")
            ) {
                Text(
                    text = if (currentIndex < questions.lastIndex) "Next Question" else "See My Placement Level",
                    color = PureWhite,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    uiState: AcademyUiState,
    onStartAssessment: () -> Unit,
    onStartDirectBeginner: () -> Unit,
    onOpenLesson: (ChessLesson) -> Unit,
    onOpenPuzzles: () -> Unit,
    onOpenAiGameplay: () -> Unit,
    onOpenLearnTab: () -> Unit
) {
    val scrollState = rememberScrollState()
    val nextLesson = uiState.nextRecommendedLesson
    val currentLevelSpec = CurriculumLevels5To9.levelSpecs.firstOrNull {
        it.levelNumber == uiState.profile.currentCurriculumLevel
    } ?: CurriculumLevels5To9.levelSpecs.first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("home_screen")
    ) {
        // Top Header & Streak
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CHESS ACADEMY",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MainTextCharcoal
                )
                Text(
                    text = "Learn. Think. Strategize. Master.",
                    style = MaterialTheme.typography.bodySmall,
                    color = PrimaryCyanDark,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Surface(
                color = SecondaryLightCyan,
                shape = RoundedCornerShape(999.dp),
                modifier = Modifier.border(1.dp, SecondaryCyanBorder, RoundedCornerShape(999.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Learning Streak",
                        tint = PrimaryCyanDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${uiState.profile.streakDays}d Streak",
                        style = MaterialTheme.typography.labelLarge,
                        color = MainTextCharcoal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Hero Banner Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CardBorderSubtle, RoundedCornerShape(20.dp))
        ) {
            Column {
                Image(
                    painter = painterResource(id = R.drawable.img_chess_hero_1794671285016),
                    contentDescription = "Chess Academy Hero Illustration",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(136.dp)
                )
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentLevelSpec.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = MainTextCharcoal
                            )
                            Text(
                                text = "Starting Tier: ${uiState.assignedLearnerLevel.title}",
                                style = MaterialTheme.typography.bodySmall,
                                color = SecondaryTextGrey
                            )
                        }
                        Surface(
                            color = PrimaryCyan,
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            Text(
                                text = "${uiState.overallCurriculumProgressPercent}% Complete",
                                style = MaterialTheme.typography.labelSmall,
                                color = PureWhite,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { uiState.overallCurriculumProgressPercent / 100f },
                        color = PrimaryCyan,
                        trackColor = SecondaryLightCyan,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(999.dp))
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${uiState.completedLessonsCount} of ${uiState.totalLessonsCount} lessons mastered • ${uiState.averageTestAccuracyPercent}% quiz accuracy",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryTextGrey
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Initial Skill Assessment Banner if not yet completed
        if (!uiState.profile.hasCompletedOnboarding) {
            OnboardingWelcomeBanner(
                onStartAssessment = onStartAssessment,
                onStartAbsoluteBeginner = onStartDirectBeginner
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Primary "Continue Learning" Active Lesson Card
        Text(
            text = "Continue Your Curriculum",
            style = MaterialTheme.typography.titleLarge,
            color = MainTextCharcoal
        )
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, PrimaryCyan, RoundedCornerShape(18.dp))
                .clickable { onOpenLesson(nextLesson) }
                .testTag("continue_learning_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = SecondaryLightCyan,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "LEVEL ${nextLesson.levelNumber} • LESSON ${nextLesson.orderInLevel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = PrimaryCyanDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Open Lesson",
                        tint = PrimaryCyanDark
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = nextLesson.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = MainTextCharcoal
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = nextLesson.learningObjective,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SecondaryTextGrey
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { onOpenLesson(nextLesson) },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("start_next_lesson_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = PureWhite,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Start Interactive Lesson", color = PureWhite, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Daily Adaptive Revision Queue (Spaced Repetition & Weak Areas)
        val weakConcepts = uiState.weakestConcepts
        val revisionLessons = uiState.dailyRevisionQueue
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    tint = PrimaryCyanDark,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Daily Recommended Session",
                    style = MaterialTheme.typography.titleLarge
                )
            }
            Text(
                text = "View All 9 Levels",
                style = MaterialTheme.typography.labelLarge,
                color = PrimaryCyanDark,
                modifier = Modifier.clickable { onOpenLearnTab() }
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = if (weakConcepts.isNotEmpty()) {
                "Spaced repetition prioritized based on your recent test & puzzle mistakes:"
            } else {
                "Recommended next topics on your personalized mastery path:"
            },
            style = MaterialTheme.typography.bodySmall,
            color = SecondaryTextGrey
        )
        Spacer(modifier = Modifier.height(8.dp))

        revisionLessons.forEach { revLesson ->
            val mastery = uiState.conceptMasteryList.firstOrNull { it.conceptTag == revLesson.conceptTag }
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(1.dp, CardBorderSubtle, RoundedCornerShape(14.dp))
                    .clickable { onOpenLesson(revLesson) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = revLesson.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = MainTextCharcoal
                        )
                        Text(
                            text = if (mastery != null && mastery.incorrectCount > 0) {
                                "Revision Needed • ${mastery.accuracyPercent}% accuracy (${mastery.incorrectCount} missed)"
                            } else {
                                "Level ${revLesson.levelNumber} • ${revLesson.learningObjective}"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (mastery != null && mastery.incorrectCount > 0) IncorrectRed else SecondaryTextGrey,
                            maxLines = 1
                        )
                    }
                    Surface(
                        color = SecondaryLightCyan,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (mastery != null && mastery.incorrectCount > 0) "Revise" else "Study",
                            style = MaterialTheme.typography.labelMedium,
                            color = PrimaryCyanDark,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Quick Practice Cards: Tactical Puzzles & Play vs Coaching AI
        Text(
            text = "Practice & Sparring",
            style = MaterialTheme.typography.titleLarge,
            color = MainTextCharcoal
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
                    .clickable { onOpenPuzzles() }
                    .testTag("home_puzzles_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(SecondaryLightCyan),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Extension,
                            contentDescription = "Chess Puzzles",
                            tint = PrimaryCyanDark
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Chess Puzzles",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "${uiState.solvedPuzzlesCount}/${uiState.totalPuzzlesCount} solved across 9 categories",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryTextGrey
                    )
                }
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
                    .clickable { onOpenAiGameplay() }
                    .testTag("home_ai_play_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(SecondaryLightCyan),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "Play Against Coach AI",
                            tint = PrimaryCyanDark
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Play vs Coach AI",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "5 difficulty levels + mistake analysis",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryTextGrey
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
