package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ChessAcademyColorScheme = lightColorScheme(
    primary = PrimaryCyan,
    onPrimary = PureWhite,
    primaryContainer = SecondaryLightCyan,
    onPrimaryContainer = MainTextCharcoal,
    secondary = PrimaryCyanDark,
    onSecondary = PureWhite,
    secondaryContainer = SecondaryLightCyan,
    onSecondaryContainer = MainTextCharcoal,
    tertiary = CorrectGreen,
    onTertiary = PureWhite,
    tertiaryContainer = CorrectGreenSurface,
    onTertiaryContainer = CorrectGreen,
    error = IncorrectRed,
    onError = PureWhite,
    errorContainer = IncorrectRedSurface,
    onErrorContainer = IncorrectRed,
    background = PureWhite,
    onBackground = MainTextCharcoal,
    surface = PureWhite,
    onSurface = MainTextCharcoal,
    surfaceVariant = CardSurfaceLightGrey,
    onSurfaceVariant = SecondaryTextGrey,
    outline = CardBorderSubtle,
    outlineVariant = DividerSubtle
)

val ChessAcademyShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ChessAcademyTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ChessAcademyColorScheme,
        typography = Typography,
        shapes = ChessAcademyShapes,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    ChessAcademyTheme(content = content)
}
