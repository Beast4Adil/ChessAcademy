package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.chess.ChessBoardState
import com.example.chess.CoachArrow
import com.example.chess.Square
import com.example.curriculum.ChessLesson
import com.example.curriculum.CurriculumLevels5To9
import com.example.curriculum.QuestionType
import com.example.ui.AcademyUiState
import com.example.ui.components.InteractiveChessboard
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CardSurfaceLightGrey
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenSurface
import com.example.ui.theme.IncorrectRed
import com.example.ui.theme.IncorrectRedSurface
import com.example.ui.theme.MainTextCharcoal
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.PrimaryCyanDark
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SecondaryCyanBorder
import com.example.ui.theme.SecondaryLightCyan
import com.example.ui.theme.SecondaryTextGrey
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberSurface

@Composable
fun LearnCurriculumScreen(
    uiState: AcademyUiState,
    onSelectLesson: (ChessLesson) -> Unit
) {
    var selectedLevel by remember { mutableIntStateOf(uiState.profile.currentCurriculumLevel.coerceIn(1, 9)) }
    var searchQuery by remember { mutableStateOf("") }

    val levelSpec = remember(selectedLevel) {
        CurriculumLevels5To9.levelSpecs.first { it.levelNumber == selectedLevel }
    }
    val lessonsForLevel = remember(selectedLevel, searchQuery) {
        if (searchQuery.isNotBlank()) {
            CurriculumLevels5To9.allLessons.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                    it.learningObjective.contains(searchQuery, ignoreCase = true)
            }
        } else {
            CurriculumLevels5To9.lessonsForLevel(selectedLevel)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("learn_curriculum_screen")
    ) {
        Text(
            text = "Complete 9-Level Curriculum",
            style = MaterialTheme.typography.headlineLarge,
            color = MainTextCharcoal
        )
        Text(
            text = "Pass each lesson's 5-question assessment (${uiState.profile.passingScoreThreshold}%+) to unlock the next topic.",
            style = MaterialTheme.typography.bodySmall,
            color = SecondaryTextGrey
        )
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search 175+ lessons (e.g., Castling, Fork, Sicilian, Lucena)...") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("curriculum_search_field")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Level 1 to 9 Selector Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(CurriculumLevels5To9.levelSpecs) { spec ->
                val isSelected = selectedLevel == spec.levelNumber && searchQuery.isBlank()
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        searchQuery = ""
                        selectedLevel = spec.levelNumber
                    },
                    label = {
                        Text(
                            text = "Level ${spec.levelNumber}",
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryCyan,
                        selectedLabelColor = PureWhite
                    ),
                    modifier = Modifier.testTag("level_chip_${spec.levelNumber}")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (searchQuery.isBlank()) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SecondaryLightCyan.copy(alpha = 0.55f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SecondaryCyanBorder, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = levelSpec.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MainTextCharcoal
                    )
                    Text(
                        text = levelSpec.overview,
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryTextGrey
                    )
                    if (levelSpec.masteryNote != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = levelSpec.masteryNote,
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryCyanDark,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(lessonsForLevel, key = { it.id }) { lesson ->
                val progress = uiState.lessonProgressMap[lesson.id]
                val isUnlocked = progress?.isUnlocked == true || (lesson.levelNumber == 1 && lesson.orderInLevel == 1)
                val isCompleted = progress?.isCompleted == true
                val bestScore = progress?.bestScorePercent ?: 0

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isUnlocked) CardSurfaceLightGrey else CardSurfaceLightGrey.copy(alpha = 0.55f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = if (isCompleted) CorrectGreen else if (isUnlocked) SecondaryCyanBorder else CardBorderSubtle,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable {
                            // Allow opening unlocked lessons; if locked, still let learner preview or inform why locked
                            if (isUnlocked) {
                                onSelectLesson(lesson)
                            }
                        }
                        .testTag("lesson_card_${lesson.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isCompleted -> CorrectGreenSurface
                                            isUnlocked -> SecondaryLightCyan
                                            else -> CardBorderSubtle
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when {
                                        isCompleted -> Icons.Default.CheckCircle
                                        isUnlocked -> Icons.Default.PlayCircleFilled
                                        else -> Icons.Default.Lock
                                    },
                                    contentDescription = if (isCompleted) "Completed" else if (isUnlocked) "Unlocked" else "Locked",
                                    tint = when {
                                        isCompleted -> CorrectGreen
                                        isUnlocked -> PrimaryCyanDark
                                        else -> SecondaryTextGrey
                                    }
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "L${lesson.levelNumber}.${lesson.orderInLevel} • ${lesson.title}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (isUnlocked) MainTextCharcoal else SecondaryTextGrey
                                )
                                Text(
                                    text = if (isUnlocked) {
                                        lesson.learningObjective
                                    } else {
                                        "Locked — Pass previous lesson test with ${uiState.profile.passingScoreThreshold}%+ to unlock"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SecondaryTextGrey,
                                    maxLines = 2
                                )
                            }
                        }

                        if (bestScore > 0) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = if (isCompleted) CorrectGreenSurface else SecondaryLightCyan,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "$bestScore%",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isCompleted) CorrectGreen else PrimaryCyanDark,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Displays all 10 mandatory components of a Chess Academy Lesson:
 * 1. Lesson Title
 * 2. Learning Objective
 * 3. Simple Explanation
 * 4. Visual Demonstration
 * 5. Interactive Chessboard
 * 6. Step-by-Step Example
 * 7. Common Mistakes
 * 8. Practical Exercise
 * 9. Short Lesson Summary
 * 10. Test Trigger
 */
@Composable
fun LessonDetailScreen(
    lesson: ChessLesson,
    uiState: AcademyUiState,
    onBack: () -> Unit,
    onExerciseCompleted: () -> Unit,
    onStartTest: () -> Unit
) {
    val scrollState = rememberScrollState()
    var activeStepIndex by remember(lesson.id) { mutableIntStateOf(0) }
    var boardHistory by remember(lesson.id) {
        mutableStateOf(listOf(ChessBoardState.fromFen(lesson.interactiveBoardFen)))
    }
    var historyCursor by remember(lesson.id) { mutableIntStateOf(0) }
    var exerciseSolved by remember(lesson.id) {
        mutableStateOf(uiState.lessonProgressMap[lesson.id]?.exerciseSolved == true)
    }
    var feedbackBanner by remember(lesson.id) { mutableStateOf<String?>(null) }

    val currentBoard = boardHistory[historyCursor]
    val activeStep = lesson.stepByStepExamples.getOrElse(activeStepIndex) { lesson.stepByStepExamples.first() }
    val stepArrow = remember(activeStep) {
        val uci = activeStep.highlightMoveUci
        if (uci != null && uci.length >= 4) {
            val from = Square.fromAlgebraic(uci.substring(0, 2))
            val to = Square.fromAlgebraic(uci.substring(2, 4))
            if (from != null && to != null) CoachArrow(from, to, true) else null
        } else {
            null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("lesson_detail_screen")
    ) {
        // 1. Lesson Title & Navigation Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("lesson_back_button")) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "LEVEL ${lesson.levelNumber} • LESSON ${lesson.orderInLevel}",
                    style = MaterialTheme.typography.labelSmall,
                    color = PrimaryCyanDark
                )
                Text(
                    text = lesson.title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MainTextCharcoal
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Learning Objective
        SectionCard(
            badge = "1. LEARNING OBJECTIVE",
            title = "What You Will Master",
            containerColor = SecondaryLightCyan.copy(alpha = 0.55f)
        ) {
            Text(
                text = lesson.learningObjective,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MainTextCharcoal
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 3. Simple Explanation
        SectionCard(
            badge = "2. SIMPLE EXPLANATION",
            title = "Core Chess Concept"
        ) {
            Text(
                text = lesson.simpleExplanation,
                style = MaterialTheme.typography.bodyLarge,
                color = MainTextCharcoal
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 4 & 5 & 8. Visual Demonstration + Interactive Chessboard + Practical Exercise
        SectionCard(
            badge = "3. INTERACTIVE CHESSBOARD & PRACTICAL EXERCISE",
            title = "Hands-On Board Demonstration"
        ) {
            Text(
                text = lesson.visualDemoCaption,
                style = MaterialTheme.typography.bodyMedium,
                color = SecondaryTextGrey
            )
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                color = if (exerciseSolved) CorrectGreenSurface else SecondaryLightCyan,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (exerciseSolved) Icons.Default.CheckCircle else Icons.Default.PlayCircleFilled,
                        contentDescription = null,
                        tint = if (exerciseSolved) CorrectGreen else PrimaryCyanDark
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (exerciseSolved) {
                            "Practical Exercise Solved! (${lesson.practicalExercisePrompt})"
                        } else {
                            "Practical Exercise: ${lesson.practicalExercisePrompt}"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MainTextCharcoal
                    )
                }
            }

            if (feedbackBanner != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = feedbackBanner!!,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (exerciseSolved) CorrectGreen else PrimaryCyanDark
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            InteractiveChessboard(
                boardState = currentBoard,
                onMoveMade = { move ->
                    val next = currentBoard.makeMove(move)
                    if (next != null) {
                        val trimmed = boardHistory.take(historyCursor + 1)
                        boardHistory = trimmed + next
                        historyCursor = boardHistory.lastIndex

                        val playedUci = move.toUci()
                        val targetUci = lesson.practicalExerciseSolutionUci.lowercase()
                        if (playedUci.startsWith(targetUci.take(4))) {
                            exerciseSolved = true
                            feedbackBanner = "Great move! ${move.san} demonstrates ${lesson.title} accurately."
                            onExerciseCompleted()
                        } else {
                            feedbackBanner = "You played ${move.san}. Try finding ${lesson.interactiveInstruction}"
                        }
                    }
                },
                boardTheme = uiState.boardTheme,
                showCoordinates = uiState.profile.showCoordinates,
                coachArrow = stepArrow,
                canUndo = historyCursor > 0,
                canRedo = historyCursor < boardHistory.lastIndex,
                onUndo = { if (historyCursor > 0) historyCursor-- },
                onRedo = { if (historyCursor < boardHistory.lastIndex) historyCursor++ },
                onRestart = {
                    boardHistory = listOf(ChessBoardState.fromFen(lesson.interactiveBoardFen))
                    historyCursor = 0
                    feedbackBanner = null
                }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 6. Step-by-Step Example
        SectionCard(
            badge = "4. STEP-BY-STEP EXAMPLE",
            title = "Guided Walkthrough"
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                lesson.stepByStepExamples.forEachIndexed { idx, step ->
                    val selected = activeStepIndex == idx
                    FilterChip(
                        selected = selected,
                        onClick = {
                            activeStepIndex = idx
                            boardHistory = listOf(ChessBoardState.fromFen(step.fen))
                            historyCursor = 0
                        },
                        label = { Text("Step ${step.stepNumber}") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PrimaryCyan,
                            selectedLabelColor = PureWhite
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = activeStep.title,
                style = MaterialTheme.typography.titleMedium,
                color = MainTextCharcoal
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = activeStep.description,
                style = MaterialTheme.typography.bodyMedium,
                color = SecondaryTextGrey
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 7. Common Mistakes
        SectionCard(
            badge = "5. COMMON MISTAKES",
            title = "What to Avoid",
            containerColor = WarningAmberSurface.copy(alpha = 0.45f)
        ) {
            lesson.commonMistakes.forEach { mistake ->
                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.size(18.dp).padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = mistake,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MainTextCharcoal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 9. Short Lesson Summary
        SectionCard(
            badge = "6. LESSON SUMMARY",
            title = "Key Takeaway"
        ) {
            Text(
                text = lesson.shortSummary,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MainTextCharcoal
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 10. Mandatory 5-Question Mastery Test Button
        Button(
            onClick = onStartTest,
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("start_lesson_test_button")
        ) {
            Icon(imageVector = Icons.Default.Quiz, contentDescription = null, tint = PureWhite)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Take 5-Question Mastery Test",
                color = PureWhite,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun SectionCard(
    badge: String,
    title: String,
    containerColor: androidx.compose.ui.graphics.Color = CardSurfaceLightGrey,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = badge,
                style = MaterialTheme.typography.labelSmall,
                color = PrimaryCyanDark
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MainTextCharcoal
            )
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}

/**
 * Mandatory 5-Question Assessment after every lesson.
 * Checks answers automatically, explains why an answer is right or wrong,
 * records missed questions for spaced-repetition revision, and unlocks the next lesson at >=80%.
 */
@Composable
fun LessonAssessmentScreen(
    lesson: ChessLesson,
    uiState: AcademyUiState,
    onSubmitResults: (Int, List<Pair<Boolean, String>>, (Boolean) -> Unit) -> Unit,
    onBackToLesson: () -> Unit,
    onDoneToCurriculum: () -> Unit
) {
    val questions = lesson.questions
    var qIndex by remember(lesson.id) { mutableIntStateOf(0) }
    var selectedOption by remember(lesson.id, qIndex) { mutableIntStateOf(-1) }
    var isAnswered by remember(lesson.id, qIndex) { mutableStateOf(false) }
    var boardMoveMatched by remember(lesson.id, qIndex) { mutableStateOf<Boolean?>(null) }

    val results = remember(lesson.id) { mutableStateListOf<Pair<Boolean, String>>() }
    var isFinished by remember(lesson.id) { mutableStateOf(false) }
    var passedAssessment by remember(lesson.id) { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("lesson_assessment_screen")
    ) {
        if (isFinished) {
            val correctCount = results.count { it.first }
            val scorePercent = ((correctCount * 100f) / questions.size).toInt()
            val threshold = uiState.profile.passingScoreThreshold

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, if (passedAssessment) CorrectGreen else IncorrectRed, RoundedCornerShape(20.dp))
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = if (passedAssessment) Icons.Default.EmojiEvents else Icons.Default.WarningAmber,
                        contentDescription = null,
                        tint = if (passedAssessment) CorrectGreen else IncorrectRed,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (passedAssessment) "Lesson Mastered!" else "Review & Retake Required",
                        style = MaterialTheme.typography.headlineLarge,
                        color = MainTextCharcoal
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Your Score: $scorePercent% ($correctCount / ${questions.size} Correct)",
                        style = MaterialTheme.typography.titleLarge,
                        color = if (passedAssessment) CorrectGreen else IncorrectRed
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (passedAssessment) {
                            "Congratulations! You exceeded the $threshold% mastery requirement and unlocked the next lesson in the curriculum."
                        } else {
                            "A minimum score of $threshold% is required to unlock the next lesson. Your missed concepts have been added to your Adaptive Revision queue."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = SecondaryTextGrey
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                results.clear()
                                qIndex = 0
                                isFinished = false
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("retake_lesson_test_button")
                        ) {
                            Text("Retake Test", color = PrimaryCyanDark, fontWeight = FontWeight.SemiBold)
                        }
                        Button(
                            onClick = onDoneToCurriculum,
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("finish_lesson_test_button")
                        ) {
                            Text("Continue", color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            return@Column
        }

        val q = questions[qIndex]
        var boardState by remember(q.id) { mutableStateOf(ChessBoardState.fromFen(q.fenPosition)) }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBackToLesson) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Lesson")
                }
                Text(
                    text = "Question ${qIndex + 1} of ${questions.size}",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Surface(
                color = SecondaryLightCyan,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "${q.type.label} • Diff ${q.difficulty}/5",
                    style = MaterialTheme.typography.labelSmall,
                    color = PrimaryCyanDark,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        LinearProgressIndicator(
            progress = { (qIndex + 1f) / questions.size },
            color = PrimaryCyan,
            trackColor = SecondaryLightCyan,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(999.dp))
        )

        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = q.prompt,
            style = MaterialTheme.typography.titleMedium,
            color = MainTextCharcoal
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Interactive Board (Interactive for BOARD_MOVE questions, visual reference for others)
        InteractiveChessboard(
            boardState = boardState,
            onMoveMade = { move ->
                if (!isAnswered && q.type == QuestionType.BOARD_MOVE && q.requiredBoardMoveUci != null) {
                    val next = boardState.makeMove(move)
                    if (next != null) {
                        boardState = next
                        val matched = move.toUci().startsWith(q.requiredBoardMoveUci.take(4).lowercase())
                        boardMoveMatched = matched
                        selectedOption = if (matched) q.correctOptionIndex else 1
                        isAnswered = true
                        results.add(matched to if (matched) q.correctExplanation else q.incorrectExplanation)
                    }
                }
            },
            boardTheme = uiState.boardTheme,
            showCoordinates = uiState.profile.showCoordinates,
            showControls = false,
            showMoveHistory = false,
            modifier = Modifier.fillMaxWidth(0.88f).align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(14.dp))

        q.options.forEachIndexed { idx, optText ->
            val isSelected = selectedOption == idx
            val isCorrect = idx == q.correctOptionIndex
            val bgColor = when {
                !isAnswered && isSelected -> SecondaryLightCyan
                isAnswered && isCorrect -> CorrectGreenSurface
                isAnswered && isSelected && !isCorrect -> IncorrectRedSurface
                else -> CardSurfaceLightGrey
            }
            val borderColor = when {
                !isAnswered && isSelected -> PrimaryCyan
                isAnswered && isCorrect -> CorrectGreen
                isAnswered && isSelected && !isCorrect -> IncorrectRed
                else -> CardBorderSubtle
            }

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = bgColor),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(1.5.dp, borderColor, RoundedCornerShape(12.dp))
                    .clickable(enabled = !isAnswered) {
                        selectedOption = idx
                        isAnswered = true
                        val right = idx == q.correctOptionIndex
                        results.add(right to if (right) q.correctExplanation else q.incorrectExplanation)
                    }
                    .testTag("quiz_option_$idx")
            ) {
                Text(
                    text = optText,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        if (isAnswered) {
            val answeredRight = selectedOption == q.correctOptionIndex || boardMoveMatched == true
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (answeredRight) CorrectGreenSurface else IncorrectRedSurface
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (answeredRight) "Correct! Why this works:" else "Incorrect — Concept Explanation:",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (answeredRight) CorrectGreen else IncorrectRed
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (answeredRight) q.correctExplanation else "${q.incorrectExplanation}\n\nWhy the right answer works: ${q.correctExplanation}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MainTextCharcoal
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = {
                    if (qIndex < questions.lastIndex) {
                        qIndex++
                    } else {
                        val correctCount = results.count { it.first }
                        val pct = ((correctCount * 100f) / questions.size).toInt()
                        onSubmitResults(pct, results.toList()) { passed ->
                            passedAssessment = passed
                            isFinished = true
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("quiz_next_button")
            ) {
                Text(
                    text = if (qIndex < questions.lastIndex) "Next Question" else "Complete Assessment",
                    color = PureWhite,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
