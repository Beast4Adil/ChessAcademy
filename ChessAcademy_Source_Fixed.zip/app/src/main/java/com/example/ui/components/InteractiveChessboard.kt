package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.BoardTheme
import com.example.chess.ChessBoardState
import com.example.chess.ChessMove
import com.example.chess.CoachArrow
import com.example.chess.GameStatus
import com.example.chess.PieceColor
import com.example.chess.PieceType
import com.example.chess.Square
import com.example.ui.theme.BoardCyanDark
import com.example.ui.theme.BoardCyanLight
import com.example.ui.theme.BoardGreenDark
import com.example.ui.theme.BoardGreenLight
import com.example.ui.theme.BoardWoodDark
import com.example.ui.theme.BoardWoodLight
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CardSurfaceLightGrey
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.HighlightCheckRed
import com.example.ui.theme.HighlightLastMove
import com.example.ui.theme.HighlightSelectedSquare
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MainTextCharcoal
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.PrimaryCyanDark
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SecondaryLightCyan
import com.example.ui.theme.SecondaryTextGrey
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun InteractiveChessboard(
    boardState: ChessBoardState,
    onMoveMade: (ChessMove) -> Unit,
    modifier: Modifier = Modifier,
    boardTheme: BoardTheme = BoardTheme.CYAN_WHITE,
    showCoordinates: Boolean = true,
    flipped: Boolean = false,
    coachArrow: CoachArrow? = null,
    showControls: Boolean = true,
    showMoveHistory: Boolean = true,
    onUndo: (() -> Unit)? = null,
    onRedo: (() -> Unit)? = null,
    onRestart: (() -> Unit)? = null,
    onFlipToggle: (() -> Unit)? = null,
    canUndo: Boolean = false,
    canRedo: Boolean = false
) {
    var selectedSquare by remember(boardState) { mutableStateOf<Square?>(null) }
    var pendingPromotionMoves by remember(boardState) { mutableStateOf<List<ChessMove>?>(null) }

    val legalMovesForSelected = remember(boardState, selectedSquare) {
        selectedSquare?.let { boardState.legalMovesFrom(it) }.orEmpty()
    }

    val (lightColor, darkColor) = when (boardTheme) {
        BoardTheme.CYAN_WHITE -> BoardCyanLight to BoardCyanDark
        BoardTheme.CLASSIC_WOOD -> BoardWoodLight to BoardWoodDark
        BoardTheme.TOURNAMENT_GREEN -> BoardGreenLight to BoardGreenDark
    }

    val status = remember(boardState) { boardState.gameStatus() }
    val kingInCheckSquare = remember(boardState, status) {
        if (status == GameStatus.CHECK || status == GameStatus.CHECKMATE) {
            boardState.kingSquare(boardState.turn)
        } else {
            null
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Turn and Status Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(if (boardState.turn == PieceColor.WHITE) PureWhite else MainTextCharcoal)
                        .border(1.5.dp, PrimaryCyanDark, CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${boardState.turn.displayName()} to move",
                    style = MaterialTheme.typography.labelLarge,
                    color = MainTextCharcoal
                )
            }

            Surface(
                color = when {
                    status == GameStatus.CHECKMATE -> PrimaryCyan
                    status == GameStatus.CHECK -> HighlightCheckRed
                    status.isTerminal -> SecondaryLightCyan
                    else -> CardSurfaceLightGrey
                },
                shape = RoundedCornerShape(999.dp)
            ) {
                Text(
                    text = status.label,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (status == GameStatus.CHECKMATE || status == GameStatus.CHECK) PureWhite else MainTextCharcoal,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        // 8x8 Board Container
        Card(
            shape = RoundedCornerShape(14.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .border(2.dp, CardBorderSubtle, RoundedCornerShape(14.dp))
                .clip(RoundedCornerShape(14.dp))
                .testTag("interactive_chessboard")
        ) {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.fillMaxSize()) {
                    val ranks = if (flipped) (0..7).toList() else (7 downTo 0).toList()
                    val files = if (flipped) (7 downTo 0).toList() else (0..7).toList()

                    for (rank in ranks) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            for (file in files) {
                                val square = Square(file, rank)
                                val piece = boardState.pieceAt(square)
                                val isSelected = selectedSquare == square
                                val isLastMoveSq = boardState.lastMove?.from == square || boardState.lastMove?.to == square
                                val isKingCheck = kingInCheckSquare == square
                                val matchingLegalMoves = legalMovesForSelected.filter { it.to == square }
                                val isLegalDestination = matchingLegalMoves.isNotEmpty()

                                val baseSqColor = if (square.isLightSquare) lightColor else darkColor
                                val bgColor = when {
                                    isKingCheck -> HighlightCheckRed
                                    isSelected -> HighlightSelectedSquare
                                    isLastMoveSq -> HighlightLastMove
                                    else -> baseSqColor
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .background(bgColor)
                                        .clickable {
                                            if (isLegalDestination) {
                                                if (matchingLegalMoves.size > 1 && matchingLegalMoves.any { it.promotion != null }) {
                                                    pendingPromotionMoves = matchingLegalMoves
                                                } else {
                                                    onMoveMade(matchingLegalMoves.first())
                                                    selectedSquare = null
                                                }
                                            } else if (piece != null && piece.color == boardState.turn) {
                                                selectedSquare = if (selectedSquare == square) null else square
                                            } else {
                                                selectedSquare = null
                                            }
                                        }
                                        .testTag("square_${square.toAlgebraic()}"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    // Coordinate labels along left rank edge and bottom file edge
                                    val isLeftEdge = file == files.first()
                                    val isBottomEdge = rank == ranks.last()
                                    val coordColor = if (square.isLightSquare) darkColor else lightColor

                                    if (showCoordinates && isLeftEdge) {
                                        Text(
                                            text = "${rank + 1}",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = coordColor,
                                            modifier = Modifier
                                                .align(Alignment.TopStart)
                                                .padding(start = 2.dp, top = 1.dp)
                                        )
                                    }
                                    if (showCoordinates && isBottomEdge) {
                                        Text(
                                            text = "${('a'.code + file).toChar()}",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = coordColor,
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(end = 2.dp, bottom = 1.dp)
                                        )
                                    }

                                    // Chess Piece Glyph with High-Contrast Badge
                                    if (piece != null) {
                                        ChessPieceToken(
                                            type = piece.type,
                                            color = piece.color
                                        )
                                    }

                                    // Legal Move Indicator (Dot for empty square, Ring for capture)
                                    if (isLegalDestination) {
                                        if (piece != null || matchingLegalMoves.any { it.isEnPassant }) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize(0.86f)
                                                    .border(3.dp, PrimaryCyanDark.copy(alpha = 0.85f), CircleShape)
                                            )
                                        } else {
                                            Box(
                                                modifier = Modifier
                                                    .size(13.dp)
                                                    .clip(CircleShape)
                                                    .background(PrimaryCyanDark.copy(alpha = 0.75f))
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Draw Coach Arrow Overlay if present
                if (coachArrow != null) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val cellW = size.width / 8f
                        val cellH = size.height / 8f

                        fun squareCenter(sq: Square): Offset {
                            val col = if (flipped) 7 - sq.file else sq.file
                            val row = if (flipped) sq.rank else 7 - sq.rank
                            return Offset((col + 0.5f) * cellW, (row + 0.5f) * cellH)
                        }

                        val start = squareCenter(coachArrow.from)
                        val end = squareCenter(coachArrow.to)
                        val arrowColor = if (coachArrow.isBestMove) CorrectGreen else PrimaryCyan

                        drawLine(
                            color = arrowColor.copy(alpha = 0.85f),
                            start = start,
                            end = end,
                            strokeWidth = 10f,
                            cap = StrokeCap.Round
                        )

                        val angle = atan2(end.y - start.y, end.x - start.x)
                        val headLength = 26f
                        val arrowPath = Path().apply {
                            moveTo(end.x, end.y)
                            lineTo(
                                end.x - headLength * cos(angle - 0.5f),
                                end.y - headLength * sin(angle - 0.5f)
                            )
                            lineTo(
                                end.x - headLength * cos(angle + 0.5f),
                                end.y - headLength * sin(angle + 0.5f)
                            )
                            close()
                        }
                        drawPath(arrowPath, color = arrowColor)
                    }
                }
            }
        }

        // Move History Tape (SAN Algebraic Notation)
        if (showMoveHistory && boardState.moveHistory.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            val movePairs = remember(boardState.moveHistory) {
                boardState.moveHistory.chunked(2)
            }
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardSurfaceLightGrey, RoundedCornerShape(10.dp))
                    .border(1.dp, CardBorderSubtle, RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(movePairs) { idx, pair ->
                    val whiteSan = pair.getOrNull(0)?.san ?: ""
                    val blackSan = pair.getOrNull(1)?.san ?: ""
                    Text(
                        text = "${idx + 1}. $whiteSan ${if (blackSan.isNotEmpty()) blackSan else ""}".trim(),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        color = MainTextCharcoal
                    )
                }
            }
        }

        // Board Controls Bar (Undo, Redo, Flip, Restart)
        if (showControls && (onUndo != null || onRedo != null || onRestart != null || onFlipToggle != null)) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onUndo != null) {
                    IconButton(
                        onClick = onUndo,
                        enabled = canUndo,
                        modifier = Modifier.testTag("board_undo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo Move",
                            tint = if (canUndo) MainTextCharcoal else SecondaryTextGrey.copy(alpha = 0.4f)
                        )
                    }
                }
                if (onRedo != null) {
                    IconButton(
                        onClick = onRedo,
                        enabled = canRedo,
                        modifier = Modifier.testTag("board_redo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo Move",
                            tint = if (canRedo) MainTextCharcoal else SecondaryTextGrey.copy(alpha = 0.4f)
                        )
                    }
                }
                if (onFlipToggle != null) {
                    IconButton(
                        onClick = onFlipToggle,
                        modifier = Modifier.testTag("board_flip_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = "Flip Board Orientation",
                            tint = MainTextCharcoal
                        )
                    }
                }
                if (onRestart != null) {
                    IconButton(
                        onClick = onRestart,
                        modifier = Modifier.testTag("board_restart_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset Board Position",
                            tint = PrimaryCyanDark
                        )
                    }
                }
            }
        }
    }

    // Pawn Promotion Selection Dialog
    val promoCandidates = pendingPromotionMoves
    if (promoCandidates != null) {
        AlertDialog(
            onDismissRequest = { pendingPromotionMoves = null },
            title = {
                Text(
                    text = "Promote Pawn",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Choose which piece your pawn promotes to on ${promoCandidates.first().to.toAlgebraic()}:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT).forEach { pt ->
                            val move = promoCandidates.firstOrNull { it.promotion == pt } ?: promoCandidates.first()
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = SecondaryLightCyan,
                                modifier = Modifier
                                    .size(60.dp)
                                    .clickable {
                                        pendingPromotionMoves = null
                                        selectedSquare = null
                                        onMoveMade(move)
                                    }
                                    .testTag("promote_${pt.name.lowercase()}"),
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = pt.unicodeSymbol(boardState.turn),
                                        fontSize = 26.sp,
                                        color = MainTextCharcoal
                                    )
                                    Text(
                                        text = pt.symbol.toString(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = PrimaryCyanDark
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { pendingPromotionMoves = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ChessPieceToken(
    type: PieceType,
    color: PieceColor
) {
    val isWhite = color == PieceColor.WHITE
    Box(
        modifier = Modifier
            .fillMaxSize(0.78f)
            .clip(CircleShape)
            .background(if (isWhite) PureWhite else Color(0xFF263238))
            .border(
                width = 1.5.dp,
                color = if (isWhite) Color(0xFF37474F) else PureWhite.copy(alpha = 0.85f),
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = type.unicodeSymbol(PieceColor.BLACK),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = if (isWhite) Color(0xFF1C262B) else PureWhite,
            textAlign = TextAlign.Center
        )
    }
}
