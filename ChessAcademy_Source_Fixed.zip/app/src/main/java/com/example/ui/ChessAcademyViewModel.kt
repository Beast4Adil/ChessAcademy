package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.chess.AiDifficulty
import com.example.chess.BoardTheme
import com.example.chess.ChessBoardState
import com.example.chess.ChessCoachAi
import com.example.chess.ChessMove
import com.example.chess.CoachArrow
import com.example.chess.GameStatus
import com.example.chess.MoveEvaluation
import com.example.chess.MoveQuality
import com.example.chess.PieceColor
import com.example.curriculum.ChessLesson
import com.example.curriculum.ChessPuzzle
import com.example.curriculum.CurriculumLevels5To9
import com.example.curriculum.LearnerLevel
import com.example.curriculum.PuzzleAndAssessmentCatalog
import com.example.curriculum.PuzzleCategory
import com.example.data.AiGameRecordEntity
import com.example.data.ChessAcademyDatabase
import com.example.data.ChessAcademyRepository
import com.example.data.ConceptMasteryEntity
import com.example.data.LearnerProfileEntity
import com.example.data.LessonProgressEntity
import com.example.data.PuzzleProgressEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class MainNavTab(val label: String) {
    HOME("Home"),
    LEARN("Learn"),
    PRACTICE("Practice"),
    PROGRESS("Progress"),
    PROFILE("Profile")
}

enum class SubScreen {
    NONE,
    SKILL_ASSESSMENT,
    LESSON_DETAIL,
    LESSON_TEST,
    PUZZLE_TRAINER,
    AI_GAMEPLAY,
    BOARD_SANDBOX
}

data class AcademyUiState(
    val isInitialized: Boolean = false,
    val profile: LearnerProfileEntity = LearnerProfileEntity(),
    val lessonProgressMap: Map<String, LessonProgressEntity> = emptyMap(),
    val conceptMasteryList: List<ConceptMasteryEntity> = emptyList(),
    val puzzleProgressMap: Map<String, PuzzleProgressEntity> = emptyMap(),
    val aiGames: List<AiGameRecordEntity> = emptyList()
) {
    val boardTheme: BoardTheme
        get() = BoardTheme.entries.firstOrNull { it.name == profile.boardThemeName } ?: BoardTheme.CYAN_WHITE

    val assignedLearnerLevel: LearnerLevel
        get() = LearnerLevel.entries.firstOrNull { it.name == profile.assignedLevelName } ?: LearnerLevel.COMPLETE_BEGINNER

    val totalLessonsCount: Int get() = CurriculumLevels5To9.allLessons.size
    val completedLessonsCount: Int get() = lessonProgressMap.values.count { it.isCompleted }

    val overallCurriculumProgressPercent: Int
        get() = if (totalLessonsCount == 0) 0 else ((completedLessonsCount * 100f) / totalLessonsCount).toInt()

    val averageTestAccuracyPercent: Int
        get() {
            val attempted = lessonProgressMap.values.filter { it.attemptsCount > 0 }
            if (attempted.isEmpty()) return 0
            return attempted.map { it.bestScorePercent }.average().toInt()
        }

    val totalPuzzlesCount: Int get() = PuzzleAndAssessmentCatalog.allPuzzles.size
    val solvedPuzzlesCount: Int get() = puzzleProgressMap.values.count { it.isSolved }

    val puzzleSuccessRatePercent: Int
        get() {
            val attempted = puzzleProgressMap.values.filter { it.attempts > 0 }
            if (attempted.isEmpty()) return 0
            val solved = attempted.count { it.isSolved }
            return ((solved * 100f) / attempted.size).toInt()
        }

    val weakestConcepts: List<ConceptMasteryEntity>
        get() = conceptMasteryList
            .filter { it.incorrectCount > 0 }
            .sortedWith(compareBy<ConceptMasteryEntity> { it.accuracyPercent }.thenByDescending { it.incorrectCount })
            .take(5)

    val strongestConcepts: List<ConceptMasteryEntity>
        get() = conceptMasteryList
            .filter { it.correctCount > 0 && it.accuracyPercent >= 80 }
            .sortedByDescending { it.correctCount }
            .take(5)

    val dailyRevisionQueue: List<ChessLesson>
        get() {
            val weakLessonIds = conceptMasteryList
                .filter { it.needsRevision }
                .map { it.lessonId }
                .distinct()
            val lessons = weakLessonIds.mapNotNull { CurriculumLevels5To9.getLessonById(it) }
            if (lessons.isNotEmpty()) return lessons.take(4)

            // Fallback: recently unlocked but uncompleted lessons
            return CurriculumLevels5To9.allLessons.filter { lesson ->
                val p = lessonProgressMap[lesson.id]
                p?.isUnlocked == true && !p.isCompleted
            }.take(3)
        }

    val nextRecommendedLesson: ChessLesson
        get() {
            val unlockedIncomplete = CurriculumLevels5To9.allLessons.firstOrNull { lesson ->
                val p = lessonProgressMap[lesson.id]
                lesson.levelNumber >= profile.currentCurriculumLevel && p?.isUnlocked == true && !p.isCompleted
            } ?: CurriculumLevels5To9.allLessons.firstOrNull { lesson ->
                val p = lessonProgressMap[lesson.id]
                p?.isUnlocked == true && !p.isCompleted
            }
            return unlockedIncomplete ?: CurriculumLevels5To9.allLessons.first()
        }
}

class ChessAcademyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ChessAcademyRepository = ChessAcademyRepository(
        ChessAcademyDatabase.getInstance(application).dao()
    )

    val uiState: StateFlow<AcademyUiState> = combine(
        repository.profileFlow,
        repository.lessonProgressFlow,
        repository.conceptMasteryFlow,
        repository.puzzleProgressFlow,
        repository.aiGamesFlow
    ) { profile, lessons, concepts, puzzles, games ->
        AcademyUiState(
            isInitialized = profile != null,
            profile = profile ?: LearnerProfileEntity(),
            lessonProgressMap = lessons.associateBy { it.lessonId },
            conceptMasteryList = concepts,
            puzzleProgressMap = puzzles.associateBy { it.puzzleId },
            aiGames = games
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AcademyUiState()
    )

    private val _currentTab = MutableStateFlow(MainNavTab.HOME)
    val currentTab: StateFlow<MainNavTab> = _currentTab.asStateFlow()

    private val _subScreen = MutableStateFlow(SubScreen.NONE)
    val subScreen: StateFlow<SubScreen> = _subScreen.asStateFlow()

    private val _selectedLesson = MutableStateFlow<ChessLesson>(CurriculumLevels5To9.allLessons.first())
    val selectedLesson: StateFlow<ChessLesson> = _selectedLesson.asStateFlow()

    private val _selectedPuzzleCategory = MutableStateFlow<PuzzleCategory?>(null)
    val selectedPuzzleCategory: StateFlow<PuzzleCategory?> = _selectedPuzzleCategory.asStateFlow()

    private val _activePuzzle = MutableStateFlow<ChessPuzzle>(PuzzleAndAssessmentCatalog.allPuzzles.first())
    val activePuzzle: StateFlow<ChessPuzzle> = _activePuzzle.asStateFlow()

    // AI Gameplay State
    private val _aiDifficulty = MutableStateFlow(AiDifficulty.BEGINNER)
    val aiDifficulty: StateFlow<AiDifficulty> = _aiDifficulty.asStateFlow()

    private val _aiPlayerColor = MutableStateFlow(PieceColor.WHITE)
    val aiPlayerColor: StateFlow<PieceColor> = _aiPlayerColor.asStateFlow()

    private val _aiBoardHistory = MutableStateFlow(listOf(ChessBoardState.initial()))
    val aiBoardHistory: StateFlow<List<ChessBoardState>> = _aiBoardHistory.asStateFlow()

    private val _aiMoveEvaluations = MutableStateFlow<List<MoveEvaluation>>(emptyList())
    val aiMoveEvaluations: StateFlow<List<MoveEvaluation>> = _aiMoveEvaluations.asStateFlow()

    private val _aiCoachHint = MutableStateFlow<Pair<String, CoachArrow?>?>(null)
    val aiCoachHint: StateFlow<Pair<String, CoachArrow?>?> = _aiCoachHint.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureInitialized()
        }
    }

    fun selectTab(tab: MainNavTab) {
        _currentTab.value = tab
        _subScreen.value = SubScreen.NONE
    }

    fun navigateBack(): Boolean {
        return when (_subScreen.value) {
            SubScreen.LESSON_TEST -> {
                _subScreen.value = SubScreen.LESSON_DETAIL
                true
            }
            SubScreen.LESSON_DETAIL,
            SubScreen.SKILL_ASSESSMENT,
            SubScreen.PUZZLE_TRAINER,
            SubScreen.AI_GAMEPLAY,
            SubScreen.BOARD_SANDBOX -> {
                _subScreen.value = SubScreen.NONE
                true
            }
            SubScreen.NONE -> {
                if (_currentTab.value != MainNavTab.HOME) {
                    _currentTab.value = MainNavTab.HOME
                    true
                } else {
                    false
                }
            }
        }
    }

    fun openSkillAssessment() {
        _subScreen.value = SubScreen.SKILL_ASSESSMENT
    }

    fun completeOnboardingDirectBeginner() {
        viewModelScope.launch {
            repository.completeOnboardingWithAssessment(
                diagnosticScore = 0,
                assignedLevel = LearnerLevel.COMPLETE_BEGINNER
            )
            _subScreen.value = SubScreen.NONE
        }
    }

    fun submitSkillAssessment(totalPoints: Int) {
        val assigned = PuzzleAndAssessmentCatalog.determineStartingLevel(totalPoints)
        viewModelScope.launch {
            repository.completeOnboardingWithAssessment(
                diagnosticScore = totalPoints,
                assignedLevel = assigned
            )
            _subScreen.value = SubScreen.NONE
        }
    }

    fun openLesson(lesson: ChessLesson) {
        _selectedLesson.value = lesson
        _subScreen.value = SubScreen.LESSON_DETAIL
    }

    fun startLessonTest(lesson: ChessLesson = _selectedLesson.value) {
        _selectedLesson.value = lesson
        _subScreen.value = SubScreen.LESSON_TEST
    }

    fun markExerciseSolved(lesson: ChessLesson) {
        viewModelScope.launch {
            repository.markPracticalExerciseSolved(lesson)
        }
    }

    fun submitLessonAssessment(
        lesson: ChessLesson,
        scorePercent: Int,
        questionResults: List<Pair<Boolean, String>>,
        onResult: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            val passed = repository.recordLessonAssessment(lesson, scorePercent, questionResults)
            onResult(passed)
        }
    }

    fun openPuzzleTrainer(puzzle: ChessPuzzle? = null, category: PuzzleCategory? = null) {
        _selectedPuzzleCategory.value = category
        val chosen = puzzle ?: PuzzleAndAssessmentCatalog.allPuzzles
            .firstOrNull { category == null || it.category == category }
            ?: PuzzleAndAssessmentCatalog.allPuzzles.first()
        _activePuzzle.value = chosen
        _subScreen.value = SubScreen.PUZZLE_TRAINER
    }

    fun selectPuzzle(puzzle: ChessPuzzle) {
        _activePuzzle.value = puzzle
    }

    fun recordPuzzleResult(
        puzzle: ChessPuzzle,
        solved: Boolean,
        solveTimeSeconds: Int,
        hintsUsed: Int
    ) {
        viewModelScope.launch {
            repository.recordPuzzleAttempt(
                puzzleId = puzzle.id,
                categoryName = puzzle.category.name,
                conceptTag = puzzle.conceptTag,
                puzzleTitle = puzzle.title,
                solved = solved,
                solveTimeSeconds = solveTimeSeconds,
                hintsUsed = hintsUsed
            )
        }
    }

    fun openBoardSandbox() {
        _subScreen.value = SubScreen.BOARD_SANDBOX
    }

    // AI Sparring & Coaching Controls
    fun openAiGameplay(
        difficulty: AiDifficulty = _aiDifficulty.value,
        playerColor: PieceColor = _aiPlayerColor.value
    ) {
        _aiDifficulty.value = difficulty
        _aiPlayerColor.value = playerColor
        _subScreen.value = SubScreen.AI_GAMEPLAY
        startNewAiGame(difficulty, playerColor)
    }

    fun startNewAiGame(
        difficulty: AiDifficulty = _aiDifficulty.value,
        playerColor: PieceColor = _aiPlayerColor.value
    ) {
        _aiDifficulty.value = difficulty
        _aiPlayerColor.value = playerColor
        val initial = ChessBoardState.initial()
        _aiBoardHistory.value = listOf(initial)
        _aiMoveEvaluations.value = emptyList()
        _aiCoachHint.value = null
        _isAiThinking.value = false

        if (playerColor == PieceColor.BLACK) {
            triggerAiReply(initial, difficulty)
        }
    }

    fun makePlayerMoveAgainstAi(move: ChessMove) {
        if (_isAiThinking.value) return
        val currentBoard = _aiBoardHistory.value.last()
        if (currentBoard.turn != _aiPlayerColor.value) return

        val nextBoard = currentBoard.makeMove(move) ?: return
        _aiCoachHint.value = null

        // Evaluate learner's move with Coach AI
        viewModelScope.launch {
            val evaluation = withContext(Dispatchers.Default) {
                ChessCoachAi.analyzeMove(currentBoard, nextBoard.lastMove ?: move)
            }
            _aiMoveEvaluations.value = _aiMoveEvaluations.value + evaluation
            // Feed blunders/mistakes into Adaptive Revision system
            if (evaluation.quality == MoveQuality.BLUNDER || evaluation.quality == MoveQuality.MISTAKE) {
                repository.updateConceptMastery(
                    conceptTag = evaluation.conceptTag,
                    lessonId = "L3_T9",
                    topicTitle = evaluation.conceptTag.replace("_", " ").lowercase()
                        .replaceFirstChar { it.uppercase() },
                    correctDelta = 0,
                    incorrectDelta = 1,
                    mistakeNote = evaluation.coachExplanation
                )
            }
        }

        _aiBoardHistory.value = _aiBoardHistory.value + nextBoard
        val status = nextBoard.gameStatus()
        if (status.isTerminal) {
            saveFinishedAiGame(nextBoard, status)
        } else {
            triggerAiReply(nextBoard, _aiDifficulty.value)
        }
    }

    private fun triggerAiReply(boardAfterPlayer: ChessBoardState, difficulty: AiDifficulty) {
        _isAiThinking.value = true
        viewModelScope.launch {
            delay(280)
            val aiMove = withContext(Dispatchers.Default) {
                ChessCoachAi.selectBestMove(boardAfterPlayer, difficulty)
            }
            if (aiMove != null) {
                val afterAi = boardAfterPlayer.makeMove(aiMove)
                if (afterAi != null) {
                    _aiBoardHistory.value = _aiBoardHistory.value + afterAi
                    val status = afterAi.gameStatus()
                    if (status.isTerminal) {
                        saveFinishedAiGame(afterAi, status)
                    }
                }
            }
            _isAiThinking.value = false
        }
    }

    fun undoAiGameMove() {
        if (_isAiThinking.value) return
        val history = _aiBoardHistory.value
        if (history.size >= 3) {
            _aiBoardHistory.value = history.dropLast(2)
            if (_aiMoveEvaluations.value.isNotEmpty()) {
                _aiMoveEvaluations.value = _aiMoveEvaluations.value.dropLast(1)
            }
            _aiCoachHint.value = null
        } else if (history.size == 2 && _aiPlayerColor.value == PieceColor.WHITE) {
            _aiBoardHistory.value = history.dropLast(1)
            _aiCoachHint.value = null
        }
    }

    fun requestAiCoachHint() {
        val currentBoard = _aiBoardHistory.value.last()
        viewModelScope.launch {
            val hint = withContext(Dispatchers.Default) {
                ChessCoachAi.getCoachHint(currentBoard)
            }
            _aiCoachHint.value = hint
        }
    }

    private fun saveFinishedAiGame(finalBoard: ChessBoardState, status: GameStatus) {
        val evals = _aiMoveEvaluations.value
        val blunders = evals.count { it.quality == MoveQuality.BLUNDER }
        val mistakes = evals.count { it.quality == MoveQuality.MISTAKE }
        val goodOrBest = evals.count {
            it.quality == MoveQuality.BEST || it.quality == MoveQuality.GOOD || it.quality == MoveQuality.BRILLIANT
        }
        val accuracy = if (evals.isEmpty()) 85 else ((goodOrBest * 100f) / evals.size).toInt().coerceIn(25, 100)

        val resultLabel = when (status) {
            GameStatus.CHECKMATE -> if (finalBoard.turn != _aiPlayerColor.value) "WIN" else "LOSS"
            else -> "DRAW"
        }

        viewModelScope.launch {
            repository.recordAiGame(
                difficultyName = _aiDifficulty.value.title,
                playerColorName = _aiPlayerColor.value.displayName(),
                resultLabel = resultLabel,
                movesCount = finalBoard.fullMoveNumber,
                blundersCount = blunders,
                mistakesCount = mistakes,
                accuracyPercent = accuracy,
                pgnText = finalBoard.toPgn(
                    eventName = "Chess Academy vs ${_aiDifficulty.value.title} AI",
                    whiteName = if (_aiPlayerColor.value == PieceColor.WHITE) "Learner" else "Coach AI",
                    blackName = if (_aiPlayerColor.value == PieceColor.BLACK) "Learner" else "Coach AI"
                )
            )
        }
    }

    fun updateSettings(
        boardTheme: BoardTheme? = null,
        showCoordinates: Boolean? = null,
        enableCoachHints: Boolean? = null,
        passingScoreThreshold: Int? = null
    ) {
        viewModelScope.launch {
            repository.updateSettings(
                boardTheme = boardTheme,
                showCoordinates = showCoordinates,
                enableCoachHints = enableCoachHints,
                passingScoreThreshold = passingScoreThreshold
            )
        }
    }

    fun resetProgress() {
        viewModelScope.launch {
            repository.resetAllLearnerProgress()
            _currentTab.value = MainNavTab.HOME
            _subScreen.value = SubScreen.NONE
        }
    }
}
