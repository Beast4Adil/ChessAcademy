package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.chess.BoardTheme
import com.example.curriculum.ChessLesson
import com.example.curriculum.CurriculumLevels5To9
import com.example.ui.AcademyUiState
import com.example.ui.theme.BoardCyanDark
import com.example.ui.theme.BoardCyanLight
import com.example.ui.theme.BoardGreenDark
import com.example.ui.theme.BoardGreenLight
import com.example.ui.theme.BoardWoodDark
import com.example.ui.theme.BoardWoodLight
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.CardSurfaceLightGrey
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenSurface
import com.example.ui.theme.IncorrectRed
import com.example.ui.theme.IncorrectRedSurface
import com.example.ui.theme.MainTextCharcoal
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.PrimaryCyanDark
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SecondaryCyanBorder
import com.example.ui.theme.SecondaryLightCyan
import com.example.ui.theme.SecondaryTextGrey

@Composable
fun ProgressDashboardScreen(
    uiState: AcademyUiState,
    onOpenLesson: (ChessLesson) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("progress_dashboard_screen")
    ) {
        Text(
            text = "Progress & Analytics",
            style = MaterialTheme.typography.headlineLarge,
            color = MainTextCharcoal
        )
        Text(
            text = "Track curriculum mastery, test accuracy, puzzle solve rates, and adaptive revision areas.",
            style = MaterialTheme.typography.bodySmall,
            color = SecondaryTextGrey
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Top 4 KPI Metric Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricSummaryCard(
                label = "Curriculum",
                value = "${uiState.overallCurriculumProgressPercent}%",
                subtitle = "${uiState.completedLessonsCount}/${uiState.totalLessonsCount} Lessons",
                modifier = Modifier.weight(1f)
            )
            MetricSummaryCard(
                label = "Test Accuracy",
                value = "${uiState.averageTestAccuracyPercent}%",
                subtitle = "Pass target: ${uiState.profile.passingScoreThreshold}%",
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricSummaryCard(
                label = "Puzzle Rate",
                value = "${uiState.puzzleSuccessRatePercent}%",
                subtitle = "${uiState.solvedPuzzlesCount}/${uiState.totalPuzzlesCount} Solved",
                modifier = Modifier.weight(1f)
            )
            MetricSummaryCard(
                label = "Current Level",
                value = "Level ${uiState.profile.currentCurriculumLevel}",
                subtitle = uiState.assignedLearnerLevel.title,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Level-by-Level Breakdown Chart
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Curriculum Progress by Level (1–9)",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))

                CurriculumLevels5To9.levelSpecs.forEach { spec ->
                    val lessonsInLvl = CurriculumLevels5To9.lessonsForLevel(spec.levelNumber)
                    val completedInLvl = lessonsInLvl.count {
                        uiState.lessonProgressMap[it.id]?.isCompleted == true
                    }
                    val fraction = if (lessonsInLvl.isEmpty()) 0f else completedInLvl.toFloat() / lessonsInLvl.size

                    Column(modifier = Modifier.padding(vertical = 5.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = spec.title,
                                style = MaterialTheme.typography.bodySmall,
                                color = MainTextCharcoal,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "$completedInLvl / ${lessonsInLvl.size}",
                                style = MaterialTheme.typography.labelSmall,
                                color = PrimaryCyanDark
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { fraction },
                            color = if (completedInLvl == lessonsInLvl.size) CorrectGreen else PrimaryCyan,
                            trackColor = SecondaryLightCyan,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(7.dp)
                                .clip(RoundedCornerShape(999.dp))
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Weakest vs Strongest Chess Topics & Revision Recommendations
        Text(
            text = "Weakest Topics & Revision Recommendations",
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.weakestConcepts.isEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SecondaryLightCyan.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = PrimaryCyanDark)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "No recurring weak concepts detected yet! As you take lesson tests and solve puzzles, any missed tactical or strategic concepts will appear here for spaced-repetition revision.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MainTextCharcoal
                    )
                }
            }
        } else {
            uiState.weakestConcepts.forEach { concept ->
                val targetLesson = CurriculumLevels5To9.getLessonById(concept.lessonId)
                    ?: CurriculumLevels5To9.allLessons.first()
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = IncorrectRedSurface.copy(alpha = 0.65f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onOpenLesson(targetLesson) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = concept.topicTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = MainTextCharcoal
                            )
                            Text(
                                text = "Accuracy: ${concept.accuracyPercent}% • ${concept.incorrectCount} mistakes recorded",
                                style = MaterialTheme.typography.bodySmall,
                                color = IncorrectRed
                            )
                            if (concept.lastMistakeExplanation.isNotBlank()) {
                                Text(
                                    text = concept.lastMistakeExplanation,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SecondaryTextGrey,
                                    maxLines = 2
                                )
                            }
                        }
                        Surface(
                            color = PureWhite,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Revise Now",
                                style = MaterialTheme.typography.labelMedium,
                                color = IncorrectRed,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Strongest Chess Topics",
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.strongestConcepts.isEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Complete lesson assessments with 80%+ accuracy to populate your mastered strengths.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SecondaryTextGrey,
                    modifier = Modifier.padding(14.dp)
                )
            }
        } else {
            uiState.strongestConcepts.forEach { concept ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CorrectGreenSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = concept.topicTitle,
                            style = MaterialTheme.typography.titleSmall,
                            color = MainTextCharcoal
                        )
                        Text(
                            text = "${concept.accuracyPercent}% Mastery (${concept.correctCount}✓)",
                            style = MaterialTheme.typography.labelMedium,
                            color = CorrectGreen
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // AI Opponent Match Results
        Text(
            text = "AI Opponent Match Results (${uiState.aiGames.size} Played)",
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.aiGames.isEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "No completed AI matches yet. Visit Practice -> Play vs. Coaching AI to test your skills.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SecondaryTextGrey,
                    modifier = Modifier.padding(14.dp)
                )
            }
        } else {
            val wins = uiState.aiGames.count { it.resultLabel == "WIN" }
            val draws = uiState.aiGames.count { it.resultLabel == "DRAW" }
            val losses = uiState.aiGames.count { it.resultLabel == "LOSS" }

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Record: $wins Wins • $draws Draws • $losses Losses",
                        style = MaterialTheme.typography.titleSmall,
                        color = PrimaryCyanDark
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    uiState.aiGames.take(5).forEach { game ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "vs ${game.difficultyName} AI (${game.playerColorName})",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "${game.resultLabel} • ${game.accuracyPercent}% Acc (${game.blundersCount} Blunders)",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (game.resultLabel == "WIN") CorrectGreen else SecondaryTextGrey
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun MetricSummaryCard(
    label: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
        modifier = modifier.border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = SecondaryTextGrey
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineLarge,
                color = PrimaryCyanDark
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MainTextCharcoal
            )
        }
    }
}

@Composable
fun ProfileSettingsScreen(
    uiState: AcademyUiState,
    onRetakeSkillAssessment: () -> Unit,
    onUpdateBoardTheme: (BoardTheme) -> Unit,
    onToggleCoordinates: (Boolean) -> Unit,
    onToggleCoachHints: (Boolean) -> Unit,
    onUpdatePassingThreshold: (Int) -> Unit,
    onResetProgress: () -> Unit
) {
    val scrollState = rememberScrollState()
    var showResetConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("profile_settings_screen")
    ) {
        Text(
            text = "Learner Profile & Academy Settings",
            style = MaterialTheme.typography.headlineLarge,
            color = MainTextCharcoal
        )
        Text(
            text = "Single-learner offline academy configuration and board customization.",
            style = MaterialTheme.typography.bodySmall,
            color = SecondaryTextGrey
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Learner Status Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SecondaryLightCyan.copy(alpha = 0.55f)),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SecondaryCyanBorder, RoundedCornerShape(18.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SINGLE LEARNER PROFILE",
                    style = MaterialTheme.typography.labelSmall,
                    color = PrimaryCyanDark
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Assigned Tier: ${uiState.assignedLearnerLevel.title}",
                    style = MaterialTheme.typography.titleLarge,
                    color = MainTextCharcoal
                )
                Text(
                    text = "Active Curriculum Level: Level ${uiState.profile.currentCurriculumLevel} • Diagnostic Score: ${uiState.profile.diagnosticScore}/100",
                    style = MaterialTheme.typography.bodySmall,
                    color = SecondaryTextGrey
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onRetakeSkillAssessment,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("retake_skill_assessment_button")
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = PrimaryCyanDark)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Retake Initial Skill Assessment", color = PrimaryCyanDark)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selectable Board Theme (Cyan-White, Classic Wood, Tournament Green)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Palette, contentDescription = null, tint = PrimaryCyanDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Chessboard Visual Theme",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))

                BoardTheme.entries.forEach { theme ->
                    val isSelected = uiState.boardTheme == theme
                    val (lightSq, darkSq) = when (theme) {
                        BoardTheme.CYAN_WHITE -> BoardCyanLight to BoardCyanDark
                        BoardTheme.CLASSIC_WOOD -> BoardWoodLight to BoardWoodDark
                        BoardTheme.TOURNAMENT_GREEN -> BoardGreenLight to BoardGreenDark
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) SecondaryLightCyan else PureWhite)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) PrimaryCyan else CardBorderSubtle,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onUpdateBoardTheme(theme) }
                            .padding(12.dp)
                            .testTag("theme_option_${theme.name}"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = theme.displayName,
                                style = MaterialTheme.typography.titleSmall,
                                color = MainTextCharcoal
                            )
                            Text(
                                text = theme.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = SecondaryTextGrey
                            )
                        }
                        Row {
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .background(lightSq, RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp))
                                    .border(1.dp, CardBorderSubtle, RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp))
                            )
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .background(darkSq, RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp))
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Board & Learning Preferences
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurfaceLightGrey),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Board & Mastery Preferences",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Show Board Coordinates (a–h, 1–8)", style = MaterialTheme.typography.bodyMedium)
                        Text("Displays algebraic file and rank labels on the board", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = uiState.profile.showCoordinates,
                        onCheckedChange = onToggleCoordinates,
                        colors = SwitchDefaults.colors(checkedThumbColor = PureWhite, checkedTrackColor = PrimaryCyan)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enable Coach AI Hints & Arrows", style = MaterialTheme.typography.bodyMedium)
                        Text("Allows requesting tactical coach arrows during AI sparring", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = uiState.profile.enableCoachHints,
                        onCheckedChange = onToggleCoachHints,
                        colors = SwitchDefaults.colors(checkedThumbColor = PureWhite, checkedTrackColor = PrimaryCyan)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Lesson Passing Score Threshold (Default 80%):", style = MaterialTheme.typography.bodyMedium)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    listOf(60, 80, 100).forEach { pct ->
                        FilterChip(
                            selected = uiState.profile.passingScoreThreshold == pct,
                            onClick = { onUpdatePassingThreshold(pct) },
                            label = { Text("$pct% Pass") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryCyan,
                                selectedLabelColor = PureWhite
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Danger Zone: Reset Local Progress
        OutlinedButton(
            onClick = { showResetConfirm = true },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("reset_progress_button")
        ) {
            Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = IncorrectRed)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Reset All Local Learning Progress", color = IncorrectRed, fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset All Progress?") },
            text = {
                Text("This will clear your local SQLite lesson progress, quiz scores, puzzle history, and AI game records, returning Chess Academy to initial setup.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirm = false
                        onResetProgress()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IncorrectRed)
                ) {
                    Text("Reset Everything", color = PureWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
