package com.example.curriculum

/**
 * Provides the Initial Skill Assessment (for personalized learner onboarding)
 * and the 9-Category Verified Chess Puzzle Catalog.
 */
object PuzzleAndAssessmentCatalog {

    val diagnosticQuestions = listOf(
        DiagnosticQuestion(
            id = 1,
            categoryLabel = "Board & Piece Mechanics",
            prompt = "Which chess piece moves in an 'L' shape and is the only piece allowed to jump over other pieces?",
            fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
            options = listOf("The Knight", "The Bishop", "The Rook", "The Queen"),
            correctIndex = 0,
            explanation = "The Knight moves two squares in one cardinal direction and one square perpendicular, jumping over any intervening pieces.",
            weightPoints = 10
        ),
        DiagnosticQuestion(
            id = 2,
            categoryLabel = "Checkmate vs Stalemate",
            prompt = "If it is Black's turn, Black's King is NOT in check, and Black has zero legal moves available, what is the result?",
            fen = "7k/5K2/6Q1/8/8/8/8/8 b - - 0 1",
            options = listOf("Draw by Stalemate", "White wins by Checkmate", "Black loses a turn", "White must undo the last move"),
            correctIndex = 0,
            explanation = "When a player is NOT in check and has no legal moves, the game immediately ends in a Draw by Stalemate.",
            weightPoints = 15
        ),
        DiagnosticQuestion(
            id = 3,
            categoryLabel = "Special Rules (En Passant & Castling)",
            prompt = "When White plays kingside castling (O-O), where do the White King and Kingside Rook land?",
            fen = "r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1",
            options = listOf("King on g1, Rook on f1", "King on h1, Rook on e1", "King on f1, Rook on g1", "King on c1, Rook on d1"),
            correctIndex = 0,
            explanation = "In kingside castling (O-O), the White King moves two squares from e1 to g1, and the h1-Rook jumps over to f1.",
            weightPoints = 15
        ),
        DiagnosticQuestion(
            id = 4,
            categoryLabel = "Tactical Pattern Recognition",
            prompt = "White to move: 1.Rd8# delivers an immediate win. Which tactical pattern does this illustrate?",
            fen = "6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1",
            options = listOf("Back-Rank Checkmate", "Smothered Mate", "En Passant Capture", "Greek Gift Sacrifice"),
            correctIndex = 0,
            explanation = "Black's King on g8 is trapped behind its own unmoved f7, g7, and h7 pawns without 'Luft', falling to a Back-Rank Checkmate.",
            weightPoints = 20
        ),
        DiagnosticQuestion(
            id = 5,
            categoryLabel = "Opening & Middlegame Strategy",
            prompt = "In the Sicilian Defense (1.e4 c5), what is Black's primary strategic idea behind 1...c5?",
            fen = "rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2",
            options = listOf(
                "Control the d4 square asymmetrically and trade a flank c-pawn for White's central d-pawn",
                "Prepare to castle queenside on Move 3",
                "Give up the center completely so the a8-Rook can advance",
                "Force an immediate draw by threefold repetition"
            ),
            correctIndex = 0,
            explanation = "1...c5 fights for d4 from the flank so that after d4 cxd4, Black trades a flank pawn for a central pawn and opens the c-file.",
            weightPoints = 20
        ),
        DiagnosticQuestion(
            id = 6,
            categoryLabel = "Endgame Mastery",
            prompt = "In a Rook + Pawn vs Rook endgame where the attacking pawn is on the 7th rank and its King stands in front of it, what is the famous winning method called?",
            fen = "1K1k4/1P6/8/8/8/8/r7/2R5 w - - 0 1",
            options = listOf(
                "The Lucena Position ('Building a Bridge' with Rc4!)",
                "Scholar's Mate",
                "The Fool's Mate",
                "Insufficient Material Draw"
            ),
            correctIndex = 0,
            explanation = "The Lucena Position is won by placing the Rook on the 4th rank (Rc4!) so it can later shield the King from vertical checks ('Building a Bridge').",
            weightPoints = 20
        )
    )

    fun determineStartingLevel(totalPoints: Int): LearnerLevel = when {
        totalPoints < 25 -> LearnerLevel.COMPLETE_BEGINNER
        totalPoints in 25..54 -> LearnerLevel.BEGINNER
        totalPoints in 55..79 -> LearnerLevel.INTERMEDIATE
        else -> LearnerLevel.ADVANCED
    }

    val allPuzzles: List<ChessPuzzle> = listOf(
        // 1. MATE IN 1
        ChessPuzzle(
            id = "PUZ_M1_01",
            title = "Back-Rank Strike",
            category = PuzzleCategory.MATE_IN_1,
            difficultyRating = 800,
            fen = "6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1",
            solutionMovesUci = listOf("d1d8"),
            hintText = "Notice that Black's pawns on f7, g7, and h7 trap their own King on the 8th rank.",
            winningIdeaExplanation = "1.Rd8# is Back-Rank Checkmate! Black's King has no escape squares because its own unadvanced pawns block the 7th rank.",
            conceptTag = "BACK_RANK_MATE"
        ),
        ChessPuzzle(
            id = "PUZ_M1_02",
            title = "Arabian Corner Net",
            category = PuzzleCategory.MATE_IN_1,
            difficultyRating = 900,
            fen = "7k/7R/5N2/8/8/8/8/6K1 w - - 0 1",
            solutionMovesUci = listOf("h7h8"),
            hintText = "Your Knight on f6 both defends the h8 square and covers the g8 escape square.",
            winningIdeaExplanation = "1.Rh8# executes the classic Arabian Mate! The Knight on f6 protects the Rook on h8 and controls the escape square g8.",
            conceptTag = "ARABIAN_MATE"
        ),
        ChessPuzzle(
            id = "PUZ_M1_03",
            title = "Queen & King Support Mate",
            category = PuzzleCategory.MATE_IN_1,
            difficultyRating = 850,
            fen = "7k/5K2/8/6Q1/8/8/8/8 w - - 0 1",
            solutionMovesUci = listOf("g5g7"),
            hintText = "Bring the Queen directly adjacent to the cornered King on a square protected by your King on f7.",
            winningIdeaExplanation = "1.Qg7# delivers checkmate with the Queen protected by the White King on f7 (whereas 1.Qg6?? would have been Stalemate!).",
            conceptTag = "KQ_VS_K"
        ),

        // 2. MATE IN 2
        ChessPuzzle(
            id = "PUZ_M2_01",
            title = "Double Rook Corridor",
            category = PuzzleCategory.MATE_IN_2,
            difficultyRating = 1150,
            fen = "6k1/R7/1R6/8/8/8/8/6K1 w - - 0 1",
            solutionMovesUci = listOf("b6b8"),
            hintText = "Use your b6-Rook to invade the 8th rank while your a7-Rook cuts off the 7th rank.",
            winningIdeaExplanation = "1.Rb8# (or forcing mate along the 7th/8th ranks) uses the 'Lawnmower' coordination of two Rooks controlling adjacent ranks.",
            conceptTag = "PIECE_COORDINATION"
        ),
        ChessPuzzle(
            id = "PUZ_M2_02",
            title = "Boden's Criss-Cross Bishops",
            category = PuzzleCategory.MATE_IN_2,
            difficultyRating = 1250,
            fen = "2kr4/8/B7/8/8/5B2/8/6K1 w - - 0 1",
            solutionMovesUci = listOf("a6b7"),
            hintText = "Your f3-Bishop already slices the h1–a8 diagonal. Use your light-squared Bishop to slice the b7–c8 squares!",
            winningIdeaExplanation = "1.Bb7+ Kb8 (forced, as the f3-Bishop covers d7/c6) creates a criss-cross Bishop net along adjacent diagonals.",
            conceptTag = "BODEN_MATE"
        ),

        // 3. MATE IN 3
        ChessPuzzle(
            id = "PUZ_M3_01",
            title = "Seventh-Rank Windmill Sweep",
            category = PuzzleCategory.MATE_IN_3,
            difficultyRating = 1450,
            fen = "6k1/5Rpp/8/8/8/2B5/8/6K1 w - - 0 1",
            solutionMovesUci = listOf("f7g7"),
            hintText = "Look at the alignment of your c3-Bishop and f7-Rook aimed directly at g7 and the Black King on g8.",
            winningIdeaExplanation = "1.Rxg7+! Kh8 triggers a lethal Windmill (discovered check from the c3-Bishop followed by repeated Rook checks).",
            conceptTag = "WINDMILL"
        ),
        ChessPuzzle(
            id = "PUZ_M3_02",
            title = "Smothered Corner Pressure",
            category = PuzzleCategory.MATE_IN_3,
            difficultyRating = 1500,
            fen = "6rk/5Npp/8/8/8/8/8/6K1 w - - 0 1",
            solutionMovesUci = listOf("f7h6"),
            hintText = "Look for a double check or Knight jump that exploits Black's boxed-in King on h8.",
            winningIdeaExplanation = "1.Nh6! threatens Nf7# Smothered Mate because Black's g8-Rook is pinned or hems in its own King.",
            conceptTag = "SMOTHERED_MATE"
        ),

        // 4. TACTICAL PUZZLES
        ChessPuzzle(
            id = "PUZ_TAC_01",
            title = "Absolute Pin Exploitation",
            category = PuzzleCategory.TACTICAL,
            difficultyRating = 1100,
            fen = "4k3/4n3/8/8/8/8/4R3/4K3 w - - 0 1",
            solutionMovesUci = listOf("e2e7"),
            hintText = "Notice the Black Knight on e7 stands directly in front of the Black King.",
            winningIdeaExplanation = "1.Rxe7+ wins the Knight cleanly and forces the Black King into a passive defense.",
            conceptTag = "PIN"
        ),
        ChessPuzzle(
            id = "PUZ_TAC_02",
            title = "Discovered Check Royal Strike",
            category = PuzzleCategory.TACTICAL,
            difficultyRating = 1300,
            fen = "4k3/8/8/3q4/4N3/8/4R3/4K3 w - - 0 1",
            solutionMovesUci = listOf("e4f6"),
            hintText = "Your Knight on e4 blocks your e2-Rook's check against the Black King on e8. Where can the Knight jump to give check AND attack?",
            winningIdeaExplanation = "1.Nf6+! is a Double Check and Fork! The Black King is forced to move, and White wins the Queen on the next turn.",
            conceptTag = "DISCOVERED_CHECK"
        ),
        ChessPuzzle(
            id = "PUZ_TAC_03",
            title = "File Skewer",
            category = PuzzleCategory.TACTICAL,
            difficultyRating = 1200,
            fen = "4k3/8/4q3/8/8/8/4R3/4K3 w - - 0 1",
            solutionMovesUci = listOf("e2e6"),
            hintText = "Black's Queen on e6 is lined up directly with the Black King on e8 along the open e-file.",
            winningIdeaExplanation = "1.Rxe6+ captures the pinned Queen with check! The Queen could not legally move off the e-file because of the absolute pin to the e8-King.",
            conceptTag = "SKEWER"
        ),

        // 5. DEFENSIVE PUZZLES
        ChessPuzzle(
            id = "PUZ_DEF_01",
            title = "Refuting Scholar's Mate",
            category = PuzzleCategory.DEFENSIVE,
            difficultyRating = 1050,
            fen = "r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 3 3",
            solutionMovesUci = listOf("g7g6"),
            hintText = "White threatens 4.Qxf7# Scholar's Mate. Block the Queen's diagonal to f7 while attacking the Queen!",
            winningIdeaExplanation = "3...g6! cleanly blunts White's Queen attack on f7 and forces the Queen to retreat, after which Black develops ...Nf6 with tempo.",
            conceptTag = "OPENING_MISTAKES"
        ),
        ChessPuzzle(
            id = "PUZ_DEF_02",
            title = "Creating Luft Against Back-Rank Mate",
            category = PuzzleCategory.DEFENSIVE,
            difficultyRating = 1150,
            fen = "3r2k1/5ppp/8/8/8/8/5PPP/6K1 w - - 0 1",
            solutionMovesUci = listOf("h2h3"),
            hintText = "Black threatens 1...Rd1# Back-Rank Checkmate. Give your King a breathing square!",
            winningIdeaExplanation = "1.h3! creates 'Luft' (breathing space on h2) for the White King, neutralizing all back-rank mate threats permanently.",
            conceptTag = "PROPHYLAXIS"
        ),

        // 6. ENDGAME PUZZLES
        ChessPuzzle(
            id = "PUZ_END_01",
            title = "Lucena Bridge Setup",
            category = PuzzleCategory.ENDGAME,
            difficultyRating = 1550,
            fen = "1K1k4/1P6/8/8/8/8/r7/2R5 w - - 0 1",
            solutionMovesUci = listOf("c1c4"),
            hintText = "Before marching your King out from b8, place your Rook on the 4th rank so it can block future vertical checks.",
            winningIdeaExplanation = "1.Rc4! prepares 'Building a Bridge': when the White King walks out (Ka7 -> Kb6 -> Kc6) and Black checks vertically, White blocks with Rb4!",
            conceptTag = "LUCENA_POSITION"
        ),
        ChessPuzzle(
            id = "PUZ_END_02",
            title = "Philidor Third-Rank Barrier",
            category = PuzzleCategory.ENDGAME,
            difficultyRating = 1500,
            fen = "4k3/8/4p3/4K3/8/8/8/2r4R w - - 0 1",
            solutionMovesUci = listOf("h1h3"),
            hintText = "Prevent the Black King from ever stepping onto the 6th rank (3rd rank from Black's side) by placing your Rook on that rank!",
            winningIdeaExplanation = "1.Rh3! establishes the Philidor 3rd-Rank Defense. Only if Black pushes ...e5-e4 does the Rook drop to the 8th rank to give checks from behind.",
            conceptTag = "PHILIDOR_POSITION"
        ),
        ChessPuzzle(
            id = "PUZ_END_03",
            title = "Three-Pawn Breakthrough",
            category = PuzzleCategory.ENDGAME,
            difficultyRating = 1400,
            fen = "8/ppp5/8/PPP5/8/8/8/4K2k w - - 0 1",
            solutionMovesUci = listOf("b5b6"),
            hintText = "Strike the middle of Black's three pawns so whichever pawn captures, one of your flank pawns breaks through!",
            winningIdeaExplanation = "1.b6! sacrifices the b-pawn: if 1...cxb6 then 2.a6! bxa6 3.c6 promotes; if 1...axb6 then 2.c6! bxc6 3.a6 promotes!",
            conceptTag = "PAWN_BREAKTHROUGHS"
        ),

        // 7. OPENING PUZZLES
        ChessPuzzle(
            id = "PUZ_OPN_01",
            title = "Italian Center Strike",
            category = PuzzleCategory.OPENING,
            difficultyRating = 1100,
            fen = "r1bqk1nr/pppp1ppp/2n5/2b1p3/2B1P3/2P2N2/PP1P1PPP/RNBQK2R w KQkq - 1 4",
            solutionMovesUci = listOf("d2d4"),
            hintText = "Why did White play 3.Bc4 and 4.c3? Use the c3-pawn to support an immediate central break with tempo against the c5-Bishop!",
            winningIdeaExplanation = "4.d4! fulfills the main strategic idea of the Giuoco Piano (Italian Game), seizing the center with tempo against Black's c5-Bishop.",
            conceptTag = "ITALIAN_GAME"
        ),
        ChessPuzzle(
            id = "PUZ_OPN_02",
            title = "Caro-Kann Light-Square Development",
            category = PuzzleCategory.OPENING,
            difficultyRating = 1150,
            fen = "rnbqkbnr/pp2pppp/2p5/3pP3/3P4/8/PPP2PPP/RNBQKBNR b KQkq - 0 3",
            solutionMovesUci = listOf("c8f5"),
            hintText = "In the Caro-Kann Advance Variation, develop your light-squared c8-Bishop outside the pawn chain BEFORE playing ...e6!",
            winningIdeaExplanation = "3...Bf5! places Black's light-squared Bishop on an active diagonal outside the pawn chain before playing ...e6.",
            conceptTag = "CARO_KANN"
        ),

        // 8. POSITIONAL PUZZLES
        ChessPuzzle(
            id = "PUZ_POS_01",
            title = "Anchoring the d5 Outpost",
            category = PuzzleCategory.POSITIONAL,
            difficultyRating = 1350,
            fen = "4k3/ppp2ppp/3p4/4p3/4P3/2N5/PPP2PPP/4K3 w - - 0 1",
            solutionMovesUci = listOf("c3d5"),
            hintText = "Look at the d5 square in Black's camp: Black's d6 and e5 pawns can never attack d5, and no c7-pawn push can dislodge a piece quickly.",
            winningIdeaExplanation = "1.Nd5! plants the Knight on a dominant central outpost supported by the e4-pawn and pressuring c7.",
            conceptTag = "OUTPOSTS"
        ),
        ChessPuzzle(
            id = "PUZ_POS_02",
            title = "Seizing the Open d-File & 7th Rank",
            category = PuzzleCategory.POSITIONAL,
            difficultyRating = 1300,
            fen = "4k3/ppp2ppp/8/8/8/8/PPP2PPP/3R2K1 w - - 0 1",
            solutionMovesUci = listOf("d1d7"),
            hintText = "The d-file is completely open. Invade the 7th rank to attack Black's unadvanced pawns from the side!",
            winningIdeaExplanation = "1.Rd7! invades the 7th rank along the open d-file, tying down the Black King and attacking both c7 and f7.",
            conceptTag = "OPEN_FILES"
        ),

        // 9. ADVANCED CALCULATION PUZZLES
        ChessPuzzle(
            id = "PUZ_CAL_01",
            title = "Queen-Fork Geometry",
            category = PuzzleCategory.CALCULATION,
            difficultyRating = 1600,
            fen = "4k3/8/8/1r6/8/8/8/3QK3 w - - 0 1",
            solutionMovesUci = listOf("d1a4"),
            hintText = "Find the single geometric square from which the White Queen gives check to the e8-King along the diagonal AND attacks the b5-Rook along the rank/file!",
            winningIdeaExplanation = "1.Qa4+! is a classic geometric Queen double attack: checking the King on the a4–e8 diagonal while attacking the undefended Rook on b5.",
            conceptTag = "DOUBLE_ATTACK"
        ),
        ChessPuzzle(
            id = "PUZ_CAL_02",
            title = "Carlsbad Minority Lever",
            category = PuzzleCategory.CALCULATION,
            difficultyRating = 1650,
            fen = "4k3/pp3ppp/2p5/3p4/1P6/8/P4PPP/4K3 w - - 0 1",
            solutionMovesUci = listOf("b4b5"),
            hintText = "Use your queenside pawn minority to strike Black's c6-pawn and create a permanent backward or isolated pawn target.",
            winningIdeaExplanation = "1.b5! initiates the Minority Attack breakthrough, forcing a structural weakness on c6 or d5 that White can besiege on the open file.",
            conceptTag = "CREATING_WEAKNESSES"
        )
    )
}
