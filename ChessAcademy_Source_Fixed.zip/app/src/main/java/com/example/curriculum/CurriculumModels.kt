package com.example.curriculum

enum class LearnerLevel(
    val title: String,
    val startCurriculumLevel: Int,
    val badgeLabel: String,
    val summary: String
) {
    COMPLETE_BEGINNER(
        title = "Complete Beginner",
        startCurriculumLevel = 1,
        badgeLabel = "Level 1 • Foundations",
        summary = "Starts from the very beginning: the 8×8 board, how every piece moves, captures, check, and checkmate."
    ),
    BEGINNER(
        title = "Beginner",
        startCurriculumLevel = 2,
        badgeLabel = "Level 2–3 • Rules & Strategy",
        summary = "Masters special rules (castling, en passant, promotion, notation) and core opening/center strategy."
    ),
    INTERMEDIATE(
        title = "Intermediate",
        startCurriculumLevel = 4,
        badgeLabel = "Level 4–6 • Tactics & Middlegame",
        summary = "Focuses on tactical combinations, major opening systems, and positional middlegame planning."
    ),
    ADVANCED(
        title = "Advanced",
        startCurriculumLevel = 7,
        badgeLabel = "Level 7–9 • Endgames & Mastery",
        summary = "Targets theoretical endgames, deep calculation trees, positional sacrifices, and master-level concepts."
    )
}

data class CurriculumLevelSpec(
    val levelNumber: Int,
    val title: String,
    val subtitle: String,
    val overview: String,
    val masteryNote: String? = null
)

data class LessonStepExample(
    val stepNumber: Int,
    val title: String,
    val description: String,
    val fen: String,
    val highlightMoveUci: String? = null
)

enum class QuestionType(val label: String) {
    MULTIPLE_CHOICE("Multiple Choice"),
    TRUE_FALSE("True or False"),
    IDENTIFY_MOVE("Identify the Correct Move"),
    FIND_TACTIC("Find the Tactical Pattern"),
    BOARD_MOVE("Interactive Board Move"),
    FIND_CHECKMATE("Find Checkmate"),
    IDENTIFY_ILLEGAL_MOVE("Identify Illegal Move"),
    BEST_STRATEGIC_MOVE("Choose Best Strategic Move")
}

data class AssessmentQuestion(
    val id: String,
    val lessonId: String,
    val questionNumber: Int,
    val type: QuestionType,
    val prompt: String,
    val fenPosition: String,
    val options: List<String>,
    val correctOptionIndex: Int,
    val requiredBoardMoveUci: String? = null,
    val correctExplanation: String,
    val incorrectExplanation: String,
    val conceptTag: String,
    val difficulty: Int
)

/**
 * Complete 10-part lesson structure required for every topic in the 9-level curriculum:
 * 1. Title
 * 2. Learning Objective
 * 3. Simple Explanation
 * 4. Visual Demonstration
 * 5. Interactive Chessboard
 * 6. Step-by-Step Example
 * 7. Common Mistakes
 * 8. Practical Exercise
 * 9. Short Lesson Summary
 * 10. 5-Question Mastery Test
 */
data class ChessLesson(
    val id: String,
    val levelNumber: Int,
    val orderInLevel: Int,
    val title: String,
    val conceptTag: String,
    val learningObjective: String,
    val simpleExplanation: String,
    val visualDemoFen: String,
    val visualDemoCaption: String,
    val interactiveBoardFen: String,
    val interactiveInstruction: String,
    val interactiveTargetMoveUci: String,
    val stepByStepExamples: List<LessonStepExample>,
    val commonMistakes: List<String>,
    val practicalExercisePrompt: String,
    val practicalExerciseFen: String,
    val practicalExerciseSolutionUci: String,
    val shortSummary: String,
    val questions: List<AssessmentQuestion>
)

enum class PuzzleCategory(val title: String, val subtitle: String) {
    MATE_IN_1("Mate in 1", "Spot immediate single-move checkmates"),
    MATE_IN_2("Mate in 2", "Calculate forcing two-move mating nets"),
    MATE_IN_3("Mate in 3", "Deep three-move checkmate calculation"),
    TACTICAL("Tactical Puzzles", "Win material with forks, pins, and skewers"),
    DEFENSIVE("Defensive Puzzles", "Parry threats and save critical positions"),
    ENDGAME("Endgame Puzzles", "Convert pawn, rook, and opposition endgames"),
    OPENING("Opening Puzzles", "Punish early opening mistakes and traps"),
    POSITIONAL("Positional Puzzles", "Find outposts, prophylaxis, and weak squares"),
    CALCULATION("Advanced Calculation", "Multi-move candidate calculation and sacrifices")
}

data class ChessPuzzle(
    val id: String,
    val title: String,
    val category: PuzzleCategory,
    val difficultyRating: Int,
    val fen: String,
    val solutionMovesUci: List<String>,
    val hintText: String,
    val winningIdeaExplanation: String,
    val conceptTag: String
)

data class DiagnosticQuestion(
    val id: Int,
    val categoryLabel: String,
    val prompt: String,
    val fen: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val weightPoints: Int
)
