package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "learner_profile")
data class LearnerProfileEntity(
    @PrimaryKey val id: Int = 1,
    val hasCompletedOnboarding: Boolean = false,
    val diagnosticScore: Int = 0,
    val assignedLevelName: String = "COMPLETE_BEGINNER",
    val currentCurriculumLevel: Int = 1,
    val streakDays: Int = 1,
    val lastStudyDayEpoch: Long = 0L,
    val boardThemeName: String = "CYAN_WHITE",
    val showCoordinates: Boolean = true,
    val enableCoachHints: Boolean = true,
    val passingScoreThreshold: Int = 80
)

@Entity(tableName = "lesson_progress")
data class LessonProgressEntity(
    @PrimaryKey val lessonId: String,
    val levelNumber: Int,
    val orderInLevel: Int,
    val isUnlocked: Boolean = false,
    val isCompleted: Boolean = false,
    val bestScorePercent: Int = 0,
    val lastScorePercent: Int = 0,
    val attemptsCount: Int = 0,
    val exerciseSolved: Boolean = false,
    val lastCompletedTimestamp: Long = 0L
)

@Entity(tableName = "concept_mastery")
data class ConceptMasteryEntity(
    @PrimaryKey val conceptTag: String,
    val lessonId: String,
    val topicTitle: String,
    val correctCount: Int = 0,
    val incorrectCount: Int = 0,
    val intervalDays: Int = 1,
    val easeFactor: Float = 2.5f,
    val nextReviewTimestamp: Long = 0L,
    val lastMistakeExplanation: String = ""
) {
    val totalAttempts: Int get() = correctCount + incorrectCount
    val accuracyPercent: Int
        get() = if (totalAttempts == 0) 100 else ((correctCount * 100f) / totalAttempts).toInt()
    val needsRevision: Boolean
        get() = incorrectCount > 0 && (accuracyPercent < 75 || System.currentTimeMillis() >= nextReviewTimestamp)
}

@Entity(tableName = "puzzle_progress")
data class PuzzleProgressEntity(
    @PrimaryKey val puzzleId: String,
    val categoryName: String,
    val isSolved: Boolean = false,
    val attempts: Int = 0,
    val bestSolveTimeSeconds: Int = 0,
    val hintsUsed: Int = 0,
    val lastAttemptTimestamp: Long = 0L
)

@Entity(tableName = "ai_game_records")
data class AiGameRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val difficultyName: String,
    val playerColorName: String,
    val resultLabel: String, // "WIN", "LOSS", "DRAW"
    val movesCount: Int,
    val blundersCount: Int,
    val mistakesCount: Int,
    val accuracyPercent: Int,
    val pgnText: String,
    val timestamp: Long = System.currentTimeMillis()
)
