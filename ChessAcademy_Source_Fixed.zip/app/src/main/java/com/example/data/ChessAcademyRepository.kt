package com.example.data

import com.example.chess.BoardTheme
import com.example.curriculum.ChessLesson
import com.example.curriculum.CurriculumLevels5To9
import com.example.curriculum.LearnerLevel
import kotlinx.coroutines.flow.Flow
import kotlin.math.max
import kotlin.math.min

/**
 * Repository abstracting Room SQLite access and implementing:
 * - Initial skill assessment placement & level unlocking
 * - Performance-gated lesson unlocking (default 80% pass score)
 * - Adaptive SM-2 spaced repetition & weak-concept tracking
 */
class ChessAcademyRepository(private val dao: ChessAcademyDao) {

    val profileFlow: Flow<LearnerProfileEntity?> = dao.observeProfile()
    val lessonProgressFlow: Flow<List<LessonProgressEntity>> = dao.observeAllLessonProgress()
    val conceptMasteryFlow: Flow<List<ConceptMasteryEntity>> = dao.observeAllConceptMastery()
    val puzzleProgressFlow: Flow<List<PuzzleProgressEntity>> = dao.observeAllPuzzleProgress()
    val aiGamesFlow: Flow<List<AiGameRecordEntity>> = dao.observeAllAiGames()

    suspend fun ensureInitialized() {
        val currentProfile = dao.getProfileOnce()
        if (currentProfile == null) {
            val todayEpoch = System.currentTimeMillis() / (24L * 3600_000L)
            dao.upsertProfile(
                LearnerProfileEntity(
                    id = 1,
                    hasCompletedOnboarding = false,
                    lastStudyDayEpoch = todayEpoch
                )
            )
            seedInitialLessonProgress(unlockedUpToLevel = 1)
        } else {
            val firstLesson = dao.getLessonProgressOnce("L1_T1")
            if (firstLesson == null) {
                seedInitialLessonProgress(unlockedUpToLevel = currentProfile.currentCurriculumLevel)
            }
            updateStreakIfNeeded(currentProfile)
        }
    }

    private suspend fun seedInitialLessonProgress(unlockedUpToLevel: Int) {
        val allLessons = CurriculumLevels5To9.allLessons
        val existingMap = mutableMapOf<String, LessonProgressEntity>()
        for (lesson in allLessons) {
            val existing = dao.getLessonProgressOnce(lesson.id)
            if (existing != null) existingMap[lesson.id] = existing
        }

        val entities = allLessons.map { lesson ->
            val prev = existingMap[lesson.id]
            val shouldUnlock = (lesson.levelNumber < unlockedUpToLevel) ||
                (lesson.levelNumber == unlockedUpToLevel && lesson.orderInLevel == 1) ||
                (lesson.levelNumber == 1 && lesson.orderInLevel == 1) ||
                (prev?.isUnlocked == true)

            prev?.copy(isUnlocked = shouldUnlock) ?: LessonProgressEntity(
                lessonId = lesson.id,
                levelNumber = lesson.levelNumber,
                orderInLevel = lesson.orderInLevel,
                isUnlocked = shouldUnlock
            )
        }
        dao.upsertAllLessonProgress(entities)
    }

    private suspend fun updateStreakIfNeeded(profile: LearnerProfileEntity) {
        val todayEpoch = System.currentTimeMillis() / (24L * 3600_000L)
        if (todayEpoch > profile.lastStudyDayEpoch) {
            val newStreak = if (todayEpoch == profile.lastStudyDayEpoch + 1L) {
                profile.streakDays + 1
            } else {
                1
            }
            dao.upsertProfile(
                profile.copy(
                    streakDays = newStreak,
                    lastStudyDayEpoch = todayEpoch
                )
            )
        }
    }

    suspend fun completeOnboardingWithAssessment(
        diagnosticScore: Int,
        assignedLevel: LearnerLevel
    ) {
        val current = dao.getProfileOnce() ?: LearnerProfileEntity()
        val startLvl = assignedLevel.startCurriculumLevel
        dao.upsertProfile(
            current.copy(
                hasCompletedOnboarding = true,
                diagnosticScore = diagnosticScore,
                assignedLevelName = assignedLevel.name,
                currentCurriculumLevel = startLvl
            )
        )
        seedInitialLessonProgress(unlockedUpToLevel = startLvl)
    }

    suspend fun markPracticalExerciseSolved(lesson: ChessLesson) {
        val existing = dao.getLessonProgressOnce(lesson.id) ?: LessonProgressEntity(
            lessonId = lesson.id,
            levelNumber = lesson.levelNumber,
            orderInLevel = lesson.orderInLevel,
            isUnlocked = true
        )
        dao.upsertLessonProgress(existing.copy(exerciseSolved = true, isUnlocked = true))
    }

    /**
     * Records a completed 5-question lesson assessment, updates SM-2 concept mastery,
     * and unlocks the next lesson ONLY if [scorePercent] >= passingScoreThreshold.
     */
    suspend fun recordLessonAssessment(
        lesson: ChessLesson,
        scorePercent: Int,
        questionResults: List<Pair<Boolean, String>> // (isCorrect, explanationIfWrong)
    ): Boolean {
        val profile = dao.getProfileOnce() ?: LearnerProfileEntity()
        val passThreshold = profile.passingScoreThreshold
        val passed = scorePercent >= passThreshold

        val existing = dao.getLessonProgressOnce(lesson.id) ?: LessonProgressEntity(
            lessonId = lesson.id,
            levelNumber = lesson.levelNumber,
            orderInLevel = lesson.orderInLevel,
            isUnlocked = true
        )

        val updatedProgress = existing.copy(
            isUnlocked = true,
            isCompleted = existing.isCompleted || passed,
            bestScorePercent = max(existing.bestScorePercent, scorePercent),
            lastScorePercent = scorePercent,
            attemptsCount = existing.attemptsCount + 1,
            lastCompletedTimestamp = System.currentTimeMillis()
        )
        dao.upsertLessonProgress(updatedProgress)

        // Update Concept Mastery & Spaced Repetition (SM-2)
        val correctDelta = questionResults.count { it.first }
        val incorrectDelta = questionResults.count { !it.first }
        val lastMistake = questionResults.lastOrNull { !it.first }?.second ?: ""
        updateConceptMastery(
            conceptTag = lesson.conceptTag,
            lessonId = lesson.id,
            topicTitle = lesson.title,
            correctDelta = correctDelta,
            incorrectDelta = incorrectDelta,
            mistakeNote = lastMistake
        )

        // Unlock next lesson if passed
        if (passed) {
            val allLessons = CurriculumLevels5To9.allLessons
            val idx = allLessons.indexOfFirst { it.id == lesson.id }
            if (idx in 0 until allLessons.lastIndex) {
                val nextLesson = allLessons[idx + 1]
                val nextExisting = dao.getLessonProgressOnce(nextLesson.id) ?: LessonProgressEntity(
                    lessonId = nextLesson.id,
                    levelNumber = nextLesson.levelNumber,
                    orderInLevel = nextLesson.orderInLevel
                )
                dao.upsertLessonProgress(nextExisting.copy(isUnlocked = true))
                if (nextLesson.levelNumber > profile.currentCurriculumLevel) {
                    dao.upsertProfile(profile.copy(currentCurriculumLevel = nextLesson.levelNumber))
                }
            }
        }
        return passed
    }

    suspend fun updateConceptMastery(
        conceptTag: String,
        lessonId: String,
        topicTitle: String,
        correctDelta: Int,
        incorrectDelta: Int,
        mistakeNote: String = ""
    ) {
        val current = dao.getConceptMasteryOnce(conceptTag) ?: ConceptMasteryEntity(
            conceptTag = conceptTag,
            lessonId = lessonId,
            topicTitle = topicTitle
        )

        val newCorrect = current.correctCount + correctDelta
        val newIncorrect = current.incorrectCount + incorrectDelta

        // SM-2 Spaced Repetition interval update
        val (newInterval, newEase) = if (incorrectDelta > 0) {
            1 to max(1.3f, current.easeFactor - 0.25f)
        } else {
            val nextInt = max(1, (current.intervalDays * current.easeFactor).toInt())
            min(30, nextInt) to min(3.0f, current.easeFactor + 0.1f)
        }

        val nextReview = if (incorrectDelta > 0) {
            System.currentTimeMillis() // Due immediately in Adaptive Revision Queue
        } else {
            System.currentTimeMillis() + newInterval * 24L * 3600_000L
        }

        dao.upsertConceptMastery(
            current.copy(
                correctCount = newCorrect,
                incorrectCount = newIncorrect,
                intervalDays = newInterval,
                easeFactor = newEase,
                nextReviewTimestamp = nextReview,
                lastMistakeExplanation = if (mistakeNote.isNotBlank()) mistakeNote else current.lastMistakeExplanation
            )
        )
    }

    suspend fun recordPuzzleAttempt(
        puzzleId: String,
        categoryName: String,
        conceptTag: String,
        puzzleTitle: String,
        solved: Boolean,
        solveTimeSeconds: Int,
        hintsUsed: Int
    ) {
        val current = dao.getPuzzleProgressOnce(puzzleId) ?: PuzzleProgressEntity(
            puzzleId = puzzleId,
            categoryName = categoryName
        )
        val bestTime = if (solved) {
            if (current.bestSolveTimeSeconds == 0) solveTimeSeconds else min(current.bestSolveTimeSeconds, solveTimeSeconds)
        } else {
            current.bestSolveTimeSeconds
        }
        dao.upsertPuzzleProgress(
            current.copy(
                isSolved = current.isSolved || solved,
                attempts = current.attempts + 1,
                bestSolveTimeSeconds = bestTime,
                hintsUsed = current.hintsUsed + hintsUsed,
                lastAttemptTimestamp = System.currentTimeMillis()
            )
        )

        // Feed puzzle result into Adaptive Revision Engine
        val matchingLesson = CurriculumLevels5To9.allLessons.firstOrNull { it.conceptTag == conceptTag }
        updateConceptMastery(
            conceptTag = conceptTag,
            lessonId = matchingLesson?.id ?: "L4_T1",
            topicTitle = matchingLesson?.title ?: puzzleTitle,
            correctDelta = if (solved) 1 else 0,
            incorrectDelta = if (solved) 0 else 1,
            mistakeNote = if (!solved) "Missed tactical pattern in puzzle: $puzzleTitle" else ""
        )
    }

    suspend fun recordAiGame(
        difficultyName: String,
        playerColorName: String,
        resultLabel: String,
        movesCount: Int,
        blundersCount: Int,
        mistakesCount: Int,
        accuracyPercent: Int,
        pgnText: String
    ) {
        dao.insertAiGame(
            AiGameRecordEntity(
                difficultyName = difficultyName,
                playerColorName = playerColorName,
                resultLabel = resultLabel,
                movesCount = movesCount,
                blundersCount = blundersCount,
                mistakesCount = mistakesCount,
                accuracyPercent = accuracyPercent,
                pgnText = pgnText
            )
        )
    }

    suspend fun updateSettings(
        boardTheme: BoardTheme? = null,
        showCoordinates: Boolean? = null,
        enableCoachHints: Boolean? = null,
        passingScoreThreshold: Int? = null
    ) {
        val current = dao.getProfileOnce() ?: LearnerProfileEntity()
        dao.upsertProfile(
            current.copy(
                boardThemeName = boardTheme?.name ?: current.boardThemeName,
                showCoordinates = showCoordinates ?: current.showCoordinates,
                enableCoachHints = enableCoachHints ?: current.enableCoachHints,
                passingScoreThreshold = passingScoreThreshold ?: current.passingScoreThreshold
            )
        )
    }

    suspend fun resetAllLearnerProgress() {
        dao.clearLessonProgress()
        dao.clearConceptMastery()
        dao.clearPuzzleProgress()
        dao.clearAiGames()
        val todayEpoch = System.currentTimeMillis() / (24L * 3600_000L)
        dao.upsertProfile(
            LearnerProfileEntity(
                id = 1,
                hasCompletedOnboarding = false,
                lastStudyDayEpoch = todayEpoch
            )
        )
        seedInitialLessonProgress(unlockedUpToLevel = 1)
    }
}
