package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface ChessAcademyDao {

    @Query("SELECT * FROM learner_profile WHERE id = 1")
    fun observeProfile(): Flow<LearnerProfileEntity?>

    @Query("SELECT * FROM learner_profile WHERE id = 1")
    suspend fun getProfileOnce(): LearnerProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: LearnerProfileEntity)

    @Query("SELECT * FROM lesson_progress ORDER BY levelNumber ASC, orderInLevel ASC")
    fun observeAllLessonProgress(): Flow<List<LessonProgressEntity>>

    @Query("SELECT * FROM lesson_progress WHERE lessonId = :lessonId")
    suspend fun getLessonProgressOnce(lessonId: String): LessonProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLessonProgress(progress: LessonProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAllLessonProgress(progressList: List<LessonProgressEntity>)

    @Query("SELECT * FROM concept_mastery ORDER BY incorrectCount DESC, correctCount ASC")
    fun observeAllConceptMastery(): Flow<List<ConceptMasteryEntity>>

    @Query("SELECT * FROM concept_mastery WHERE conceptTag = :tag")
    suspend fun getConceptMasteryOnce(tag: String): ConceptMasteryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConceptMastery(entity: ConceptMasteryEntity)

    @Query("SELECT * FROM puzzle_progress")
    fun observeAllPuzzleProgress(): Flow<List<PuzzleProgressEntity>>

    @Query("SELECT * FROM puzzle_progress WHERE puzzleId = :puzzleId")
    suspend fun getPuzzleProgressOnce(puzzleId: String): PuzzleProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPuzzleProgress(entity: PuzzleProgressEntity)

    @Query("SELECT * FROM ai_game_records ORDER BY timestamp DESC")
    fun observeAllAiGames(): Flow<List<AiGameRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAiGame(record: AiGameRecordEntity)

    @Query("DELETE FROM lesson_progress")
    suspend fun clearLessonProgress()

    @Query("DELETE FROM concept_mastery")
    suspend fun clearConceptMastery()

    @Query("DELETE FROM puzzle_progress")
    suspend fun clearPuzzleProgress()

    @Query("DELETE FROM ai_game_records")
    suspend fun clearAiGames()
}

@Database(
    entities = [
        LearnerProfileEntity::class,
        LessonProgressEntity::class,
        ConceptMasteryEntity::class,
        PuzzleProgressEntity::class,
        AiGameRecordEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ChessAcademyDatabase : RoomDatabase() {
    abstract fun dao(): ChessAcademyDao

    companion object {
        @Volatile
        private var INSTANCE: ChessAcademyDatabase? = null

        fun getInstance(context: Context): ChessAcademyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ChessAcademyDatabase::class.java,
                    "chess_academy_local.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
