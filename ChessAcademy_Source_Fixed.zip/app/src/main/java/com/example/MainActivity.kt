package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ChessAcademyViewModel
import com.example.ui.MainNavTab
import com.example.ui.SubScreen
import com.example.ui.screens.AiGameplayScreen
import com.example.ui.screens.BoardSandboxScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LearnCurriculumScreen
import com.example.ui.screens.LessonAssessmentScreen
import com.example.ui.screens.LessonDetailScreen
import com.example.ui.screens.PracticeHubScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.screens.ProgressDashboardScreen
import com.example.ui.screens.PuzzleTrainerScreen
import com.example.ui.screens.SkillAssessmentScreen
import com.example.ui.theme.CardBorderSubtle
import com.example.ui.theme.ChessAcademyTheme
import com.example.ui.theme.MainTextCharcoal
import com.example.ui.theme.PrimaryCyanDark
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SecondaryLightCyan
import com.example.ui.theme.SecondaryTextGrey

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ChessAcademyTheme {
                ChessAcademyApp()
            }
        }
    }
}

@Composable
fun ChessAcademyApp(
    viewModel: ChessAcademyViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val subScreen by viewModel.subScreen.collectAsStateWithLifecycle()
    val selectedLesson by viewModel.selectedLesson.collectAsStateWithLifecycle()
    val selectedPuzzleCategory by viewModel.selectedPuzzleCategory.collectAsStateWithLifecycle()
    val activePuzzle by viewModel.activePuzzle.collectAsStateWithLifecycle()

    val aiDifficulty by viewModel.aiDifficulty.collectAsStateWithLifecycle()
    val aiPlayerColor by viewModel.aiPlayerColor.collectAsStateWithLifecycle()
    val aiBoardHistory by viewModel.aiBoardHistory.collectAsStateWithLifecycle()
    val aiMoveEvaluations by viewModel.aiMoveEvaluations.collectAsStateWithLifecycle()
    val aiCoachHint by viewModel.aiCoachHint.collectAsStateWithLifecycle()
    val isAiThinking by viewModel.isAiThinking.collectAsStateWithLifecycle()

    BackHandler(enabled = subScreen != SubScreen.NONE || currentTab != MainNavTab.HOME) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = PureWhite,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            if (subScreen == SubScreen.NONE) {
                NavigationBar(
                    containerColor = PureWhite,
                    tonalElevation = 4.dp
                ) {
                    MainNavTab.entries.forEach { tab ->
                        val selected = currentTab == tab
                        val icon = when (tab) {
                            MainNavTab.HOME -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
                            MainNavTab.LEARN -> if (selected) Icons.Filled.MenuBook else Icons.Outlined.MenuBook
                            MainNavTab.PRACTICE -> if (selected) Icons.Filled.SportsEsports else Icons.Outlined.SportsEsports
                            MainNavTab.PROGRESS -> if (selected) Icons.Filled.BarChart else Icons.Outlined.BarChart
                            MainNavTab.PROFILE -> if (selected) Icons.Filled.Person else Icons.Outlined.Person
                        }
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.selectTab(tab) },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = tab.label
                                )
                            },
                            label = {
                                Text(
                                    text = tab.label,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryCyanDark,
                                selectedTextColor = MainTextCharcoal,
                                indicatorColor = SecondaryLightCyan,
                                unselectedIconColor = SecondaryTextGrey,
                                unselectedTextColor = SecondaryTextGrey
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (subScreen) {
                SubScreen.SKILL_ASSESSMENT -> {
                    SkillAssessmentScreen(
                        uiState = uiState,
                        onCompleteAssessment = { score -> viewModel.submitSkillAssessment(score) },
                        onCancel = { viewModel.navigateBack() }
                    )
                }
                SubScreen.LESSON_DETAIL -> {
                    LessonDetailScreen(
                        lesson = selectedLesson,
                        uiState = uiState,
                        onBack = { viewModel.navigateBack() },
                        onExerciseCompleted = { viewModel.markExerciseSolved(selectedLesson) },
                        onStartTest = { viewModel.startLessonTest(selectedLesson) }
                    )
                }
                SubScreen.LESSON_TEST -> {
                    LessonAssessmentScreen(
                        lesson = selectedLesson,
                        uiState = uiState,
                        onSubmitResults = { pct, results, onDone ->
                            viewModel.submitLessonAssessment(selectedLesson, pct, results, onDone)
                        },
                        onBackToLesson = { viewModel.navigateBack() },
                        onDoneToCurriculum = { viewModel.selectTab(MainNavTab.LEARN) }
                    )
                }
                SubScreen.PUZZLE_TRAINER -> {
                    PuzzleTrainerScreen(
                        uiState = uiState,
                        initialCategory = selectedPuzzleCategory,
                        activePuzzle = activePuzzle,
                        onSelectPuzzle = { viewModel.selectPuzzle(it) },
                        onRecordResult = { puz, solved, sec, hints ->
                            viewModel.recordPuzzleResult(puz, solved, sec, hints)
                        },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                SubScreen.AI_GAMEPLAY -> {
                    AiGameplayScreen(
                        uiState = uiState,
                        difficulty = aiDifficulty,
                        playerColor = aiPlayerColor,
                        boardHistory = aiBoardHistory,
                        moveEvaluations = aiMoveEvaluations,
                        coachHint = aiCoachHint,
                        isAiThinking = isAiThinking,
                        onMoveMade = { viewModel.makePlayerMoveAgainstAi(it) },
                        onUndo = { viewModel.undoAiGameMove() },
                        onRestart = { diff, col -> viewModel.startNewAiGame(diff, col) },
                        onRequestHint = { viewModel.requestAiCoachHint() },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                SubScreen.BOARD_SANDBOX -> {
                    BoardSandboxScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateBack() }
                    )
                }
                SubScreen.NONE -> {
                    when (currentTab) {
                        MainNavTab.HOME -> {
                            HomeScreen(
                                uiState = uiState,
                                onStartAssessment = { viewModel.openSkillAssessment() },
                                onStartDirectBeginner = { viewModel.completeOnboardingDirectBeginner() },
                                onOpenLesson = { viewModel.openLesson(it) },
                                onOpenPuzzles = { viewModel.openPuzzleTrainer(null, null) },
                                onOpenAiGameplay = { viewModel.openAiGameplay() },
                                onOpenLearnTab = { viewModel.selectTab(MainNavTab.LEARN) }
                            )
                        }
                        MainNavTab.LEARN -> {
                            LearnCurriculumScreen(
                                uiState = uiState,
                                onSelectLesson = { viewModel.openLesson(it) }
                            )
                        }
                        MainNavTab.PRACTICE -> {
                            PracticeHubScreen(
                                uiState = uiState,
                                onOpenPuzzles = { cat -> viewModel.openPuzzleTrainer(null, cat) },
                                onOpenAiGameplay = { diff, col -> viewModel.openAiGameplay(diff, col) },
                                onOpenBoardSandbox = { viewModel.openBoardSandbox() }
                            )
                        }
                        MainNavTab.PROGRESS -> {
                            ProgressDashboardScreen(
                                uiState = uiState,
                                onOpenLesson = { viewModel.openLesson(it) }
                            )
                        }
                        MainNavTab.PROFILE -> {
                            ProfileSettingsScreen(
                                uiState = uiState,
                                onRetakeSkillAssessment = { viewModel.openSkillAssessment() },
                                onUpdateBoardTheme = { viewModel.updateSettings(boardTheme = it) },
                                onToggleCoordinates = { viewModel.updateSettings(showCoordinates = it) },
                                onToggleCoachHints = { viewModel.updateSettings(enableCoachHints = it) },
                                onUpdatePassingThreshold = { viewModel.updateSettings(passingScoreThreshold = it) },
                                onResetProgress = { viewModel.resetProgress() }
                            )
                        }
                    }
                }
            }
        }
    }
}
