package com.example.chess

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Tactical Heuristic & Alpha-Beta Minimax Chess Engine with Adaptive Learner Coaching
 * and Post-Game Mistake Analysis.
 */
object ChessCoachAi {

    // Piece-Square Tables (from White's perspective, rank 0..7)
    private val PAWN_PST = intArrayOf(
        0,  0,  0,  0,  0,  0,  0,  0,
        5, 10, 10,-20,-20, 10, 10,  5,
        5, -5,-10,  0,  0,-10, -5,  5,
        0,  0,  0, 25, 25,  0,  0,  0,
        5,  5, 10, 30, 30, 10,  5,  5,
       10, 10, 20, 35, 35, 20, 10, 10,
       50, 50, 50, 50, 50, 50, 50, 50,
        0,  0,  0,  0,  0,  0,  0,  0
    )

    private val KNIGHT_PST = intArrayOf(
       -50,-40,-30,-30,-30,-30,-40,-50,
       -40,-20,  0,  5,  5,  0,-20,-40,
       -30,  5, 15, 20, 20, 15,  5,-30,
       -30,  5, 20, 25, 25, 20,  5,-30,
       -30,  5, 20, 25, 25, 20,  5,-30,
       -30,  5, 15, 20, 20, 15,  5,-30,
       -40,-20,  0,  0,  0,  0,-20,-40,
       -50,-40,-30,-30,-30,-30,-40,-50
    )

    private val BISHOP_PST = intArrayOf(
       -20,-10,-10,-10,-10,-10,-10,-20,
       -10,  5,  0,  0,  0,  0,  5,-10,
       -10, 10, 10, 15, 15, 10, 10,-10,
       -10,  0, 15, 15, 15, 15,  0,-10,
       -10,  5, 10, 15, 15, 10,  5,-10,
       -10,  0, 10, 10, 10, 10,  0,-10,
       -10,  0,  0,  0,  0,  0,  0,-10,
       -20,-10,-10,-10,-10,-10,-10,-20
    )

    private val ROOK_PST = intArrayOf(
         0,  0,  5, 10, 10,  5,  0,  0,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        25, 25, 25, 25, 25, 25, 25, 25,
         0,  0,  5, 10, 10,  5,  0,  0
    )

    private val KING_MID_PST = intArrayOf(
        20, 30, 10,  0,  0, 10, 30, 20,
        20, 20,  0,  0,  0,  0, 20, 20,
       -10,-20,-20,-20,-20,-20,-20,-10,
       -20,-30,-30,-40,-40,-30,-30,-20,
       -30,-40,-40,-50,-50,-40,-40,-30,
       -30,-40,-40,-50,-50,-40,-40,-30,
       -30,-40,-40,-50,-50,-40,-40,-30,
       -30,-40,-40,-50,-50,-40,-40,-30
    )

    /**
     * Evaluates the board in centipawns from [perspective]'s point of view.
     */
    fun evaluatePosition(state: ChessBoardState, perspective: PieceColor = state.turn): Int {
        val status = state.gameStatus()
        if (status == GameStatus.CHECKMATE) {
            return if (state.turn == perspective) -19000 else 19000
        }
        if (status.isTerminal) return 0

        var whiteScore = 0
        var blackScore = 0

        for ((sq, piece) in state.pieces) {
            val pstIndex = if (piece.color == PieceColor.WHITE) {
                sq.rank * 8 + sq.file
            } else {
                (7 - sq.rank) * 8 + sq.file
            }

            val positionalBonus = when (piece.type) {
                PieceType.PAWN -> PAWN_PST[pstIndex]
                PieceType.KNIGHT -> KNIGHT_PST[pstIndex]
                PieceType.BISHOP -> BISHOP_PST[pstIndex]
                PieceType.ROOK -> ROOK_PST[pstIndex]
                PieceType.QUEEN -> (BISHOP_PST[pstIndex] + ROOK_PST[pstIndex]) / 2
                PieceType.KING -> KING_MID_PST[pstIndex]
            }

            val total = piece.type.value + positionalBonus
            if (piece.color == PieceColor.WHITE) {
                whiteScore += total
            } else {
                blackScore += total
            }
        }

        // Center control & king safety bonuses
        val centerSquares = listOf(Square(3, 3), Square(4, 3), Square(3, 4), Square(4, 4))
        for (cSq in centerSquares) {
            if (state.isSquareAttackedBy(cSq, PieceColor.WHITE)) whiteScore += 8
            if (state.isSquareAttackedBy(cSq, PieceColor.BLACK)) blackScore += 8
        }

        val netWhite = whiteScore - blackScore
        return if (perspective == PieceColor.WHITE) netWhite else -netWhite
    }

    /**
     * Selects a move for the AI opponent at the chosen [difficulty].
     */
    fun selectBestMove(state: ChessBoardState, difficulty: AiDifficulty): ChessMove? {
        val legal = state.legalMoves()
        if (legal.isEmpty()) return null
        if (legal.size == 1) return legal.first()

        // Order moves for faster alpha-beta pruning (captures, promotions, checks first)
        val ordered = orderMoves(state, legal)

        // For Beginner level, pick among the top 3 reasonable moves to give learners instructive play
        val depth = difficulty.searchDepth
        var bestMove = ordered.first()
        var bestScore = Int.MIN_VALUE / 2

        val scoredMoves = mutableListOf<Pair<ChessMove, Int>>()
        var alpha = -30000
        val beta = 30000

        for (move in ordered) {
            val nextState = state.applyMoveUnchecked(move, move.san)
            val score = -alphaBeta(
                state = nextState,
                depth = depth - 1,
                alpha = -beta,
                beta = -alpha,
                usePositional = difficulty.level >= 2
            )
            scoredMoves.add(move to score)
            if (score > bestScore) {
                bestScore = score
                bestMove = move
            }
            alpha = max(alpha, score)
        }

        scoredMoves.sortByDescending { it.second }
        return when (difficulty) {
            AiDifficulty.BEGINNER -> {
                // Avoid outright mate-in-1 blunders if possible, but play accessible moves
                val nonBlunders = scoredMoves.filter { it.second >= bestScore - 180 }
                nonBlunders.getOrNull(min(1, nonBlunders.lastIndex))?.first ?: bestMove
            }
            AiDifficulty.EASY -> {
                val topCandidates = scoredMoves.filter { it.second >= bestScore - 75 }
                topCandidates.firstOrNull()?.first ?: bestMove
            }
            else -> bestMove
        }
    }

    private fun alphaBeta(
        state: ChessBoardState,
        depth: Int,
        alpha: Int,
        beta: Int,
        usePositional: Boolean
    ): Int {
        val legal = state.legalMoves()
        if (legal.isEmpty()) {
            return if (state.isInCheck(state.turn)) -(19000 + depth * 50) else 0
        }
        if (depth <= 0) {
            return if (usePositional) {
                evaluatePosition(state, state.turn)
            } else {
                materialOnlyEvaluation(state, state.turn)
            }
        }

        var currentAlpha = alpha
        val ordered = orderMoves(state, legal)
        var maxEval = -30000

        for (move in ordered) {
            val next = state.applyMoveUnchecked(move, move.san)
            val eval = -alphaBeta(next, depth - 1, -beta, -currentAlpha, usePositional)
            if (eval > maxEval) maxEval = eval
            if (eval > currentAlpha) currentAlpha = eval
            if (currentAlpha >= beta) break
        }
        return maxEval
    }

    private fun materialOnlyEvaluation(state: ChessBoardState, perspective: PieceColor): Int {
        var score = 0
        for (p in state.pieces.values) {
            score += if (p.color == perspective) p.type.value else -p.type.value
        }
        return score
    }

    private fun orderMoves(state: ChessBoardState, moves: List<ChessMove>): List<ChessMove> {
        return moves.sortedByDescending { move ->
            var priority = 0
            if (move.san.endsWith("#")) priority += 10000
            if (move.san.endsWith("+")) priority += 800
            if (move.promotion != null) priority += move.promotion.value
            if (move.capturedPiece != null) {
                val attackerVal = state.pieceAt(move.from)?.type?.value ?: 100
                priority += 10 * move.capturedPiece.type.value - (attackerVal / 10)
            }
            if (move.isCastlingKingSide || move.isCastlingQueenSide) priority += 150
            priority
        }
    }

    /**
     * Generates a real-time or post-game coaching evaluation comparing the learner's move
     * against the engine's recommended move, explaining the underlying chess concept.
     */
    fun analyzeMove(
        stateBefore: ChessBoardState,
        playedMove: ChessMove
    ): MoveEvaluation {
        val playerColor = stateBefore.turn
        val bestMove = selectBestMove(stateBefore, AiDifficulty.ADVANCED) ?: playedMove
        val stateAfterPlayed = stateBefore.applyMoveUnchecked(playedMove, playedMove.san)
        val stateAfterBest = stateBefore.applyMoveUnchecked(bestMove, bestMove.san)

        val evalBefore = evaluatePosition(stateBefore, playerColor)
        val evalAfterBest = -evaluatePosition(stateAfterBest, playerColor.opposite())
        val evalAfterPlayed = -evaluatePosition(stateAfterPlayed, playerColor.opposite())

        val cpLoss = max(0, evalAfterBest - evalAfterPlayed)
        val isBest = playedMove.from == bestMove.from && playedMove.to == bestMove.to

        val quality = when {
            isBest && (playedMove.san.endsWith("#") || cpLoss == 0) -> MoveQuality.BEST
            cpLoss <= 30 -> MoveQuality.GOOD
            cpLoss in 31..95 -> MoveQuality.INACCURACY
            cpLoss in 96..220 -> MoveQuality.MISTAKE
            else -> MoveQuality.BLUNDER
        }

        val (conceptTag, explanation) = buildCoachExplanation(
            stateBefore = stateBefore,
            stateAfterPlayed = stateAfterPlayed,
            playedMove = playedMove,
            bestMove = bestMove,
            quality = quality,
            cpLoss = cpLoss
        )

        return MoveEvaluation(
            moveNumber = stateBefore.fullMoveNumber,
            playerColor = playerColor,
            playedMoveSan = playedMove.san.ifEmpty { playedMove.toUci() },
            bestMoveSan = bestMove.san.ifEmpty { bestMove.toUci() },
            quality = quality,
            evalBeforeCp = evalBefore,
            evalAfterCp = evalAfterPlayed,
            coachExplanation = explanation,
            conceptTag = conceptTag,
            bestMoveArrow = CoachArrow(bestMove.from, bestMove.to, isBestMove = true)
        )
    }

    private fun buildCoachExplanation(
        stateBefore: ChessBoardState,
        stateAfterPlayed: ChessBoardState,
        playedMove: ChessMove,
        bestMove: ChessMove,
        quality: MoveQuality,
        cpLoss: Int
    ): Pair<String, String> {
        val movingPiece = stateBefore.pieceAt(playedMove.from)
        val enemyColor = stateBefore.turn.opposite()

        // Check if learner hung the moved piece
        val movedPieceAttacked = stateAfterPlayed.isSquareAttackedBy(playedMove.to, enemyColor)
        val movedPieceDefended = stateAfterPlayed.isSquareAttackedBy(playedMove.to, stateBefore.turn)

        if (quality == MoveQuality.BLUNDER || quality == MoveQuality.MISTAKE) {
            if (movedPieceAttacked && !movedPieceDefended && movingPiece != null && movingPiece.type != PieceType.PAWN) {
                return "HANGING_PIECES" to
                    "${playedMove.san} places your ${movingPiece.type.displayName} on ${playedMove.to.toAlgebraic()} undefended where ${enemyColor.displayName()} can capture it. Consider ${bestMove.san} instead."
            }
            if (bestMove.capturedPiece != null && playedMove.capturedPiece == null) {
                return "TACTICAL_AWARENESS" to
                    "You missed a strong capture with ${bestMove.san} (winning ${bestMove.capturedPiece.type.displayName}). Always scan for undefended opponent pieces before moving."
            }
            if (bestMove.san.endsWith("#")) {
                return "CHECKMATE_PATTERNS" to
                    "You had a forced checkmate available with ${bestMove.san}! Always check forcing moves (checks and captures) first."
            }
            return "POSITIONAL_PLAY" to
                "${playedMove.san} loses approximately ${cpLoss / 100.0} pawns of evaluation. ${bestMove.san} better maintains piece coordination and king safety."
        }

        if (quality == MoveQuality.INACCURACY) {
            if (stateBefore.fullMoveNumber <= 10 && movingPiece?.type == PieceType.PAWN &&
                (playedMove.from.file == 0 || playedMove.from.file == 7)
            ) {
                return "OPENING_PRINCIPLES" to
                    "Flank pawn moves like ${playedMove.san} in the opening slow down piece development. Prefer ${bestMove.san} to fight for the center and develop minor pieces."
            }
            return "PIECE_ACTIVITY" to
                "${playedMove.san} is playable, though ${bestMove.san} gives slightly more active square control."
        }

        // Best or Good move
        if (playedMove.isCastlingKingSide || playedMove.isCastlingQueenSide) {
            return "KING_SAFETY" to
                "Excellent! Castling (${playedMove.san}) tucks your King into safety and activates your Rook toward the center files."
        }
        if (playedMove.capturedPiece != null) {
            return "TACTICS" to
                "Well spotted! ${playedMove.san} wins material cleanly while keeping your pieces coordinated."
        }
        if (stateBefore.fullMoveNumber <= 8 && (movingPiece?.type == PieceType.KNIGHT || movingPiece?.type == PieceType.BISHOP)) {
            return "DEVELOPMENT" to
                "Strong developing move (${playedMove.san}), bringing a minor piece into active play toward the center."
        }
        return "STRATEGY" to
            "Strong move (${playedMove.san})! This maintains healthy piece coordination and central pressure."
    }

    /**
     * Generates a coaching hint for the current board state without immediately making the move.
     */
    fun getCoachHint(state: ChessBoardState): Pair<String, CoachArrow?> {
        val best = selectBestMove(state, AiDifficulty.ADVANCED)
            ?: return "No legal moves available in this position." to null
        val piece = state.pieceAt(best.from)
        val hintText = when {
            best.san.endsWith("#") ->
                "Coach Hint: Look closely at your ${piece?.type?.displayName ?: "pieces"} on ${best.from.toAlgebraic()} — there is a direct checkmate available!"
            best.capturedPiece != null ->
                "Coach Hint: Your ${piece?.type?.displayName ?: "piece"} on ${best.from.toAlgebraic()} can capture an important target on ${best.to.toAlgebraic()}."
            best.isCastlingKingSide || best.isCastlingQueenSide ->
                "Coach Hint: Prioritizing King safety by castling now will connect your Rooks and safeguard your King."
            else ->
                "Coach Hint: Consider improving your ${piece?.type?.displayName ?: "piece"} from ${best.from.toAlgebraic()} to ${best.to.toAlgebraic()} to increase central control."
        }
        return hintText to CoachArrow(best.from, best.to, isBestMove = true)
    }
}
