package com.example.chess

import kotlin.math.abs

enum class PieceColor {
    WHITE, BLACK;

    fun opposite(): PieceColor = if (this == WHITE) BLACK else WHITE
    fun displayName(): String = if (this == WHITE) "White" else "Black"
}

enum class PieceType(val symbol: Char, val value: Int, val displayName: String) {
    KING('K', 20000, "King"),
    QUEEN('Q', 900, "Queen"),
    ROOK('R', 500, "Rook"),
    BISHOP('B', 330, "Bishop"),
    KNIGHT('N', 320, "Knight"),
    PAWN('P', 100, "Pawn");

    fun unicodeSymbol(color: PieceColor): String = when (this) {
        KING -> if (color == PieceColor.WHITE) "♔" else "♚"
        QUEEN -> if (color == PieceColor.WHITE) "♕" else "♛"
        ROOK -> if (color == PieceColor.WHITE) "♖" else "♜"
        BISHOP -> if (color == PieceColor.WHITE) "♗" else "♝"
        KNIGHT -> if (color == PieceColor.WHITE) "♘" else "♞"
        PAWN -> if (color == PieceColor.WHITE) "♙" else "♟"
    }
}

data class ChessPiece(
    val type: PieceType,
    val color: PieceColor
) {
    fun toFenChar(): Char =
        if (color == PieceColor.WHITE) type.symbol else type.symbol.lowercaseChar()

    companion object {
        fun fromFenChar(c: Char): ChessPiece? {
            val color = if (c.isUpperCase()) PieceColor.WHITE else PieceColor.BLACK
            val type = when (c.uppercaseChar()) {
                'K' -> PieceType.KING
                'Q' -> PieceType.QUEEN
                'R' -> PieceType.ROOK
                'B' -> PieceType.BISHOP
                'N' -> PieceType.KNIGHT
                'P' -> PieceType.PAWN
                else -> return null
            }
            return ChessPiece(type, color)
        }
    }
}

data class Square(val file: Int, val rank: Int) {
    val isValid: Boolean get() = file in 0..7 && rank in 0..7
    val isLightSquare: Boolean get() = (file + rank) % 2 != 0

    fun toAlgebraic(): String {
        if (!isValid) return "-"
        val f = ('a'.code + file).toChar()
        val r = ('1'.code + rank).toChar()
        return "$f$r"
    }

    fun offset(df: Int, dr: Int): Square = Square(file + df, rank + dr)

    companion object {
        fun fromAlgebraic(str: String): Square? {
            val clean = str.trim().lowercase()
            if (clean.length != 2) return null
            val f = clean[0] - 'a'
            val r = clean[1] - '1'
            val sq = Square(f, r)
            return if (sq.isValid) sq else null
        }
    }
}

data class CastlingRights(
    val whiteKingSide: Boolean = true,
    val whiteQueenSide: Boolean = true,
    val blackKingSide: Boolean = true,
    val blackQueenSide: Boolean = true
) {
    fun toFenString(): String {
        val sb = StringBuilder()
        if (whiteKingSide) sb.append('K')
        if (whiteQueenSide) sb.append('Q')
        if (blackKingSide) sb.append('k')
        if (blackQueenSide) sb.append('q')
        return if (sb.isEmpty()) "-" else sb.toString()
    }

    companion object {
        fun fromFenString(fen: String): CastlingRights {
            if (fen == "-") return CastlingRights(false, false, false, false)
            return CastlingRights(
                whiteKingSide = fen.contains('K'),
                whiteQueenSide = fen.contains('Q'),
                blackKingSide = fen.contains('k'),
                blackQueenSide = fen.contains('q')
            )
        }
    }
}

data class ChessMove(
    val from: Square,
    val to: Square,
    val promotion: PieceType? = null,
    val isCastlingKingSide: Boolean = false,
    val isCastlingQueenSide: Boolean = false,
    val isEnPassant: Boolean = false,
    val capturedPiece: ChessPiece? = null,
    val san: String = ""
) {
    fun toUci(): String {
        val promo = promotion?.symbol?.lowercaseChar()?.toString() ?: ""
        return "${from.toAlgebraic()}${to.toAlgebraic()}$promo"
    }

    fun matchesSquares(otherFrom: Square, otherTo: Square, otherPromo: PieceType? = null): Boolean {
        if (from != otherFrom || to != otherTo) return false
        if (promotion != null && otherPromo != null && promotion != otherPromo) return false
        return true
    }
}

enum class GameStatus(val label: String, val isTerminal: Boolean) {
    ACTIVE("In Progress", false),
    CHECK("Check!", false),
    CHECKMATE("Checkmate!", true),
    STALEMATE("Draw by Stalemate", true),
    DRAW_FIFTY_MOVE("Draw by 50-Move Rule", true),
    DRAW_THREEFOLD("Draw by Threefold Repetition", true),
    DRAW_INSUFFICIENT_MATERIAL("Draw by Insufficient Material", true)
}

enum class BoardTheme(val displayName: String, val subtitle: String) {
    CYAN_WHITE("Cyan & White", "Signature Chess Academy clean high-contrast palette"),
    CLASSIC_WOOD("Classic Wood", "Warm traditional tournament walnut and maple"),
    TOURNAMENT_GREEN("Tournament Green", "Championship standard green and cream")
}

data class CoachArrow(
    val from: Square,
    val to: Square,
    val isBestMove: Boolean = true
)

enum class MoveQuality(val label: String, val symbol: String) {
    BRILLIANT("Brilliant Move", "!!"),
    BEST("Best Move", "★"),
    GOOD("Solid Move", "✓"),
    INACCURACY("Inaccuracy", "?!"),
    MISTAKE("Mistake", "?"),
    BLUNDER("Blunder", "??")
}

data class MoveEvaluation(
    val moveNumber: Int,
    val playerColor: PieceColor,
    val playedMoveSan: String,
    val bestMoveSan: String,
    val quality: MoveQuality,
    val evalBeforeCp: Int,
    val evalAfterCp: Int,
    val coachExplanation: String,
    val conceptTag: String,
    val bestMoveArrow: CoachArrow? = null
)

enum class AiDifficulty(
    val level: Int,
    val title: String,
    val eloEstimate: Int,
    val searchDepth: Int,
    val description: String
) {
    BEGINNER(1, "Beginner", 600, 1, "Focuses on basic legal moves and simple captures; ideal for practicing fundamentals."),
    EASY(2, "Easy", 950, 2, "Plays developing moves and spots 1-move captures; forgiving of minor tactical slips."),
    INTERMEDIATE(3, "Intermediate", 1300, 2, "Uses opening principles, piece coordination, and spots 2-move tactical combinations."),
    ADVANCED(4, "Advanced", 1650, 3, "Calculates multi-move tactics, protects king safety, and punishes loose pieces."),
    EXPERT(5, "Expert", 2000, 4, "Deep tactical and positional evaluation with quiescence search and endgame precision.")
}
