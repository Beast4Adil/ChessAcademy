package com.example.chess

import kotlin.math.abs

/**
 * Immutable FIDE-compliant Chess Board State with full legal move generation,
 * castling, en passant, promotion, check/checkmate/stalemate/draw rules,
 * SAN algebraic notation, FEN, and PGN support.
 */
data class ChessBoardState(
    val pieces: Map<Square, ChessPiece> = emptyMap(),
    val turn: PieceColor = PieceColor.WHITE,
    val castlingRights: CastlingRights = CastlingRights(),
    val enPassantTarget: Square? = null,
    val halfMoveClock: Int = 0,
    val fullMoveNumber: Int = 1,
    val moveHistory: List<ChessMove> = emptyList(),
    val positionHistory: List<String> = emptyList(),
    val lastMove: ChessMove? = null
) {
    fun pieceAt(square: Square): ChessPiece? = pieces[square]

    fun kingSquare(color: PieceColor): Square? =
        pieces.entries.firstOrNull { it.value.color == color && it.value.type == PieceType.KING }?.key

    fun isSquareAttackedBy(target: Square, attackerColor: PieceColor): Boolean {
        // 1. Pawn attacks
        val pawnRankDir = if (attackerColor == PieceColor.WHITE) -1 else 1
        for (df in intArrayOf(-1, 1)) {
            val sq = target.offset(df, pawnRankDir)
            val p = pieceAt(sq)
            if (p != null && p.color == attackerColor && p.type == PieceType.PAWN) return true
        }

        // 2. Knight attacks
        val knightOffsets = arrayOf(
            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
            1 to -2, 1 to 2, 2 to -1, 2 to 1
        )
        for ((df, dr) in knightOffsets) {
            val sq = target.offset(df, dr)
            val p = pieceAt(sq)
            if (p != null && p.color == attackerColor && p.type == PieceType.KNIGHT) return true
        }

        // 3. King attacks
        for (df in -1..1) {
            for (dr in -1..1) {
                if (df == 0 && dr == 0) continue
                val sq = target.offset(df, dr)
                val p = pieceAt(sq)
                if (p != null && p.color == attackerColor && p.type == PieceType.KING) return true
            }
        }

        // 4. Orthogonal rays (Rook / Queen)
        val orthoDirs = arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)
        for ((df, dr) in orthoDirs) {
            var step = 1
            while (true) {
                val sq = target.offset(df * step, dr * step)
                if (!sq.isValid) break
                val p = pieceAt(sq)
                if (p != null) {
                    if (p.color == attackerColor && (p.type == PieceType.ROOK || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                step++
            }
        }

        // 5. Diagonal rays (Bishop / Queen)
        val diagDirs = arrayOf(1 to 1, 1 to -1, -1 to 1, -1 to -1)
        for ((df, dr) in diagDirs) {
            var step = 1
            while (true) {
                val sq = target.offset(df * step, dr * step)
                if (!sq.isValid) break
                val p = pieceAt(sq)
                if (p != null) {
                    if (p.color == attackerColor && (p.type == PieceType.BISHOP || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                step++
            }
        }

        return false
    }

    fun isInCheck(color: PieceColor = turn): Boolean {
        val kSq = kingSquare(color) ?: return false
        return isSquareAttackedBy(kSq, color.opposite())
    }

    fun generatePseudoLegalMoves(forColor: PieceColor = turn): List<ChessMove> {
        val moves = mutableListOf<ChessMove>()
        for ((sq, piece) in pieces) {
            if (piece.color != forColor) continue
            when (piece.type) {
                PieceType.PAWN -> generatePawnMoves(sq, piece.color, moves)
                PieceType.KNIGHT -> generateKnightMoves(sq, piece.color, moves)
                PieceType.BISHOP -> generateSlidingMoves(sq, piece.color, arrayOf(1 to 1, 1 to -1, -1 to 1, -1 to -1), moves)
                PieceType.ROOK -> generateSlidingMoves(sq, piece.color, arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1), moves)
                PieceType.QUEEN -> generateSlidingMoves(
                    sq,
                    piece.color,
                    arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1, 1 to 1, 1 to -1, -1 to 1, -1 to -1),
                    moves
                )
                PieceType.KING -> generateKingMoves(sq, piece.color, moves)
            }
        }
        return moves
    }

    private fun generatePawnMoves(from: Square, color: PieceColor, out: MutableList<ChessMove>) {
        val dir = if (color == PieceColor.WHITE) 1 else -1
        val startRank = if (color == PieceColor.WHITE) 1 else 6
        val promoRank = if (color == PieceColor.WHITE) 7 else 0
        val promoTypes = listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)

        // Single step forward
        val oneStep = from.offset(0, dir)
        if (oneStep.isValid && pieceAt(oneStep) == null) {
            if (oneStep.rank == promoRank) {
                for (pt in promoTypes) {
                    out.add(ChessMove(from = from, to = oneStep, promotion = pt))
                }
            } else {
                out.add(ChessMove(from = from, to = oneStep))
                // Double step from starting rank
                if (from.rank == startRank) {
                    val twoStep = from.offset(0, dir * 2)
                    if (twoStep.isValid && pieceAt(twoStep) == null) {
                        out.add(ChessMove(from = from, to = twoStep))
                    }
                }
            }
        }

        // Captures (including En Passant)
        for (df in intArrayOf(-1, 1)) {
            val target = from.offset(df, dir)
            if (!target.isValid) continue
            val targetPiece = pieceAt(target)
            if (targetPiece != null && targetPiece.color != color) {
                if (target.rank == promoRank) {
                    for (pt in promoTypes) {
                        out.add(ChessMove(from = from, to = target, promotion = pt, capturedPiece = targetPiece))
                    }
                } else {
                    out.add(ChessMove(from = from, to = target, capturedPiece = targetPiece))
                }
            } else if (target == enPassantTarget) {
                val epCapturedSquare = Square(target.file, from.rank)
                val epPawn = pieceAt(epCapturedSquare)
                if (epPawn != null && epPawn.color != color && epPawn.type == PieceType.PAWN) {
                    out.add(
                        ChessMove(
                            from = from,
                            to = target,
                            isEnPassant = true,
                            capturedPiece = epPawn
                        )
                    )
                }
            }
        }
    }

    private fun generateKnightMoves(from: Square, color: PieceColor, out: MutableList<ChessMove>) {
        val offsets = arrayOf(
            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
            1 to -2, 1 to 2, 2 to -1, 2 to 1
        )
        for ((df, dr) in offsets) {
            val to = from.offset(df, dr)
            if (!to.isValid) continue
            val occupant = pieceAt(to)
            if (occupant == null || occupant.color != color) {
                out.add(ChessMove(from = from, to = to, capturedPiece = occupant))
            }
        }
    }

    private fun generateSlidingMoves(
        from: Square,
        color: PieceColor,
        dirs: Array<Pair<Int, Int>>,
        out: MutableList<ChessMove>
    ) {
        for ((df, dr) in dirs) {
            var step = 1
            while (true) {
                val to = from.offset(df * step, dr * step)
                if (!to.isValid) break
                val occupant = pieceAt(to)
                if (occupant == null) {
                    out.add(ChessMove(from = from, to = to))
                } else {
                    if (occupant.color != color) {
                        out.add(ChessMove(from = from, to = to, capturedPiece = occupant))
                    }
                    break
                }
                step++
            }
        }
    }

    private fun generateKingMoves(from: Square, color: PieceColor, out: MutableList<ChessMove>) {
        for (df in -1..1) {
            for (dr in -1..1) {
                if (df == 0 && dr == 0) continue
                val to = from.offset(df, dr)
                if (!to.isValid) continue
                val occupant = pieceAt(to)
                if (occupant == null || occupant.color != color) {
                    out.add(ChessMove(from = from, to = to, capturedPiece = occupant))
                }
            }
        }

        // Castling
        val homeRank = if (color == PieceColor.WHITE) 0 else 7
        if (from == Square(4, homeRank) && !isInCheck(color)) {
            val enemy = color.opposite()
            // Kingside
            val canKingSide = if (color == PieceColor.WHITE) castlingRights.whiteKingSide else castlingRights.blackKingSide
            if (canKingSide) {
                val fSq = Square(5, homeRank)
                val gSq = Square(6, homeRank)
                val rookSq = Square(7, homeRank)
                val rook = pieceAt(rookSq)
                if (rook?.type == PieceType.ROOK && rook.color == color &&
                    pieceAt(fSq) == null && pieceAt(gSq) == null &&
                    !isSquareAttackedBy(fSq, enemy) && !isSquareAttackedBy(gSq, enemy)
                ) {
                    out.add(ChessMove(from = from, to = gSq, isCastlingKingSide = true))
                }
            }
            // Queenside
            val canQueenSide = if (color == PieceColor.WHITE) castlingRights.whiteQueenSide else castlingRights.blackQueenSide
            if (canQueenSide) {
                val dSq = Square(3, homeRank)
                val cSq = Square(2, homeRank)
                val bSq = Square(1, homeRank)
                val rookSq = Square(0, homeRank)
                val rook = pieceAt(rookSq)
                if (rook?.type == PieceType.ROOK && rook.color == color &&
                    pieceAt(dSq) == null && pieceAt(cSq) == null && pieceAt(bSq) == null &&
                    !isSquareAttackedBy(dSq, enemy) && !isSquareAttackedBy(cSq, enemy)
                ) {
                    out.add(ChessMove(from = from, to = cSq, isCastlingQueenSide = true))
                }
            }
        }
    }

    fun applyMoveUnchecked(move: ChessMove, computeSan: String = ""): ChessBoardState {
        val movingPiece = pieceAt(move.from) ?: return this
        val newPieces = pieces.toMutableMap()
        newPieces.remove(move.from)

        if (move.isEnPassant) {
            val epVictimSq = Square(move.to.file, move.from.rank)
            newPieces.remove(epVictimSq)
        }

        if (move.isCastlingKingSide) {
            val rank = move.from.rank
            val rook = newPieces.remove(Square(7, rank))
            if (rook != null) newPieces[Square(5, rank)] = rook
        } else if (move.isCastlingQueenSide) {
            val rank = move.from.rank
            val rook = newPieces.remove(Square(0, rank))
            if (rook != null) newPieces[Square(3, rank)] = rook
        }

        val placedPiece = if (move.promotion != null) {
            ChessPiece(move.promotion, movingPiece.color)
        } else {
            movingPiece
        }
        newPieces[move.to] = placedPiece

        // Update castling rights
        var newRights = castlingRights
        if (movingPiece.type == PieceType.KING) {
            newRights = if (movingPiece.color == PieceColor.WHITE) {
                newRights.copy(whiteKingSide = false, whiteQueenSide = false)
            } else {
                newRights.copy(blackKingSide = false, blackQueenSide = false)
            }
        }
        if (move.from == Square(0, 0) || move.to == Square(0, 0)) newRights = newRights.copy(whiteQueenSide = false)
        if (move.from == Square(7, 0) || move.to == Square(7, 0)) newRights = newRights.copy(whiteKingSide = false)
        if (move.from == Square(0, 7) || move.to == Square(0, 7)) newRights = newRights.copy(blackQueenSide = false)
        if (move.from == Square(7, 7) || move.to == Square(7, 7)) newRights = newRights.copy(blackKingSide = false)

        // Update en passant target
        val newEpTarget = if (movingPiece.type == PieceType.PAWN && abs(move.to.rank - move.from.rank) == 2) {
            Square(move.from.file, (move.from.rank + move.to.rank) / 2)
        } else {
            null
        }

        val newHalfMove = if (movingPiece.type == PieceType.PAWN || move.capturedPiece != null || move.isEnPassant) {
            0
        } else {
            halfMoveClock + 1
        }

        val newFullMove = if (turn == PieceColor.BLACK) fullMoveNumber + 1 else fullMoveNumber
        val recordedMove = if (computeSan.isNotEmpty()) move.copy(san = computeSan) else move
        val nextTurn = turn.opposite()

        val nextState = ChessBoardState(
            pieces = newPieces,
            turn = nextTurn,
            castlingRights = newRights,
            enPassantTarget = newEpTarget,
            halfMoveClock = newHalfMove,
            fullMoveNumber = newFullMove,
            moveHistory = moveHistory + recordedMove,
            positionHistory = positionHistory,
            lastMove = recordedMove
        )
        val posKey = nextState.repetitionKey()
        return nextState.copy(positionHistory = positionHistory + posKey)
    }

    fun legalMoves(forColor: PieceColor = turn): List<ChessMove> {
        val pseudo = generatePseudoLegalMoves(forColor)
        val legal = mutableListOf<ChessMove>()
        for (m in pseudo) {
            val next = applyMoveUnchecked(m)
            if (!next.isInCheck(forColor)) {
                legal.add(m)
            }
        }
        return legal.map { m -> m.copy(san = formatSan(m, legal)) }
    }

    fun legalMovesFrom(square: Square): List<ChessMove> =
        legalMoves(turn).filter { it.from == square }

    fun makeMove(move: ChessMove): ChessBoardState? {
        val allLegal = legalMoves(turn)
        val matched = allLegal.firstOrNull {
            it.from == move.from && it.to == move.to && (move.promotion == null || it.promotion == move.promotion)
        } ?: return null
        return applyMoveUnchecked(matched, matched.san)
    }

    fun makeMoveBySquares(from: Square, to: Square, promotion: PieceType? = PieceType.QUEEN): ChessBoardState? {
        val allLegal = legalMoves(turn)
        val candidates = allLegal.filter { it.from == from && it.to == to }
        if (candidates.isEmpty()) return null
        val chosen = if (candidates.size > 1 && promotion != null) {
            candidates.firstOrNull { it.promotion == promotion } ?: candidates.first()
        } else {
            candidates.first()
        }
        return applyMoveUnchecked(chosen, chosen.san)
    }

    fun makeSanMove(sanInput: String): ChessBoardState? {
        val clean = sanInput.trim().replace("+", "").replace("#", "").replace("!", "").replace("?", "")
        val allLegal = legalMoves(turn)
        val matched = allLegal.firstOrNull {
            val mClean = it.san.replace("+", "").replace("#", "")
            mClean == clean || it.toUci().equals(clean, ignoreCase = true)
        } ?: return null
        return applyMoveUnchecked(matched, matched.san)
    }

    private fun formatSan(move: ChessMove, allLegal: List<ChessMove>): String {
        val sb = StringBuilder()
        val movingPiece = pieceAt(move.from) ?: return move.toUci()

        if (move.isCastlingKingSide) {
            sb.append("O-O")
        } else if (move.isCastlingQueenSide) {
            sb.append("O-O-O")
        } else {
            if (movingPiece.type != PieceType.PAWN) {
                sb.append(movingPiece.type.symbol)
                val ambiguous = allLegal.filter {
                    it != move &&
                        it.to == move.to &&
                        pieceAt(it.from)?.type == movingPiece.type &&
                        pieceAt(it.from)?.color == movingPiece.color
                }
                if (ambiguous.isNotEmpty()) {
                    val sameFile = ambiguous.any { it.from.file == move.from.file }
                    val sameRank = ambiguous.any { it.from.rank == move.from.rank }
                    if (!sameFile) {
                        sb.append(('a'.code + move.from.file).toChar())
                    } else if (!sameRank) {
                        sb.append(('1'.code + move.from.rank).toChar())
                    } else {
                        sb.append(move.from.toAlgebraic())
                    }
                }
            } else if (move.capturedPiece != null || move.isEnPassant) {
                sb.append(('a'.code + move.from.file).toChar())
            }

            if (move.capturedPiece != null || move.isEnPassant) {
                sb.append('x')
            }
            sb.append(move.to.toAlgebraic())

            if (move.promotion != null) {
                sb.append('=').append(move.promotion.symbol)
            }
        }

        val afterState = applyMoveUnchecked(move)
        if (afterState.isInCheck(afterState.turn)) {
            val oppReplies = afterState.generatePseudoLegalMoves(afterState.turn).any { reply ->
                !afterState.applyMoveUnchecked(reply).isInCheck(afterState.turn)
            }
            if (!oppReplies) {
                sb.append('#')
            } else {
                sb.append('+')
            }
        }
        return sb.toString()
    }

    fun gameStatus(): GameStatus {
        val currentLegal = legalMoves(turn)
        if (currentLegal.isEmpty()) {
            return if (isInCheck(turn)) GameStatus.CHECKMATE else GameStatus.STALEMATE
        }
        if (halfMoveClock >= 100) return GameStatus.DRAW_FIFTY_MOVE
        val currentKey = repetitionKey()
        if (positionHistory.count { it == currentKey } >= 3) return GameStatus.DRAW_THREEFOLD
        if (hasInsufficientMaterial()) return GameStatus.DRAW_INSUFFICIENT_MATERIAL
        return if (isInCheck(turn)) GameStatus.CHECK else GameStatus.ACTIVE
    }

    fun hasInsufficientMaterial(): Boolean {
        val nonKings = pieces.entries.filter { it.value.type != PieceType.KING }
        if (nonKings.isEmpty()) return true // K vs K
        if (nonKings.size == 1) {
            val single = nonKings.first().value.type
            if (single == PieceType.BISHOP || single == PieceType.KNIGHT) return true
        }
        if (nonKings.size == 2) {
            val first = nonKings[0]
            val second = nonKings[1]
            if (first.value.type == PieceType.BISHOP && second.value.type == PieceType.BISHOP &&
                first.value.color != second.value.color &&
                first.key.isLightSquare == second.key.isLightSquare
            ) {
                return true // K+B vs K+B on same square color
            }
        }
        return false
    }

    fun repetitionKey(): String {
        val sb = StringBuilder()
        for (r in 7 downTo 0) {
            var empty = 0
            for (f in 0..7) {
                val p = pieceAt(Square(f, r))
                if (p == null) {
                    empty++
                } else {
                    if (empty > 0) {
                        sb.append(empty)
                        empty = 0
                    }
                    sb.append(p.toFenChar())
                }
            }
            if (empty > 0) sb.append(empty)
            if (r > 0) sb.append('/')
        }
        sb.append(' ').append(if (turn == PieceColor.WHITE) 'w' else 'b')
        sb.append(' ').append(castlingRights.toFenString())
        sb.append(' ').append(enPassantTarget?.toAlgebraic() ?: "-")
        return sb.toString()
    }

    fun toFen(): String = "${repetitionKey()} $halfMoveClock $fullMoveNumber"

    fun toPgn(eventName: String = "Chess Academy Practice", whiteName: String = "Learner", blackName: String = "Coach AI"): String {
        val sb = StringBuilder()
        sb.appendLine("[Event \"$eventName\"]")
        sb.appendLine("[White \"$whiteName\"]")
        sb.appendLine("[Black \"$blackName\"]")
        val resultStr = when (gameStatus()) {
            GameStatus.CHECKMATE -> if (turn == PieceColor.WHITE) "0-1" else "1-0"
            GameStatus.STALEMATE,
            GameStatus.DRAW_FIFTY_MOVE,
            GameStatus.DRAW_THREEFOLD,
            GameStatus.DRAW_INSUFFICIENT_MATERIAL -> "1/2-1/2"
            else -> "*"
        }
        sb.appendLine("[Result \"$resultStr\"]")
        sb.appendLine()
        val movesText = StringBuilder()
        for (i in moveHistory.indices) {
            if (i % 2 == 0) {
                if (i > 0) movesText.append(' ')
                movesText.append("${(i / 2) + 1}. ")
            } else {
                movesText.append(' ')
            }
            movesText.append(moveHistory[i].san.ifEmpty { moveHistory[i].toUci() })
        }
        if (movesText.isNotEmpty()) movesText.append(' ')
        movesText.append(resultStr)
        sb.append(movesText.toString().trim())
        return sb.toString()
    }

    companion object {
        const val INITIAL_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        fun initial(): ChessBoardState = fromFen(INITIAL_FEN)

        fun fromFen(fen: String): ChessBoardState {
            val parts = fen.trim().split(Regex("\\s+"))
            if (parts.isEmpty() || parts[0].isEmpty()) return fromFen(INITIAL_FEN)

            val ranks = parts[0].split("/")
            if (ranks.size != 8) return fromFen(INITIAL_FEN)

            val map = mutableMapOf<Square, ChessPiece>()
            for (rIdx in 0..7) {
                val rankStr = ranks[7 - rIdx]
                var file = 0
                for (ch in rankStr) {
                    if (ch.isDigit()) {
                        file += ch.digitToInt()
                    } else {
                        val piece = ChessPiece.fromFenChar(ch)
                        if (piece != null && file in 0..7) {
                            map[Square(file, rIdx)] = piece
                        }
                        file++
                    }
                }
            }

            // Ensure both kings exist for valid board state unless it's a pure demonstration fragment
            val turn = if (parts.getOrNull(1) == "b") PieceColor.BLACK else PieceColor.WHITE
            val castling = CastlingRights.fromFenString(parts.getOrNull(2) ?: "-")
            val ep = parts.getOrNull(3)?.let { Square.fromAlgebraic(it) }
            val halfMove = parts.getOrNull(4)?.toIntOrNull() ?: 0
            val fullMove = parts.getOrNull(5)?.toIntOrNull() ?: 1

            val base = ChessBoardState(
                pieces = map,
                turn = turn,
                castlingRights = castling,
                enPassantTarget = ep,
                halfMoveClock = halfMove,
                fullMoveNumber = fullMove
            )
            return base.copy(positionHistory = listOf(base.repetitionKey()))
        }

        fun fromPgn(pgn: String): ChessBoardState {
            var state = initial()
            val body = pgn.lines()
                .filterNot { it.trim().startsWith("[") }
                .joinToString(" ")
                .replace(Regex("\\{[^}]*\\}"), " ")
                .replace(Regex("\\d+\\.+"), " ")
                .replace("1-0", "")
                .replace("0-1", "")
                .replace("1/2-1/2", "")
                .replace("*", "")
            val tokens = body.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
            for (tok in tokens) {
                val next = state.makeSanMove(tok) ?: break
                state = next
            }
            return state
        }
    }
}
