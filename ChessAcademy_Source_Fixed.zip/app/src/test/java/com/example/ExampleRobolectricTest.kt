package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.curriculum.CurriculumLevels5To9
import com.example.curriculum.LearnerLevel
import com.example.data.ChessAcademyDatabase
import com.example.data.ChessAcademyRepository
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var database: ChessAcademyDatabase
    private lateinit var repository: ChessAcademyRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(
            context,
            ChessAcademyDatabase::class.java
        ).allowMainThreadQueries().build()
        repository = ChessAcademyRepository(database.dao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `read app_name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Chess Academy", appName)
    }

    @Test
    fun `performance gating unlocks next lesson only when passing score achieved`() = runBlocking {
        repository.ensureInitialized()
        val lesson1 = CurriculumLevels5To9.allLessons[0] // L1_T1
        val lesson2 = CurriculumLevels5To9.allLessons[1] // L1_T2

        // Fail test with 60% (< 80% default threshold)
        val passedLow = repository.recordLessonAssessment(
            lesson = lesson1,
            scorePercent = 60,
            questionResults = listOf(
                true to "",
                true to "",
                true to "",
                false to "Missed concept",
                false to "Missed concept"
            )
        )
        assertFalse(passedLow)
        val lesson2AfterFail = database.dao().getLessonProgressOnce(lesson2.id)
        assertFalse("Lesson 2 must remain locked after 60% score", lesson2AfterFail?.isUnlocked == true)

        // Verify weak concept was scheduled for revision
        val mastery = database.dao().getConceptMasteryOnce(lesson1.conceptTag)
        assertTrue(mastery != null && mastery.incorrectCount == 2)

        // Pass test with 80%
        val passedHigh = repository.recordLessonAssessment(
            lesson = lesson1,
            scorePercent = 80,
            questionResults = listOf(
                true to "",
                true to "",
                true to "",
                true to "",
                false to "Minor slip"
            )
        )
        assertTrue(passedHigh)
        val lesson2AfterPass = database.dao().getLessonProgressOnce(lesson2.id)
        assertTrue("Lesson 2 must unlock after 80% passing score", lesson2AfterPass?.isUnlocked == true)
    }

    @Test
    fun `skill assessment placement configures starting curriculum level`() = runBlocking {
        repository.ensureInitialized()
        repository.completeOnboardingWithAssessment(
            diagnosticScore = 65,
            assignedLevel = LearnerLevel.INTERMEDIATE
        )
        val profile = database.dao().getProfileOnce()
        assertEquals(true, profile?.hasCompletedOnboarding)
        assertEquals("INTERMEDIATE", profile?.assignedLevelName)
        assertEquals(4, profile?.currentCurriculumLevel)
    }
}
