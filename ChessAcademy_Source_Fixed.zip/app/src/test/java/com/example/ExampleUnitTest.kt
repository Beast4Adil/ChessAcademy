package com.example

import com.example.chess.AiDifficulty
import com.example.chess.ChessBoardState
import com.example.chess.ChessCoachAi
import com.example.chess.GameStatus
import com.example.chess.PieceColor
import com.example.chess.PieceType
import com.example.chess.Square
import com.example.curriculum.CurriculumLevels5To9
import com.example.curriculum.PuzzleAndAssessmentCatalog
import com.example.curriculum.PuzzleCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `initial board has 20 legal moves and 32 pieces`() {
        val board = ChessBoardState.initial()
        assertEquals(32, board.pieces.size)
        assertEquals(PieceColor.WHITE, board.turn)
        val legal = board.legalMoves()
        assertEquals(20, legal.size)
    }

    @Test
    fun `kingside and queenside castling work and respect attack rules`() {
        val fen = "r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1"
        val board = ChessBoardState.fromFen(fen)
        val afterOO = board.makeSanMove("O-O")
        assertNotNull(afterOO)
        assertEquals(PieceType.KING, afterOO!!.pieceAt(Square.fromAlgebraic("g1")!!)?.type)
        assertEquals(PieceType.ROOK, afterOO.pieceAt(Square.fromAlgebraic("f1")!!)?.type)

        val afterOOO = board.makeSanMove("O-O-O")
        assertNotNull(afterOOO)
        assertEquals(PieceType.KING, afterOOO!!.pieceAt(Square.fromAlgebraic("c1")!!)?.type)
        assertEquals(PieceType.ROOK, afterOOO.pieceAt(Square.fromAlgebraic("d1")!!)?.type)
    }

    @Test
    fun `en passant capture removes captured pawn and expires next move`() {
        val board = ChessBoardState.fromFen("4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1")
        val afterEp = board.makeMoveBySquares(
            Square.fromAlgebraic("e5")!!,
            Square.fromAlgebraic("d6")!!
        )
        assertNotNull(afterEp)
        assertEquals(PieceType.PAWN, afterEp!!.pieceAt(Square.fromAlgebraic("d6")!!)?.type)
        assertEquals(null, afterEp.pieceAt(Square.fromAlgebraic("d5")!!))
    }

    @Test
    fun `pawn promotion supports queen and underpromotion`() {
        val board = ChessBoardState.fromFen("8/4P1k1/8/8/8/8/8/4K3 w - - 0 1")
        val promotedQueen = board.makeMoveBySquares(
            Square.fromAlgebraic("e7")!!,
            Square.fromAlgebraic("e8")!!,
            PieceType.QUEEN
        )
        assertNotNull(promotedQueen)
        assertEquals(PieceType.QUEEN, promotedQueen!!.pieceAt(Square.fromAlgebraic("e8")!!)?.type)

        val promotedKnight = board.makeMoveBySquares(
            Square.fromAlgebraic("e7")!!,
            Square.fromAlgebraic("e8")!!,
            PieceType.KNIGHT
        )
        assertNotNull(promotedKnight)
        assertEquals(PieceType.KNIGHT, promotedKnight!!.pieceAt(Square.fromAlgebraic("e8")!!)?.type)
    }

    @Test
    fun `checkmate stalemate and insufficient material are detected accurately`() {
        // Back-rank checkmate
        val mateStart = ChessBoardState.fromFen("6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1")
        val mated = mateStart.makeSanMove("Rd8#")
        assertNotNull(mated)
        assertEquals(GameStatus.CHECKMATE, mated!!.gameStatus())

        // Stalemate
        val staleBoard = ChessBoardState.fromFen("7k/5K2/6Q1/8/8/8/8/8 b - - 0 1")
        assertEquals(GameStatus.STALEMATE, staleBoard.gameStatus())

        // Insufficient Material (K+N vs K)
        val insuffBoard = ChessBoardState.fromFen("4k3/8/8/8/4N3/8/8/4K3 w - - 0 1")
        assertEquals(GameStatus.DRAW_INSUFFICIENT_MATERIAL, insuffBoard.gameStatus())
    }

    @Test
    fun `all 9 curriculum levels and 9 puzzle categories have valid positions and 5 questions`() {
        assertEquals(9, CurriculumLevels5To9.levelSpecs.size)
        val allLessons = CurriculumLevels5To9.allLessons
        assertTrue("Expected at least 170 lessons across 9 levels", allLessons.size >= 170)

        for (lvl in 1..9) {
            val lvlLessons = CurriculumLevels5To9.lessonsForLevel(lvl)
            assertFalse("Level $lvl must not be empty", lvlLessons.isEmpty())
            for (lesson in lvlLessons) {
                assertTrue("Lesson ${lesson.id} must have at least 5 questions", lesson.questions.size >= 5)
            }
        }

        // Verify all 9 puzzle categories exist and have legal solution moves
        for (cat in PuzzleCategory.entries) {
            val puzzles = PuzzleAndAssessmentCatalog.allPuzzles.filter { it.category == cat }
            assertFalse("Category $cat must have puzzles", puzzles.isEmpty())
            for (puz in puzzles) {
                val state = ChessBoardState.fromFen(puz.fen)
                val firstUci = puz.solutionMovesUci.first()
                val from = Square.fromAlgebraic(firstUci.substring(0, 2))!!
                val to = Square.fromAlgebraic(firstUci.substring(2, 4))!!
                val moved = state.makeMoveBySquares(from, to)
                assertNotNull("Puzzle ${puz.id} solution move $firstUci must be legal", moved)
            }
        }
    }

    @Test
    fun `coaching AI selects legal moves and evaluates blunders`() {
        val board = ChessBoardState.initial()
        val aiMove = ChessCoachAi.selectBestMove(board, AiDifficulty.INTERMEDIATE)
        assertNotNull(aiMove)
        val next = board.makeMove(aiMove!!)
        assertNotNull(next)

        val eval = ChessCoachAi.analyzeMove(board, aiMove)
        assertTrue(eval.coachExplanation.isNotBlank())
    }
}
